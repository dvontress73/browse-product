sap.ui.define([
	"hcm/fab/myleaverequest/utils/utils",
	"hcm/fab/myleaverequest/utils/formatters",
	"hcm/fab/lib/common/util/TeamCalendarDataManager",
	"hcm/fab/lib/common/util/DateUtil",
	"sap/ui/Device",
	"hcm/fab/myleaverequest/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/unified/DateRange",
	"sap/ui/unified/DateTypeRange",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/ui/core/LocaleData",
	"jquery.sap.storage"
], function(u, f, T, D, a, B, F, b, H, c, d, J, M, e, g, LocaleData) {
	"use strict";
	
	f.statusFormatter = function (sStatus, statusText) {
		if (sStatus === "CANCELED") {
			return sap.ui.core.ValueState.None;
		}
		
		switch (sStatus) {
			case "POSTED":
			case "APPROVED":
				return sap.ui.core.ValueState.Success;
			case "SENT":
				return sap.ui.core.ValueState.Warning;
			case "REJECTED":
				return sap.ui.core.ValueState.Error;
			default: //fallback (should not happen)
				return sap.ui.core.ValueState.None;
		}
	};
	
	return sap.ui.controller("hcm.fab.myleaverequest.HCMFAB_LEAV_MANExtension.controller.OverviewCustom", {

	});
});