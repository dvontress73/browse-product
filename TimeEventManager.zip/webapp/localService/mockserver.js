sap.ui.define([
    "./ZHRF_ACTUAL_PAID_SRV/mockserver",
    "./ZHRF_SHARED_SRV/mockserver",
    "./ZHRF_HCMFAB_MYTIMEEVENTS_SRV/mockserver",
    "./ZHRF_HCMFAB_TIME_PAYROLL_CHECK_SRV/mockserver"
], function(
	actualPaidMockServer, 
	sharedMockServer, 
	timeEventsMockServer,
	payrollCheckMockServer
){
    return {
        init: function(){
            actualPaidMockServer.init();
            sharedMockServer.init();
            timeEventsMockServer.init();
            payrollCheckMockServer.init();
        },
        
        actualPaid: function(){
        	return actualPaidMockServer.getMockServer();
        },
        
        shared: function(){
        	return sharedMockServer.getMockServer();
        },
        
        timeEvents: function(){ 
        	return timeEventsMockServer.getMockServer();
        },
        
        payrollCheck: function(){
        	return payrollCheckMockServer.getMockServer();
        }
    };
});