sap.ui.define([
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/m/Button"
], function (
	Dialog,
	Label,
	TextArea,
	Button
) {
	/**
	 * Creates a new instance of the DeleteDialog
	 * @constructor
	 * @param {object} options Constructor options for DeleteDialog wrapper
	 * @param {string} [options.text] The dialog label
	 * @param {string} [options.title] The dialog title
	 * @param {string} [options.formPlaceholder] The placeholder text for input box
	 * @param {string} [options.value] The form value of the delete dialog
	 * @param {function} [options.deleteCallback] The delete callback.
	 * @param {boolean} [options.enabled] Whether or not the delete action is enabled.
	 * @param {sap.ui.model} [options.model] The model for the control
	 */
	var DeleteDialog = function DeleteDialog(options) {
		this.model = options.model || null;
		this.modelName = "deleteDialogViewModel";
		var defaults = {
			title: "Confirm",
			text: "Are you sure you want to delete this?",
			value: "",
			formPlaceholder: "Add note",
			enabled: true,
			deleteCallback: function () {}
		};

		this.noteInput = new TextArea("submitDialogTextarea", {
			width: "100%",
			placeholder: options.formPlaceholder || defaults.formPlaceholder,
			valueLiveUpdate: true
		});
		var inputValue = options.value || defaults.value;
		if (typeof inputValue === "object") {
			this.noteInput.bindValue(inputValue);
		} else {
			this.noteInput.setValue(inputValue);
		}

		this.deleteBtn = new Button({
			text: "Delete",
			type: sap.m.ButtonType.Reject,
			press: options.deleteCallback || defaults.deleteCallback
		});
		var deleteEnabled = options.enabled || defaults.enabled;
		if (typeof deleteEnabled === "object") {
			this.deleteBtn.bindProperty("enabled", deleteEnabled);
		} else {
			this.deleteBtn.setEnabled(deleteEnabled);
		}
		
		this.label = new Label({
			text: "Are you sure you want to remove this Clock In / Clock Out event.",
			labelFor: "submitDialogTextarea"
		});
		var labelText = options.text || defaults.text;
		if (typeof labelText === "object") {
			this.label.bindProperty("text", labelText);
		} else {
			this.label.setText(labelText);
		}

		this._dialog = new Dialog({
			type: "Message",
			content: [
				this.label,
				this.noteInput
			],
			beginButton: this.deleteBtn,
			endButton: new Button({
				text: "Cancel",
				press: this.close.bind(this)
			}),
			afterClose: this.afterClose.bind(this)
		});

		var title = options.title || defaults.title;
		if (typeof title === "object") {
			this._dialog.bindProperty("title", title);
		} else {
			this._dialog.setTitle(title);
		}
		
		// bind to model
		if (options.model) {
			this.setModel(options.model);
		}
		
		return this;
	};
	
	DeleteDialog.prototype.setModel = function setModel (model, name) {
		this.modelName = name || "deleteDialogViewModel";

		var result = this.deleteBtn.setModel(model, name)
			&& this.noteInput.setModel(model, name)
			&& this._dialog.setModel(model, name);
			
		return result;
	};
	
	DeleteDialog.prototype.open = function open () {
		return this._dialog.open();
	};
	
	DeleteDialog.prototype.close = function close () {
		return this._dialog.close();
	};
	
	DeleteDialog.prototype.afterClose = function afterClose () {
		return this._dialog.destroy();
	};

	return DeleteDialog;
});