sap.ui.define([
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV"
	], function (Export, ExportTypeCSV) {
		"use strict";
		/**
		 * A module to generate csv's in an opinionated builder
		 * pattern
		 * @module
		 */
		 
		/**
		 * @constructor
		 * @param {sap.ui.model.json.JSONModel} jsonModel The JSON Model for binding
		 * @param {string} path The root node for the path
		 */
		var ExportBuilder = function(jsonModel, path) {
			/** @type {sap.ui.model.json.JSONMode} */
			this._binding = jsonModel;
			/** @type {string} */
			this._bindingPath = path;
			/** @type {column[]} */
			this._columns = [];
		};
		
		/**
		 * Builds the export object from builder
		 * @return {sap.ui.core.util.Export} An Export instance
		 */
		ExportBuilder.prototype.buildExport = function () {
			return new Export({
			    // Type that will be used to generate the content. Own ExportType's can be created to support other formats
			    exportType: new sap.ui.core.util.ExportTypeCSV(),
			
			    // Pass in the model created above
			    models: this._binding,
			
			    // binding information for the rows aggregation 
			    rows: {
			        path: this._bindingPath
			    },
			
			    // column definitions with column name and binding info for the content
			    columns: this._columns
			});
		};
		
		/**
		 * Add a column to the export
		 * @param {string} name The title of the column
		 * @param {string|object} content The binding path or content options to use as content for the column
		 * @return {this} Returns self for builder patterns.
		 */
		ExportBuilder.prototype.addColumn = function (name, content)  {
			var options = content;
			if (typeof content === "string") {
				options = {
		            path: content
		        };
			}
			
			this._columns.push({
	            name: name,
	            template: {
	                content: options
	            }
	        });
	        
	        return this;
		};
		
		/**
		 * @return {Promise} A promise that resolves whent the export has been attempted to generate.
		 */
		ExportBuilder.prototype.download = function () {
			return this.buildExport()
				.saveFile()
				.always(function() {
				    this.destroy();
				});
		};
		
		return ExportBuilder;
	}
);