sap.ui.define([
	"dart/hcm/timeevtmgr/model/ClockEvent",
	"dart/hcm/timeevtmgr/model/ExceptionCodes"
],
function (
	ClockEvent,
	ExceptionCodes
) {
	"use strict";
	
	var clockItemProperties = [
		"Clockin1",
		"Clockout1",
		"Clockin2",
		"Clockout2",
		"Clockin3",
		"Clockout3"
	];
	
	/**
	 * Creates a Daily Summary for a specific employee.
	 * @returns {ClockEventDailySummary}
	 */
	var ClockEventDailySummary = function ClockEventDailySummary () {
		/** @type {string} */
		this.employeeName = "";
		/** @type {string} */
		this.employeeNumber = "";
		/** @type {ClockEvent[]} */
		this.clockEvents = [];
		/** @type {Date} */
		this.date = new Date();
		/** @type {bool} */
		this.hasError = false;
		/** @type {string} */
		this.errorMessage = "";
		/** @type {bool} */
		this.hasWarning = false;
		/** @type {float} */
		this.actualHours = 0;
		/** @type {float} */
		this.actualHourMinuteFormat = "";
		/** @type {float} */
		this.plannedHours = 0;
		/** @type {string} */
		this.absenseType = "";
		/** @type {string} */
		this.exceptionCodes = "";
		/** @type {ExceptionCodes[]} */
		this.exceptions = [];		
		/** @type {sap.ui.core.MessageType} */
		this.worstMessageType = "None";
		/** @type {string} */
		this.scheduleRule = "";
		/** @type {sap.ui.core.ValueState} */
		this.actualVsPlannedState = "None";
		return this;
	};
	
	ClockEventDailySummary.prototype.setDate = function setDate(date) {
		this.date = date;
		return this;
	};
	
	ClockEventDailySummary.prototype.setError = function setError(error) {
		this.hasError = true;
		this.errorMessage += error;
		return this;
	};
	
	ClockEventDailySummary.prototype.setPlannedHours = function setPlannedHours(num) {
		this.plannedHours = parseFloat(num, 10);
		this.getActualVsPlannedState();
		return this;
	};
	
	ClockEventDailySummary.prototype.setActualHours = function setActualHours(num) {
		this.actualHours = parseFloat(num, 10);
		this.getActualVsPlannedState();
		return this;
	};
	
	ClockEventDailySummary.prototype.getActualVsPlannedState = function getActualVsPlannedState() {
		var diff = Math.abs(this.plannedHours - this.actualHours);
		if (diff > 2) {
			this.actualVsPlannedState = "Error";
		}
		if (diff <= 2 && diff > .5) {
			this.actualVsPlannedState = "Warning";
		}
		if (diff <= .5) {
			this.actualVsPlannedState = "None";
		}
		if (diff === 0) {
			this.actualVsPlannedState = "Success";
		}
		return this;
	};
	
	ClockEventDailySummary.prototype.setClockEvents = function setClockEvents(events) {
		var args = [0, this.clockEvents.length].concat(events);
		this.clockEvents.splice.apply(this.clockEvents, args);
		return this;
	};
	
	ClockEventDailySummary.prototype.setAbsenseType = function setAbsenseType(strType) {
		this.absenseType = strType;
		return this;
	};
	
	ClockEventDailySummary.prototype.setExceptionCodes = function setExceptionCodes(codes) {
		this.exceptionCodes = codes;
		var exceptions = ExceptionCodes.parse(codes);
		this.exceptions.splice.apply(this.exceptions, [0, this.exceptions.length].concat(exceptions));
		var worstLevel = this.exceptions.reduce(function(lvl, code) {
			if (code.level > lvl) {
				return code.level;
			}
			return lvl; 
		}, 0);
		this.worstMessageType = ExceptionCodes.getMessageType(worstLevel);
		return this;
	};
	
	ClockEventDailySummary.prototype.setScheduleRule = function setScheduleRule(rule) {
		this.scheduleRule = rule;
		return this;
	};
	
	ClockEventDailySummary.prototype.setEmployee = function setEmployee(number, name) {
		this.employeeNumber = number;
		this.employeeName = name;
		return this;
	};

	ClockEventDailySummary.prototype.resetErrors = function resetErrors () {
		this.hasError = false;
		this.errorMessage = "";
		return this; 
	};
	
	ClockEventDailySummary.prototype.resetExceptions = function resetExceptions () {
		this.exceptions = [];
		this.worstMessageType = "None";
		return this;
	};
	
	ClockEventDailySummary.prototype.setWarning = function setWarning () {
		this.hasWarning = true;
		return this;
	};
	
	ClockEventDailySummary.prototype.setActualHourMinuteFormat = function setActualHourMinuteFormat(value) {
		this.actualHourMinuteFormat = value;
		return this;
	};
	
	var createAbsentEvent = function (summary) {
		var absentEvent = new ClockEvent(summary.date);
		return absentEvent
			.setEmployee(summary.employeeNumber, summary.employeeName)
			.setType(summary.absenseType || "ABS")
			.setWarning()
			.setSchedule(summary.scheduleRule);
	};
	
	var createMissingPunch = function (summary, lastEvent) {
		// Generate a holder for missing punch line
			var error = "Missing a clock out punch. ";
			summary.setError(error);
			var missingEvent = new ClockEvent(summary.date); 

			return missingEvent.setError(error)
				.setEmployee(lastEvent.employeeNumber, lastEvent.employeeName)
				.setType("Missing Punch")
				.setDateTime(lastEvent.datetime)
				.setSchedule(summary.scheduleRule);
	};
	
	ClockEventDailySummary.parseResult = function parseResult (result) {
		// Build the Summary
		var summary = new ClockEventDailySummary();
		
		var exceptionCodes = result.ExceptionCodes;
		
		if(result.AbsenceDetailType === "ABS"){
			exceptionCodes += " ABS";
		}
		
		summary.setDate(result.PunchDate)
			.setActualHours(result.ActualEvaluatedHours)
			.setPlannedHours(result.PlannedWorkingHours)
			.setAbsenseType(result.AbsenceDetailType)
			.setExceptionCodes(exceptionCodes)
			.setEmployee(result.EmployeeNum, result.EmployeeName)
			.setScheduleRule(result.WSRuleDescription)
			.setActualHourMinuteFormat(result.ActualEvaluatedMinutes);
		
		return summary;
	};

	return ClockEventDailySummary;
});