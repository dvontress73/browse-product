sap.ui.define([
	"dart/hcm/timeevtmgr/model/ClockEventDailySummary",
	"dart/hcm/timeevtmgr/model/ExceptionCodes"
],
function (
	ClockEventDailySummary,
	ExceptionCodes
) {
	"use strict";
	
	var ClockEventEmployeeSummary = function ClockEventsSummary (employeeNumber, employeeName) {
		/** @type {string} */
		this.employeeNumber = employeeNumber || "";
		/** @type {string} */
		this.employeeName = employeeName || "";
		/** @type {ClockEventDailySummary[]} */
		this.dailySummaries = [];
		/** @type {bool} */
		this.hasError = false;
		/** @type {bool} */
		this.hasWarning = false;
		/** @type {string} */
		this.warningMessage = "";
		/** @type {string} */
		this.errorMessage = "";
		/** @type {float} */
		this.actualHours = 0;
		/** @type {float} */
		this.plannedHours = 0;
		/** @type {ExceptionCodes[]} */
		this.exceptions = [];
		/** @type {sap.ui.core.MessageType} */
		this.worstMessageType = "None";
		return this;
	};
	
	ClockEventEmployeeSummary.prototype.setError = function setError(errorMessage) {
		this.hasError = true;
		this.errorMessage += errorMessage;
		return this;
	};
	
	ClockEventEmployeeSummary.prototype.addDailySummary = function addDailySummary (result) {
		var dailySummary = ClockEventDailySummary.parseResult(result);

		this.actualHours += dailySummary.actualHours;
		this.plannedHours += dailySummary.plannedHours;
		this.dailySummaries.push(dailySummary);
		this.exceptions = this.exceptions.concat(dailySummary.exceptions);
		var worstLevel = this.exceptions.reduce(function(lvl, code) {
			if (code.level > lvl) {
				return code.level;
			}
			return lvl; 
		}, 0);
		this.worstMessageType = ExceptionCodes.getMessageType(worstLevel);
		
		if (dailySummary.hasError) {
			var formatter = sap.ui.core.format.DateFormat.getDateInstance({
				style: "short"
			});
			this.setError(formatter.format(dailySummary.date) + ": " + dailySummary.errorMessage); 
		}
	};

	ClockEventEmployeeSummary.prototype.resetErrors = function resetErrors () {
		this.hasError = false;
		this.errorMessage = "";
		for (var i = 0; i < this.dailySummaries.length; i++) {
			this.dailySummaries[i].resetErrors();
		}
		return this; 
	};
	
	ClockEventEmployeeSummary.prototype.resetExceptions = function resetExceptions () {
		this.exceptions = [];
		this.worstMessageType = "None";
		this.hasWarning = false;
		this.warningMessage = "";
		for (var i = 0; i < this.dailySummaries.length; i++) {
			this.dailySummaries[i].resetExceptions();
		}
		return this;
	};
	
	ClockEventEmployeeSummary.parseResults = function parseResults (results) {
		var nested = results.reduce(function(byEmployeeNum, result) {
			// Make an object
			var group = byEmployeeNum[result.EmployeeNum];
			if (!group) {
				group = new ClockEventEmployeeSummary(result.EmployeeNum, result.EmployeeName);
				byEmployeeNum[result.EmployeeNum] = group;
			}
			
			group.addDailySummary(result);
			
			return byEmployeeNum;
		}, {});
		
		var rows = [];
		for (var employeeNum in nested) {
		  rows.push(nested[employeeNum]);
		}
		
		return rows; 
	};
	
	ClockEventEmployeeSummary.prototype.flattenClockEvents = function flattenClockEvents () {
		// Flatten results
		var punches = [];
		
		for (var y = 0; y < this.dailySummaries.length; y++) {
			var dailySummary =  this.dailySummaries[y];
			
			for (var z = 0; z < dailySummary.clockEvents.length; z++) {
				var clockEvent = dailySummary.clockEvents[z];
				punches.push(clockEvent);
			}
		}

		return punches;
	};

	return ClockEventEmployeeSummary;
});