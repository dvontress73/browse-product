sap.ui.define(function () {
	var ExceptionCode = function ExceptionCode(text, level) {
		this.text = text || "";
		this.level = level || 0;
		return this;
	};
	
	var parser = function parser (value) {
		var NONE = 0;
		//var INFO = 1;
		var WARNING = 2;
		var ERROR = 3;

		switch (value) {
			case "ABS":
				return new ExceptionCode("Absent", ERROR);
			case "EI":
				return new ExceptionCode("Early In", NONE);
			case "LI":
				return new ExceptionCode("Late In", NONE);
			case "LL":
				return new ExceptionCode("Long Lunch", NONE);
			case "SL":
				return new ExceptionCode("Short Lunch", NONE);
			case "NL":
				return new ExceptionCode("No Lunch", NONE);
			case "EO":
				return new ExceptionCode("Early Out", NONE);
			case "LO":
				return new ExceptionCode("Late Out", NONE);
			case "OD":
				return new ExceptionCode("Missing Punch", ERROR);
			case "NS":
				return new ExceptionCode("Not Scheduled", NONE);
			case "AW":
				return new ExceptionCode("At Work With Absence", WARNING);
			case "5L":
				return new ExceptionCode("Lunch After 5th Hour", NONE);
			default:
				return new ExceptionCode(value);
		}
	};
	
	ExceptionCode.parse = function parse (values) {
		return values
			.split(" ")
			.filter(function(i){
				return i !== null && i.trim() !== ""; 
			})
			.map(function(each) {
				var safe = each.trim().toUpperCase(); 
				return parser(safe);
			});
	};
	
	ExceptionCode.getMessageType = function getMessageType(level) {
		level = level || 0;
		var types = [
			"None",
			"Information",
			"Warning",
			"Error"
		];
		
		return types[level];
	};
	
	return ExceptionCode;
});