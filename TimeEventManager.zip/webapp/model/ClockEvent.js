sap.ui.define(function () {
	"use strict";
	
	var ClockEvent = function ClockEvent (date) {
		/** @type {Date} */
		this.datetime = date ? new Date(date.getTime()) : new Date();
		/** @type {string} */
		this.type = "";
		/** @type {string} */
		this.message = "";
		/** @type {string} */
		this.icon = "";
		/** @type {bool} */
		this.hasError = false;
		/** @type {string} */
		this.errorMessage = "";
		/** @type {bool} */
		this.hasWarning = false;
		/** @type {string} */
		this.employeeName = "";
		/** @type {string} */
		this.employeeNumber = "";
		/** @type {string} */
		this.schedule = "";
		/** @type {bool} */
		this.posted = true;
		/** @type {string} */
		this.requestId = "";
		/** @type {bool} */
		this.canDelete = true;
		/** @type {string} */
		this.note = "";
		return this;
	};
	
	/**
	 * Sets the Time of the Clock event
	 * @param {string} time A string of the time
	 * @returns {ClockEvent} Return self.
	 */
	ClockEvent.prototype.setTime = function setTime (time) {
		var parts = time.split(":");
		var args = [0, 0, 0, 0];
		args.splice.apply(args, [0, parts.length].concat(parts));
		this.datetime.setUTCHours.apply(this.datetime, args);
		return this;
	};

	/**
	 * Sets the Datetime of the Clock event
	 * @param {Date} datetime The Datetime
	 * @returns {ClockEvent} Return self.
	 */
	ClockEvent.prototype.setDateTime = function setDateTime (datetime) {
		this.datetime = datetime;
		return this;
	};
	
	/**
	 * Sets the Time of the Clock event
	 * @param {string} type A string of the type of event. I.e. - Clock In, Clock Out, Missing Punch
	 * @returns {ClockEvent} Return self.
	 */
	ClockEvent.prototype.setType = function setType (type) {
		this.type = type;
		return this;
	};
	
	/**
	 * Sets whether or not the time event is posted.
	 * @param {bool} posted Whether or not the time event is posted.
	 * @returns {ClockEvent} Return self.
	 */
	ClockEvent.prototype.setPosted = function setPosted (posted) {
		this.posted = posted;
		return this;
	};
	
	ClockEvent.prototype.setError = function setError (errorMessage) {
		this.errorMessage = errorMessage;
		this.hasError = true;
		return this;
	};
	
	ClockEvent.prototype.setWarning = function setWarning () {
		this.hasWarning = true;
		return this;
	};
	
	ClockEvent.prototype.setEmployee = function setEmployee(number, name) {
		this.employeeNumber = number;
		this.employeeName = name;
		return this;
	};
	
	ClockEvent.prototype.setSchedule = function setSchedule(schedule) {
		this.schedule = schedule;
		return this;
	};
	
	ClockEvent.prototype.setRequestId = function setRequestId(value) {
		this.requestId = value;
		return this;
	};
	
	ClockEvent.prototype.setCanDelete = function setCanDelete(value) {
		this.canDelete = value;
		return this;
	};
	
	ClockEvent.prototype.setNote = function setNote(note) {
		this.note = note;
		return this;
	};

	return ClockEvent;
});