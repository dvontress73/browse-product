sap.ui.define(
[
	"sap/ui/core/Item",
	"sap/m/MessageToast",
	"sap/ui/core/routing/History",
	"dart/hcm/timeevtmgr/controller/BaseController",
	"dart/hcm/timeevtmgr/model/ClockEventEmployeeSummary",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"dart/hcm/core/SubordinateType"
], 
function(
	Item,
	MessageToast,
	History,
	BaseController,
	ClockEventEmployeeSummary,
	JSONModel,
	Filter,
	FilterOperator,
	Sorter,
	SubordinateType
) {
	"use strict";

	return BaseController.extend("dart.hcm.timeevtmgr.controller.CreatePunch", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf dart.hcm.timeevtmgr.view.Punches
		 */
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.attachRouteMatched(this.attachRouteMatched, this);
			
			this.resetViewModel();
		},
		
		resetViewModel: function() {
			this.viewModel = new JSONModel({
				results: null,
				busy: false,
				employeeNumber: null,
				datetime: new Date(),
				time: new Date(),
				note: "",
				verificationRun: false,
				verified: false,
				showValidationError: false,
				valueStateText: "",
				valueState: "None",
				subordinateType: SubordinateType.DIRECT,
				subordinateTypes: [
					{ key: SubordinateType.DIRECT, text: "Direct" },
					{ key: SubordinateType.INDIRECT, text: "Indirect" },
					{ key: SubordinateType.ANY, text: "Any" }
				]
			});
			
			this.setModel(this.viewModel, "viewModel");
		},
		
		onBeforeRendering: function () {
			this.getModel("shared")
				.attachRequestCompleted(this.requestVerification, this);
		},
		
		attachRouteMatched: function (evt) {
			var params = evt.getParameters();
			// Exit if not a match on known route
			if (params.name !== "createPunch") {
				return;
			}
			if (params.arguments["?query"]) {
				var reportType = params.arguments["?query"].reportType;
				var employeeNumber = params.arguments["?query"].employeeNumber;
				var datetimestamp = parseInt(params.arguments["?query"].datetime, 10);
				
				if (reportType) {
					this.viewModel.setProperty("/reportType", reportType);	
				}
				
				if (employeeNumber) {
					this.viewModel.setProperty("/employeeNumber", employeeNumber);	
				}
				
				if (datetimestamp) {
					var date = new Date(datetimestamp);
					
					// Build a time object from the UTC time
					var timeDate = new Date(0);
					timeDate.setHours(date.getUTCHours(), date.getUTCMinutes());
					
					this.viewModel.setProperty("/datetime", date);
					this.viewModel.setProperty("/time", timeDate);	
				} else {
					this.viewModel.setProperty("/time", new Date());
				}
				
			}

			// Start verifying
			this.requestVerification();
		},
		
		onSubordinateTypeChange: function (evt) {
			var params = evt.getParameters();
			var type = params.selectedItem.getKey();
			var employeeSelect = this.byId("EmployeeSelect");
			
			var employeeOption = new Item();
       		employeeOption.bindProperty("key", {
       			path: "EmployeeNum",
       			model: "shared"
       		});
       		employeeOption.bindProperty("text", {
       			path: "SubordinateInfo/Name",
       			model: "shared"
       		});
       		
       		var binding = {
       			path: "shared>/Subordinates",
       			template: employeeOption
       		};
       		var filters = [
       			new Filter({
					path: "SubGroupExclusion",
			    	operator: FilterOperator.EQ,
			    	value1: "Exempt"
				})
			];

       		if (type === SubordinateType.DIRECT) {
       			filters.push(new Filter({
       				path: "Selection",
       				operator: FilterOperator.EQ,
       				value1: "MSS_TMV_EE_DIR"
       			}));
       		}
       		if (type === SubordinateType.INDIRECT) {
       			filters.push(new Filter({
       				path: "Selection",
       				operator: FilterOperator.EQ,
       				value1: "MSS_TMV_EE_IND"
       			}));
       		}
       		
       		if (filters.length > 0) {
       			binding.filters = filters;
       		}
       		
       		employeeSelect.bindItems(binding);
		},

		handleTimePicker: function (evt) {
			var time = this.viewModel.getProperty("/time");
			var datetime = this.viewModel.getProperty("/datetime");
			datetime.setUTCHours(time.getHours(), time.getMinutes());
			this.viewModel.setProperty("/datetime", datetime);
			
			// Verify that the time is eligible
			this.requestVerification();
		},
		
		requestVerification: function () {
			var model = this.getModel("timeCheck");
			var employeeNumber = this.viewModel.getProperty("/employeeNumber");
			var datetime = this.viewModel.getProperty("/datetime");
			if (!employeeNumber) {
				return;
			}
			
			var entityPath = model.createKey("/EmployeeSet", {
				Pernr: employeeNumber,
				ClockDate: datetime
			});
			
			this.viewModel.setProperty("/verificationRun", false);
			this.viewModel.setProperty("/verified", false);
			this.viewModel.setProperty("/valueState", "None");
			this.viewModel.setProperty("/valueStateText", "");
			model.read(entityPath, {
				success: this.receiveVerification.bind(this),
				error: this.verificationErr.bind(this)
			});
		},
		
		receiveVerification: function (data) {
			var isValid = data.PayrollCheck === ""; // Obscure as can be
			this.viewModel.setProperty("/verificationRun", true);
			this.viewModel.setProperty("/showValidationError", !isValid);
			this.viewModel.setProperty("/valueState", isValid ? "Success" : "Error");
			this.viewModel.setProperty("/valueStateText", "Cannot add a clock in/clock out event to pay period for the selected date.");
			this.viewModel.setProperty("/verified", isValid);
		},
		
		verificationErr: function (err) {
			this.viewModel.setProperty("/verificationRun", true);
			this.viewModel.setProperty("/valueState", "Error");
			this.viewModel.setProperty("/valueStateText", err.message);
		},
		
		submit: function (evt) {
			var context;
			var submitting = this.viewModel.getProperty("/busy");
			// Exit if in progress
			if (submitting) {
				return;
			}
			
			var timeFormatter = sap.ui.core.format.DateFormat.getDateInstance({
		        pattern : "PTHH'H'mm'M'ss'S'"
		    });
			
			var onSuccess = function () {
				MessageToast.show("Clock In / Clock Out successfully created. Entry may not be reflected in Actual vs. Planned report immediately.", {
					closeOnBrowserNavigation: false
				});
				this.viewModel.setProperty("/busy", false);
				this.resetViewModel();
			};

			var onError = function (err) {
				this.parseErrorMessage(err);
				this.getModel("timeEvents").resetChanges();
				this.viewModel.setProperty("/busy", false);
				
				if(context){
					this.getModel("timeEvents").deleteCreatedEntry(context);
				}
			};
			
			var datetime = this.viewModel.getProperty("/datetime");
			// Unshift from UTC
			var persistDatetime = new Date(datetime.getTime());
			persistDatetime.setFullYear(datetime.getUTCFullYear(), datetime.getUTCMonth(), datetime.getUTCDate());
			persistDatetime.setHours(datetime.getUTCHours(), datetime.getUTCMinutes(), datetime.getUTCSeconds());
			context = this.getModel("timeEvents").createEntry("/TimeEventSet", {
				properties: {
					EmployeeID: this.viewModel.getProperty("/employeeNumber"),
					EventDate: persistDatetime,
					EventTime: timeFormatter.format(persistDatetime),
					TimeType: "P01", // Hard Coded for Clock In/Clock Out event
					TimezoneOffset: (0 - (datetime.getTimezoneOffset() / 60)).toFixed(2),
					Note: this.viewModel.getProperty("/note")
				},
				success: onSuccess.bind(this),
				error: onError.bind(this)
			});
			
			// Execute the create
			this.viewModel.setProperty("/busy", true);
			this.getModel("timeEvents").submitChanges();
		},

		navigateBack: function() {
			var history = History.getInstance();
			var prevHash = history.getPreviousHash();

			if (prevHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true /*no history*/);
			}
		},
			
		navigateToPunchDetails: function (evt) {
			var ctx = evt.getSource().getBindingContext("viewModel");
			var oViewModel = this.getModel("viewModel");
			var date = oViewModel.getProperty("date", ctx);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("punchDetails", {
				employeeId: this.employeeNumber,
				date: date.getTime()
			});
		}
	});
});