sap.ui.define(
[
	"dart/hcm/timeevtmgr/controller/BaseController",
	"dart/hcm/timeevtmgr/model/ClockEventEmployeeSummary",
	"dart/hcm/timeevtmgr/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], 
function(
	BaseController,
	ClockEventEmployeeSummary,
	Formatters,
	JSONModel,
	Filter,
	FilterOperator,
	Sorter
) {
	"use strict";

	return BaseController.extend("dart.hcm.timeevtmgr.controller.Punches", {
		formatters: Formatters,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf dart.hcm.timeevtmgr.view.Punches
		 */
		onInit: function() {
			this.getRouter().attachRouteMatched(this.attachRouteMatched, this);
			/** @type {Date|null} */
			this.startDate = null;
			/** @type {Date|null} */
			this.endDate = null;
			/** @type {string} */
			this.employeeNumber = "";
			/** @type {JSONModel} */
			this.viewModel = new JSONModel({
				results: null,
				busy: true,
				timeRange: "",
				employeeName: "",
				employeeNumber: ""
			});
			
			this.setModel(this.viewModel, "viewModel");
		},
		
		attachRouteMatched: function (evt) {
			var params = evt.getParameters();
			if (params.name === "punches") {
				if (params.arguments["?query"]) {
					this.startDate = new Date(parseInt(params.arguments["?query"].startDate, 10));
					this.endDate = new Date(parseInt(params.arguments["?query"].endDate, 10));
					this.subordinateType = params.arguments["?query"].subordinateType;
				}
				// Get employee info
				this.employeeNumber = params.arguments.employeeNumber;
				this.viewModel.setProperty("/employeeNumber", this.employeeNumber);

				// Kick of the Async Data
				this.requestData();
				
				var dayFormatter = sap.ui.core.format.DateFormat.getDateInstance({
					UTC: true,
					style: "short"	
				});
				if (this.startDate.getTime() === this.endDate.getTime()) {	
					this.viewModel.setProperty("/timeRange", dayFormatter.format(this.startDate));
				} else {
					this.viewModel.setProperty("/timeRange", dayFormatter.format(this.startDate) + " - " + dayFormatter.format(this.endDate));
				}
			}
		},
		
		requestData: function () {
			var model = this.getModel();
			var filters = this._getFilters();
			this.viewModel.setProperty("/busy", true);
			model.read("/ActualVsPaid", {
				filters: filters,
				sorters: [
					new Sorter("EmployeeName", /** bDesc */ false)
				],
				success: this.receiveData.bind(this),
				error: this.receiveError.bind(this)
			});
		},
		
		receiveData: function (data) {
			var results = ClockEventEmployeeSummary.parseResults(data.results);
			this.viewModel.setProperty("/employeeName", results[0].employeeName);
			this.viewModel.setProperty("/results", results[0]);
			this.viewModel.setProperty("/busy", false);
		},
		
		receiveError: function (err) {
			this.viewModel.setProperty("/busy", false);
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 * @return {Filter[]} An array of filters to apply to GET requests
		 */
		_getFilters: function() {
			return [
				new Filter({
					path: "StartDate",
					operator: FilterOperator.EQ,
					value1: this.startDate
				}),
				new Filter({
					path: "EndDate",
					operator: FilterOperator.EQ,
					value1: this.endDate
				}),
				new Filter({
					path: "EmployeeNum",
					operator: FilterOperator.EQ,
					value1: this.employeeNumber
				}),
				new Filter({
					path: "SubGroupExclusion",
					operator: FilterOperator.EQ,
					value1: "ActualPaid"
				})
			];
		},
		
		navigateToPunchDetails: function (evt) {
			var ctx = evt.getSource().getBindingContext("viewModel");
			var oViewModel = this.getModel("viewModel");
			var date = oViewModel.getProperty("date", ctx);
			// Switch from UTC to current Timezone
			var navDate = new Date(
				date.getUTCFullYear(),
				date.getUTCMonth(),
				date.getUTCDate(),
				0, 
				0, 
				0, 
				0
			);

			var oRouter = this.getRouter();
			oRouter.navTo("punchDetails", {
				employeeNumber: this.employeeNumber,
				query: {
					start: navDate.getTime(),
					end: navDate.getTime(),
					subordinateType: this.subordinateType
				}
			});
		}
	});
});