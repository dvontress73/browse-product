sap.ui.define([
  "dart/hcm/timeevtmgr/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/routing/History",
  "dart/hcm/timeevtmgr/model/formatter",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter",
  "dart/hcm/timeevtmgr/utils/ExportBuilder",
  "dart/hcm/timeevtmgr/model/ClockEventEmployeeSummary",
  "dart/hcm/core/SubordinateType"
], function (
  BaseController,
  JSONModel,
  History,
  formatter,
  Filter,
  FilterOperator,
  Sorter,
  ExportBuilder,
  ClockEventEmployeeSummary,
  SubordinateType) {
  "use strict";

  return BaseController.extend("dart.hcm.timeevtmgr.controller.DetailedAvp", {

    formatter: formatter,
    /* =========================================================== */
    /* lifecycle methods                                           */
    /* =========================================================== */

    /**
     * Called when the DetailedAvp controller is instantiated.
     * @public
     */
    onInit: function () {
      var oTable = this.byId("table");

      this._oTable = oTable;
      // keeps the search state
      this._oTableSearchState = [];

      var initialDate = new Date();
      initialDate.setHours(0);
      initialDate.setMinutes(0);
      initialDate.setSeconds(0);
      initialDate.setMilliseconds(0);
      initialDate.setDate(initialDate.getDate() - initialDate.getDay());

      var endDate = new Date(initialDate.getTime());
      endDate.setDate(endDate.getDate() + 6);

      // Model used to manipulate control states
      /** @type {JSONModel} */
      this.viewModel = new JSONModel({
        filters: {
          startDate: initialDate,
          endDate: endDate,
          employeeNumber: null,
          subordinateType: SubordinateType.DIRECT,
          subordinateFilter: this.getSubordinateFilter()
        },
        rawData: null,

        activePickMode: "DAY",
        pickerModes: [{
          key: "DAY",
          text: "By Day"
        }, {
          key: "CUSTOM",
          text: "Custom Range"
        }],
        //ADO273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
        SubordinateTypeSelected: true,
        scope: "",
        subordinateType: SubordinateType.DIRECT,
        subordinateTypes: [{
          key: SubordinateType.DIRECT,
          text: "Direct"
        }, {
          key: SubordinateType.INDIRECT,
          text: "Indirect"
        }, {
          key: SubordinateType.DELEGATE,
          text: "Delegate"
        }, {
          key: SubordinateType.ALL,
          text: "All"
        }],

        hasMissingPunch: false
      });
      this.setModel(this.viewModel, "viewModel");

      this.getRouter().attachRouteMatched(this.attachRouteMatched, this);
    },

    attachRouteMatched: function (evt) {
      var params = evt.getParameters();
      if (params.name === "detailedAVPReport") {
        if (params.arguments["?query"]) {
          var startDate = new Date(parseInt(params.arguments["?query"].startDate, 10));
          var endDate = new Date(parseInt(params.arguments["?query"].endDate, 10));

          var employeeNumber = params.arguments["?query"].employeeNumber;
          var subordinateType = params.arguments["?query"].subordinateType;

          this.viewModel.setProperty("/filters/startDate", startDate);
          this.viewModel.setProperty("/filters/endDate", endDate);
          if (employeeNumber) {
            this.viewModel.setProperty("/filters/employeeNumber", employeeNumber);
          }
          if (subordinateType) {
            this.viewModel.setProperty("/filters/subordinateType", subordinateType);
          }
        }
      }

      this.requestData();
    },

    /* =========================================================== */
    /* data handlers                                              */
    /* =========================================================== */

    /**
     * Intiates an API request for remote data.
     * Manages busy state switch and wires up the
     * success and error handlers
     */
    requestData: function () {
      this.viewModel.setProperty("/tableBusy", true);

      var model = this.getModel();
      var filters = this._getFilters();

      model.read("/ActualVsPaid", {
        filters: filters,
        sorters: [
          new Sorter("EmployeeName", /** bDesc */ false),
          new Sorter("PunchDate", false)
        ],
        success: this.receiveData.bind(this),
        error: this.receiveError.bind(this)
      });
    },

    /**
     * Accepts Successfule request of data
     * Handles the controller state and data transormations.
     * @param {object} data returned from an API request
     */
    receiveData: function (data) {
      this.viewModel.setProperty("/rawData", data.results);
      this.viewModel.setProperty("/tableBusy", false);
    },

    receiveError: function (data) {
      this.viewModel.setProperty("/tableBusy", false);
    },

    /* =========================================================== */
    /* event handlers                                              */
    /* =========================================================== */

    /**
     * Event handler for refresh event. Keeps filter, sort
     * and group settings and refreshes the list binding.
     * @public
     */
    onRefresh: function () {
      this._oTable.getBinding("items").refresh();

      this.requestData();
    },

    handleChange: function (evt) {
      var params = evt.getParameters();
      this.getRouter()
        .navTo(
          "detailedAVPReport", {
            query: this._buildNavQuery(params)
          });
    },

    // Begin Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
    handleSubordinateChange: function (evt) {
      var params = evt.getParameters();
      this.getRouter()
        .navTo(
          "detailedAVPReport", {
            query: this._buildSubordinateQuery(params)
          });
    },
   
    // End Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App

    _buildNavQuery: function (params) {
      params = params || {};
      var query = {
        startDate: params.start || this.viewModel.getProperty("/filters/startDate").getTime(),
        endDate: params.end || this.viewModel.getProperty("/filters/endDate").getTime(),
        subordinateType: params.subordinateType || this.viewModel.getProperty("/filters/subordinateType")
      };

      var employeeNum = params.employeeNumber || this.viewModel.getProperty("/filters/employeeNumber");
      if (employeeNum) {
        query.employeeNumber = employeeNum;
      }

      return query;
    },

    onDownload: function () {
      // Custom Module to use builder pattern for csv generation
      var builder = new ExportBuilder(this.viewModel, "/rawData");

      return builder
        .addColumn(this.getResourceBundle().getText("tableNumberColumnTitle"), "EmployeeNum")
        .addColumn(this.getResourceBundle().getText("tableNameColumnTitle"), "EmployeeName")
        .addColumn(this.getResourceBundle().getText("tablePunchDateColumnTitle"), {
          path: "PunchDate",
          type: "sap.ui.model.type.Date",
          formatOptions: {
            style: "short",
            UTC: true
          }
        })
        .addColumn(this.getResourceBundle().getText("tableAssignedWorkScheduleColumnTitle"), "WSRuleDescription")
        .addColumn(this.getResourceBundle().getText("tablePlannedColumnTitle"), "PlannedWorkingHours")
        .addColumn(this.getResourceBundle().getText("tableActualColumnTitle"), "ActualEvaluatedHours")
        .addColumn(this.getResourceBundle().getText("tableActualMinuteColumnTitle"), "ActualEvaluatedMinutes")
        .addColumn(this.getResourceBundle().getText("tableExceptionCodeColumnTitle"), "ExceptionCodes")
        .addColumn(this.getResourceBundle().getText("tableInColumnTitle"), "Clockin1")
        .addColumn(this.getResourceBundle().getText("tableOutColumnTitle"), "Clockout1")
        .addColumn(this.getResourceBundle().getText("tableInColumnTitle"), "Clockin2")
        .addColumn(this.getResourceBundle().getText("tableOutColumnTitle"), "Clockout2")
        .addColumn(this.getResourceBundle().getText("tableInColumnTitle"), "Clockin3")
        .addColumn(this.getResourceBundle().getText("tableOutColumnTitle"), "Clockout3")
        .addColumn(this.getResourceBundle().getText("tableInColumnTitle"), "Clockin4")
        .addColumn(this.getResourceBundle().getText("tableOutColumnTitle"), "Clockout4")
        .addColumn(this.getResourceBundle().getText("tableAATypeColumnTitle"), "AbsenceDetailType")
        .download();
    },

    navigateToPunches: function (evt, employeeNumber) {
      var ctx = evt.getSource().getBindingContext("viewModel");
      var startDate = this.viewModel.getProperty("/filters/startDate");
      var endDate = this.viewModel.getProperty("/filters/endDate");

      var employeNum = employeeNumber || this.viewModel.getProperty("EmployeeNum", ctx);
      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      oRouter.navTo("punches", {
        employeeNumber: employeNum,
        query: {
          startDate: startDate.getTime(),
          endDate: endDate.getTime()
        }
      });
    },

    navigateToPunchDetails: function (evt) {
      var employeeNumber = this.viewModel.getProperty("/filters/employeeNumber");
      if (employeeNumber) {
        this.navigateToPunches(evt, employeeNumber);
      }

      var router = this.getRouter();
      var startDate = this.viewModel.getProperty("/filters/startDate");
      var endDate = this.viewModel.getProperty("/filters/endDate");
      router.navTo("punchMultiDetails", {
        query: {
          start: startDate.getTime(),
          end: endDate.getTime(),
          subordinateType: this.viewModel.getProperty("/filters/subordinateType")
        }
      });
    },

    navToNewAvp: function () {
      this.getRouter().navTo("worklist", {
        query: this._buildNavQuery()
      });
    },

    /* =========================================================== */
    /* internal methods                                            */
    /* =========================================================== */

    /**
     * Internal helper method to apply both filter and search state together on the list binding
     * @param {object} oTableSearchState an array of filters for the search
     * @private
     * @return {Filter[]} An array of filters to apply to GET requests
     */
    _getFilters: function () {
      var filters = [
        new Filter({
          path: "StartDate",
          operator: FilterOperator.EQ,
          value1: this._dateForFilter(this.viewModel.getProperty("/filters/startDate"))
        }),
        new Filter({
          path: "EndDate",
          operator: FilterOperator.EQ,
          value1: this._dateForFilter(this.viewModel.getProperty("/filters/endDate"))
        }),
        new Filter({
          path: "SubGroupExclusion",
          operator: FilterOperator.EQ,
          value1: "ActualPaid"
        })
      ];

      if (this.viewModel.getProperty("/filters/employeeNumber")) {
        filters.push(new Filter({
          path: "EmployeeNum",
          operator: FilterOperator.EQ,
          value1: this.viewModel.getProperty("/filters/employeeNumber")
        }));
      }

      var type = this.viewModel.getProperty("/filters/subordinateType");
      if (type !== SubordinateType.ALL) {
        var value = "MSS_TMV_EE_ALL";
        if (type === SubordinateType.DIRECT) {
          value = "MSS_TMV_EE_DIR";
        }
        if (type === SubordinateType.INDIRECT) {
          value = "MSS_TMV_EE_IND";
        }
        // Begin Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
        if (type === SubordinateType.DELEGATE) {
          value = "MSS_TMV_EE_DEL";
        }

        filters.push(new Filter({
          path: "Selection",
          operator: FilterOperator.EQ,
          value1: value
        }));
      }

      return filters;
    },
    _setDates: function (date) {
      this.getRouter()
        .navTo(
          "detailedAVPReport", {
            query: {
              startDate: date.getTime(),
              endDate: date.getTime()
            }
          });
    },
    // Begin Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
     _buildSubordinateQuery: function (params) {
     params = params || {};
      var query = {
        startDate: params.start || this.viewModel.getProperty("/filters/startDate").getTime(),
        endDate: params.end || this.viewModel.getProperty("/filters/endDate").getTime(),
        subordinateType: params.subordinateType || this.viewModel.getProperty("/filters/subordinateType")
      };
      return query;
    }
    // End Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
  });
});