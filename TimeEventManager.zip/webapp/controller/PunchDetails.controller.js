sap.ui.define(
  [
    "dart/hcm/timeevtmgr/controller/BaseController",
    "dart/hcm/timeevtmgr/model/ClockEventEmployeeSummary",
    "dart/hcm/timeevtmgr/model/ClockEventDailySummary",
    "dart/hcm/timeevtmgr/model/ClockEvent",
    "dart/hcm/timeevtmgr/utils/DeleteDialog",
    "sap/ui/model/Context",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/ui/core/routing/HashChanger",
    "sap/m/MessageBox",
    "sap/m/ResponsivePopover",
    "sap/m/Text",
    "dart/hcm/core/SubordinateType",
    "sap/m/MessageToast",
    "dart/hcm/timeevtmgr/model/ExceptionCodes"
  ],
  function (
    BaseController,
    ClockEventEmployeeSummary,
    ClockEventDailySummary,
    ClockEvent,
    DeleteDialog,
    Context,
    JSONModel,
    Filter,
    FilterOperator,
    Sorter,
    HashChanger,
    MessageBox,
    ResponsivePopover,
    Text,
    SubordinateType,
    MessageToast,
    ExceptionCodes
  ) {
    "use strict";

    return BaseController.extend("dart.hcm.timeevtmgr.controller.PunchDetails", {

      /**
       * Called when a controller is instantiated and its View controls (if available) are already created.
       * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
       * @memberOf dart.hcm.timeevtmgr.view.Punches
       */
      onInit: function () {
      	this.pernr = "";
        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.attachRouteMatched(this.attachRouteMatched, this);
        /** @type {Date|null} */
        this.date = null;
        /** @type {string} */
        this.activeRoute = "";
        /** @type {JSONModel} */
        this.viewModel = new JSONModel({
          results: [],
          busy: true,
          date: "",
          startDate: new Date(),
          endDate: new Date(),
          employeeNumber: "",
          scope: "",
          missingPunchReview: true,
          problemPunchesOnly: false,
          rawData: null,
          subordinateType: SubordinateType.DIRECT,
          subordinateTypes: [{
            key: SubordinateType.DIRECT,
            text: "Direct"
          }, {
            key: SubordinateType.INDIRECT,
            text: "Indirect"
          }, {
            key: SubordinateType.DELEGATE,
            text: "Delegate"
          }, {
            key: SubordinateType.ANY,
            text: "Any"
          }],
          deleteComment: "",
          showPunchDates: false
        });

        /** @type {ClockEventEmployeeSummary[]} */
        this.results = null;

        this.setModel(this.viewModel, "viewModel");

        this.hashChanger = new HashChanger();

        this.validationQueue = [];
      },

      formatters: {
        eventToStatus: function (hasError, hasWarning) {
          if (hasError) {
            return "Error";
          }

          if (hasWarning) {
            return "Warning";
          }

          return "None";
        }
      },

      attachRouteMatched: function (evt) {
      	this.pernr = "";
        var routes = ["punchDetails", "punchMultiDetails"];
        var params = evt.getParameters();

        // Exit non-matching routes quick because UI5 routing is poorly designed
        if (routes.indexOf(params.name) === -1) {
          return;
        }

        if (params.arguments["?query"].scrollPosition) {
          this.scrollPosition = parseInt(params.arguments["?query"].scrollPosition, 10);
        }

        this.activeRoute = params.name;

        var dayFormatter = sap.ui.core.format.DateFormat.getDateInstance({
          style: "short",
          UTC: true
        });

        // Reset View Vars
        var missingPunchReview = true;
        var employeeNumber = "";
        var start = new Date(parseInt(params.arguments["?query"].start, 10)) || new Date();
        var end = new Date(parseInt(params.arguments["?query"].end, 10)) || new Date();

        // Check if a subordinate type is set
        var subordinateType = params.arguments["?query"].subordinateType;
        if (subordinateType) {
          this.viewModel.setProperty("/subordinateType", subordinateType);
        }
        // Set Vars based on route
        if (params.name === "punchDetails") {
          employeeNumber = params.arguments.employeeNumber || "";
          missingPunchReview = false;
        }

        if (params.name === "punchMultiDetails") {
          if (params.arguments["?query"]) {
            this.viewModel.setProperty("/scope", "Punch Report");
          }
        }

        // Setup view model;
        this.viewModel.setProperty("/startDate", start);
        this.viewModel.setProperty("/endDate", end);
        this.viewModel.setProperty("/missingPunchReview", missingPunchReview);
        this.viewModel.setProperty("/problemPunchesOnly", missingPunchReview);
        this.viewModel.setProperty("/employeeNumber", employeeNumber);
        if (start.getTime() === end.getTime()) {
          this.viewModel.setProperty("/timerange", dayFormatter.format(start));
        } else {
          this.viewModel.setProperty("/timerange", dayFormatter.format(start) + " - " + dayFormatter.format(end));
        }

        // Kick of the Async Data
        this.requestData();
      },

      requestData: function (pernr) {
        this.validationQueue = [];
        this.viewModel.setProperty("/busy", true);
        this.viewModel.setProperty("/results", []);
        this.viewModel.setProperty("/showPunchDates", false);
        var self = this;
        this.getModel().read("/ActualVsPaid", {
          filters: this._getFilters(),
          sorters: [
            new Sorter("EmployeeName", /** bDesc */ false),
            new Sorter("PunchDate", false)
          ],
          error: this.receiveError.bind(this),
          success: function (avpData) {
            var groupedAvp = {};

            avpData.results.forEach(function (avp) {
              if (!groupedAvp[avp.EmployeeNum]) {
                groupedAvp[avp.EmployeeNum] = [];
              }

              groupedAvp[avp.EmployeeNum].push(avp);
            });

            if (Object.keys(groupedAvp).length === 1) {
              var str = avpData.results[0].EmployeeName +
                "(" +
                avpData.results[0].WSRuleDescription +
                ")";
              self.viewModel.setProperty("/scope", str);
            }

            Object.keys(groupedAvp).forEach(function (key) {
              var endDate = new Date(self.viewModel.getProperty("/endDate").getTime());
              endDate.setDate(endDate.getDate() + 1);
              self.getModel("timeEvents").read("/TimeEventSet", {
                filters: [
                  new Filter({
                    path: "DateFrom",
                    operator: FilterOperator.EQ,
                    value1: self.viewModel.getProperty("/startDate")
                  }),
                  new Filter({
                    path: "DateTo",
                    operator: FilterOperator.EQ,
                    value1: endDate
                  }),
                  new Filter({
                    path: "EmployeeID",
                    operator: FilterOperator.EQ,
                    value1: key
                  })
                ],
                success: self.massageData.bind(self, groupedAvp[key]),
                groupId: "PunchDetails"
              });
            });
          }
        });
      },

      massageData: function (avpData, data) {
        var results = [];
        var previousDayIndicators = ["<", "-"];
        var massagedData = data.results.map(function (r) {
          r.schedule = avpData[0].WSRuleDescription;
          r.employeeName = avpData[0].EmployeeName;

          if (previousDayIndicators.indexOf(r.DayAssignment) > -1) {
            var oneDayAgo = 24 * 60 * 60 * 1000; // 24 hours ago in ms
            r.PayDate = new Date(r.EventDate.getTime() - oneDayAgo);
          } else {
            r.PayDate = new Date(r.EventDate.getTime());
          }

          r.EventDate.setUTCMilliseconds(r.EventTime.ms);
          return r;
        }, this);

        var startDate = this.viewModel.getProperty("/startDate").getTime();
        var endDate = this.viewModel.getProperty("/endDate").getTime();

        var msInDay = 24 * 60 * 60 * 1000;
        var numberOfDays = Math.round((endDate - startDate) / (msInDay)) + 1;

        for (var i = 0; i < numberOfDays; i++) {
          var date = startDate + (msInDay * i);
          var form = this.createFormEvent(date, avpData);
          var shouldAdd = !this.viewModel.getProperty("/problemPunchesOnly") || form.hasError;

          if (shouldAdd) {
            // need to subtract a day because of UTC and display issues.
            var compareDate = new Date(date);
            compareDate.setUTCHours(0);
            var dataForDate = massagedData.filter(function (d) {
              return d.PayDate.getTime() === compareDate.getTime();
            });

            dataForDate.sort(function (a, b) {
              if (!b.EventDate) {
                return -1;
              }

              if (!a.EventDate) {
                return 1;
              }

              if (a.EventDate.getTime() > b.EventDate.getTime()) {
                return 1;
              }

              if (a.EventDate.getTime() < b.EventDate.getTime()) {
                return -1;
              }

              return 0;
            });

            results = results.concat(dataForDate);
            results.push(form);
          }
        }

        this.viewModel.setProperty("/busy", false);
        var alreadySetResults = this.viewModel.getProperty("/results");
        this.viewModel.setProperty("/results", alreadySetResults.concat(results));
        this.viewModel.setProperty("/busy", true);
        if (!this.viewModel.getProperty("/showPunchDates")) {
          for (var j = 0; j < results.length; j++) {
            var payDate = results[j].PayDate;
            var punchDate = results[j].EventDate;
            if (!!payDate && !!punchDate &&
              (payDate.getFullYear() !== punchDate.getFullYear() ||
                payDate.getMonth() !== punchDate.getMonth() ||
                payDate.getUTCDate() !== punchDate.getUTCDate())) {

              this.viewModel.setProperty("/showPunchDates", true);
            }
          }
        }
        var that = this;
        jQuery.sap.delayedCall(500, null, function () {
          that.viewModel.setProperty("/busy", false);
          if (that.scrollPosition) {
            that.byId("PunchDetailPage")
              .getDomRef()
              .firstChild
              .firstChild
              .scrollTop = that.scrollPosition;
          }
        });
      },
      createFormEvent: function (date, avpData) {
        var avp;
        var compareDate = new Date(date);
        compareDate.setUTCHours(0);
        for (var i = 0; i < avpData.length; i++) {
          if (compareDate.getTime() === avpData[i].PunchDate.getTime()) {
            avp = avpData[i];
            break;
          }
        }

        var formEvent = {
          type: "Form",
          formIsOpen: false,
          PayDate: new Date(date),
          formDate: null,
          schedule: avpData[0].WSRuleDescription,
          employeeName: avpData[0].EmployeeName,
          employeeNum: avpData[0].EmployeeNum,
          avp: avp
        };

        if (avp) {
          var exceptionCodes = avp.ExceptionCodes;

          if (avp.AbsenceDetailType === "ABS") {
            exceptionCodes += " ABS";
          }

          var exceptions = ExceptionCodes.parse(exceptionCodes);
          formEvent.hasError = exceptions.filter(function (e) {
            return e.level === 3;
          }).length > 0;
          formEvent.hasWarning = exceptions.filter(function (e) {
            return e.level === 2;
          }).lenght > 0;
          formEvent.exceptionsString = exceptions.filter(function (e) {
            return e.level > 1;
          }).map(function (e) {
            return e.text;
          }).join(",");
        }

        return formEvent;
      },
      _validateCanDeleteAsync: function (ctx, groupId) {
        var checker = this.getModel("timeCheck");
        var employeeNumber = this.viewModel.getProperty("employeeNumber", ctx);
        var datetime = this.viewModel.getProperty("datetime", ctx);
        if (!employeeNumber) {
          return;
        }

        var entityPath = checker.createKey("/EmployeeSet", {
          Pernr: employeeNumber,
          ClockDate: datetime
        });

        var onSuccess = function (data) {
          var isValid = data.PayrollCheck === ""; // Obscure as can be
          this.viewModel.setProperty("canDelete", isValid, ctx);
        };

        checker.read(entityPath, {
          success: onSuccess.bind(this),
          groupId: groupId
        });
      },

      receiveData: function (data) {
        this.viewModel.setProperty("/rawData", data);
        var results = ClockEventEmployeeSummary.parseResults(data.results);

        var punches = this._flattenResults(results);

        if (punches.length) {
          this.viewModel.setProperty("/results", punches);
        } else {
          this.viewModel.setProperty("/results", null);
        }
        this.viewModel.setProperty("/busy", false);
      },

      receiveError: function (err) {
        this.viewModel.setProperty("/busy", false);
      },

      handleMissingPunchToggle: function () {
        this.requestData();
      },

      onSubordinateChange: function () {
        var routeParams = {
          query: {
            start: this.viewModel.getProperty("/startDate").getTime(),
            end: this.viewModel.getProperty("/endDate").getTime(),
            subordinateType: this.viewModel.getProperty("/subordinateType")
          }
        };

        this.getRouter()
          .navTo("punchMultiDetails", routeParams, false);
      },

      createLeave: function (evt) {
        var subordinateType = this.viewModel.getProperty("/subordinateType");
        var bindingPath = evt
          .getSource()
          .getParent()
          .getParent()
          .getBindingContextPath();
        var data = this.viewModel.getProperty(bindingPath);
        var timestamp = (data.PayDate || new Date()).getTime();

        var route = "punchDetails";
        if (this.viewModel.getProperty("/missingPunchReview")) {
          route = "punchMultiDetails";
        }

        this.getRouter().navTo(route, {
          employeeNumber: this.viewModel.getProperty("/employeeNumber"),
          query: {
            start: this.viewModel.getProperty("/startDate").getTime(),
            end: this.viewModel.getProperty("/endDate").getTime(),
            subordinateType: subordinateType,
            scrollPosition: this.getScrollPosition()
          }
        });

        this.hashChanger.setHash("LeaveRequest-obo&/employee/" + data.employeeNum + "/create?employeeType=" + subordinateType +
          "&timestamp=" + timestamp);
      },

      deleteEvent: function (evt) {
        var dialog;

        // Reset comment
        this.viewModel.setProperty("/deleteComment", "");

        // Get the data for clock event
        var bindingPath = evt
          .getSource()
          .getParent()
          .getParent()
          .getBindingContextPath();
        var data = this.viewModel.getProperty(bindingPath);
        if (!data.ReqId) {
          jQuery.sap.log.error("Clock Event does not have a matching Request ID");
          return;
        }
        var model = evt.getSource().getBindingContext("viewModel");
        var rowPath = model.sPath.split("/results/");
        var delRowNumber = parseInt(rowPath[1]);

        // Build TimeEventSet key
        var model = this.getModel("timeEvents");
        var key = model.createKey("TimeEventSet", {
          EmployeeID: data.EmployeeID,
          ReqId: data.ReqId
        });

        // Error any of the steps
        var onError = function (err) {
          dialog.close();
          if (err.responseText) {
            var response = JSON.parse(err.responseText);
            if (response.error) {
              MessageBox.error(response.error.message.value);
            }
          }
          jQuery.sap.log.error(
            "An error occurred while removing LeaveRequest",
            err
          );
        };

        // 4. Handle response
        // var onDeleted = function () {
        //   dialog.close();
        //   this.requestData();
        // };
        var that = this;
        var oViewModel = this.viewModel.getProperty("/results");
        this.deleteEvent = true;
        var onDeleted = function () {
          dialog.close();
			oViewModel.splice(delRowNumber, 1);
			that.viewModel.setProperty("/results",[]);
			that.viewModel.setProperty("/results",oViewModel);
        };

        // 3. Run delete operation
        var onUpdate = function () {
          model.remove("/" + key, {
            success: onDeleted.bind(this),
            error: onError.bind(this)
          });

          model.submitChanges();
        };

        // 2. Update Note
        var onConfirm = function () {
          model.update(
            "/" + key, {
              Note: this.viewModel.getProperty("/deleteComment")
            }, {
              success: onUpdate.bind(this),
              error: onError.bind(this)
            });

          model.submitChanges();
        };

        dialog = new DeleteDialog({
          text: "Are you sure you want to remove this Clock In / Clock Out event.",
          model: this.viewModel,
          formPlaceholder: "Add note (required)",
          value: {
            path: "/deleteComment"
          },
          enabled: {
            path: "/deleteComment",
            formatter: function (cmt) {
              return !!cmt && cmt.length > 2;
            }
          },
          deleteCallback: onConfirm.bind(this)
        });

        // 1. Open the dialog.
        dialog.open();
      },

      onDateRangeChange: function (evt) {
        var params = evt.getParameters();
        var employeeNumber = this.viewModel.getProperty("/employeeNumber");
        var query = {
          subordinateType: this.viewModel.getProperty("/subordinateType")
        };

        if (params.start) {
          query.start = new Date(
            params.startDate.getUTCFullYear(),
            params.startDate.getUTCMonth(),
            params.startDate.getUTCDate(),
            params.startDate.getUTCHours(),
            params.startDate.getMinutes()).getTime();
        } else {
          query.start = this.viewModel.getProperty("/startDate").getTime();
        }

        if (params.end) {
          query.end = new Date(
            params.endDate.getUTCFullYear(),
            params.endDate.getUTCMonth(),
            params.endDate.getUTCDate(),
            params.endDate.getUTCHours(),
            params.endDate.getMinutes()).getTime();
        } else {
          query.end = this.viewModel.getProperty("/endDate").getTime();
        }

        var routeParams = {
          query: query
        };

        if (employeeNumber) {
          routeParams.employeeNumber = employeeNumber;
        }

        this.getRouter()
          .navTo(this.activeRoute, routeParams, false);
      },

      showNotes: function (evt) {
        var src = evt.getSource();
        var ctx = src.getParent().getBindingContext("viewModel");

        var txt = new Text({
          text: this.viewModel.getProperty("Note", ctx)
        });
        txt.addStyleClass("sapUiTinyMargin");
        var popover = new ResponsivePopover({
          showHeader: false,
          placement: sap.m.PlacementType.Left,
          content: txt,
          afterClose: function () {
            popover.destroy();
          }
        });
        popover.openBy(src);
      },

      /**
       * Internal helper method to apply both filter and search state together on the list binding
       * @param {object} oTableSearchState an array of filters for the search
       * @private
       * @return {Filter[]} An array of filters to apply to GET requests
       */
      _getFilters: function () {
        if (this.pernr) {
          var employeeNumber = this.pernr;
        } else {
          employeeNumber = this.viewModel.getProperty("/employeeNumber");
        }

        var subordinateType = this.viewModel.getProperty("/subordinateType");
        var startdate = new Date(this.viewModel.getProperty("/startDate").getTime());
        startdate.setDate(startdate.getDate() - 1);

        var enddate = new Date(this.viewModel.getProperty("/endDate").getTime());
        enddate.setDate(enddate.getDate() + 1);
        var filters = [
          new Filter({
            path: "StartDate",
            operator: FilterOperator.EQ,
            value1: this._dateForFilter(startdate)
          }),
          new Filter({
            path: "EndDate",
            operator: FilterOperator.EQ,
            value1: enddate
          }),
          new Filter({
            path: "SubGroupExclusion",
            operator: FilterOperator.EQ,
            value1: "ActualPaid"
          })
        ];

        if (employeeNumber) {
          filters.push(new Filter({
            path: "EmployeeNum",
            operator: FilterOperator.EQ,
            value1: employeeNumber
          }));
        }

        var typeValue = "";
        if (subordinateType === SubordinateType.DIRECT) {
          typeValue = "MSS_TMV_EE_DIR";
        }
        if (subordinateType === SubordinateType.INDIRECT) {
          typeValue = "MSS_TMV_EE_IND";
        }
        if (subordinateType === SubordinateType.DELEGATE) {
          typeValue = "MSS_TMV_EE_DEL";
        }
        if (typeValue !== "") {
          filters.push(new Filter({
            path: "Selection",
            operator: FilterOperator.EQ,
            value1: typeValue
          }));
        }

        return filters;
      },

      submitEvent: function (evt) {
        var context;
        var model = evt.getSource().getBindingContext("viewModel");
        var rowPath = model.sPath.split("/results/");
        this.rowNumber = parseInt(rowPath[1]);
        var submitting = this.viewModel.getProperty("/busy");
        // Exit if in progress
        if (submitting) {
          return;
        }

        var timeFormatter = sap.ui.core.format.DateFormat.getDateInstance({
          pattern: "PTHH'H'mm'M'ss'S'"
        });

        this.scrollPosition = this.getScrollPosition();
		
		//No Longer Required
        var onSuccess = function () {
          MessageToast.show(
            "Clock In / Clock Out successfully created. Entry may not be reflected in Actual vs. Planned report immediately.", {
              closeOnBrowserNavigation: false
            });
          this.viewModel.setProperty("/busy", false);
          this.requestData();
        };
		//No Longer Required
        var onError = function (err) {
          var text;
          try {
            var json = JSON.parse(err.responseText);
            text = json.error.message.value;
          } catch (e) {
            text = err.responseText;
          }
          MessageToast.show(text);
          if (context) {
            this.getModel("timeEvents").deleteCreatedEntry(context);
          }
          this.viewModel.setProperty("/busy", false);
        };

        var date = model.getProperty("formDate");
        var time = model.getProperty("formTime");

        var parsedDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
        var parsedTime = new Date(0, 0, 0, time.getHours(), time.getMinutes());

		//No Longer Required
		
        // context = this.getModel("timeEvents").createEntry("/TimeEventSet", {
        //   properties: {
        //     EmployeeID: model.getProperty("employeeNum"),
        //     EventDate: parsedDate,
        //     EventTime: timeFormatter.format(parsedTime),
        //     TimeType: "P01", // Hard Coded for Clock In/Clock Out event
        //     TimezoneOffset: (0 - (date.getTimezoneOffset() / 60)).toFixed(2),
        //     Note: model.getProperty("note")
        //   },
        //   success: onSuccess.bind(this),
        //   error: onError.bind(this)
        // });
        var empId = model.getProperty("employeeNum");
        this.pernr = empId;
        var payload = {
          "EmployeeID": empId,
          "EventDate": parsedDate,
          "EventTime": timeFormatter.format(parsedTime),
          "TimeType": "P01", // Hard Coded for Clock In/Clock Out event
          "TimezoneOffset": (0 - (date.getTimezoneOffset() / 60)).toFixed(2),
          "Note": model.getProperty("note")
        };
        this.data = payload;
        this.newRow = this.rowNumber - 1;

        // Execute the create
        var that = this;
        this.viewModel.setProperty("/busy", true);
        this.getModel("timeEvents").create("/TimeEventSet", payload, {
          success: function (odata, Response) {
            MessageToast.show(
              "Clock In / Clock Out successfully created. Entry may not be reflected in Actual vs. Planned report immediately.", {
                closeOnBrowserNavigation: false
              });
            that.viewModel.setProperty("/busy", false);
            that.getOnlyOneRecord(that.pernr);
            this.pernr = "";
          },
          error: function (err) {
            var text;
            try {
              var json = JSON.parse(err.responseText);
              text = json.error.message.value;
            } catch (e) {
              text = err.responseText;
            }
            MessageToast.show(text);
            that.viewModel.setProperty("/busy", false);
            this.pernr = "";
          }
        });

        // this.getModel("timeEvents").submitChanges();
      },
      getOnlyOneRecord: function (empId) {

        this.validationQueue = [];
        this.viewModel.setProperty("/busy", true);
        this.viewModel.setProperty("/showPunchDates", false);
        var self = this;
        this.getModel().read("/ActualVsPaid", {
          filters: this._getFilters(),
          sorters: [
            new Sorter("EmployeeName", /** bDesc */ false),
            new Sorter("PunchDate", false)
          ],
          error: this.receiveError.bind(this),
          success: function (avpData) {
            var groupedAvp = {};

            avpData.results.forEach(function (avp) {
              if (!groupedAvp[avp.EmployeeNum]) {
                groupedAvp[avp.EmployeeNum] = [];
              }

              groupedAvp[avp.EmployeeNum].push(avp);
            });
            Object.keys(groupedAvp).forEach(function (key) {
              var endDate = new Date(self.viewModel.getProperty("/endDate").getTime());
              endDate.setDate(endDate.getDate() + 1);
              self.getModel("timeEvents").read("/TimeEventSingleUpdateSet", {
                filters: [
                  new Filter({
                    path: "DateFrom",
                    operator: FilterOperator.EQ,
                    value1: self.viewModel.getProperty("/startDate")
                  }),
                  new Filter({
                    path: "DateTo",
                    operator: FilterOperator.EQ,
                    value1: endDate
                  }),
                  new Filter({
                    path: "EmployeeID",
                    operator: FilterOperator.EQ,
                    value1: key
                  }),
                  new Filter({
                    path: "EventDate",
                    operator: FilterOperator.EQ,
                    value1: self.data.EventDate
                  }),
                 new Filter({
                    path: "EventTime",
                    operator: FilterOperator.EQ,
                    value1: self.data.EventTime
                  })
                ],
                success: self.replaceResultMessage.bind(self, groupedAvp[key]),
                groupId: "PunchDetails"
              });
            });
          }
        });
      },
      replaceResultMessage: function (avpData, data) {

        var previousDayIndicators = ["<", "-"];
        var massagedData = data.results.map(function (r) {
          r.schedule = avpData[0].WSRuleDescription;
          r.employeeName = avpData[0].EmployeeName;

          if (previousDayIndicators.indexOf(r.DayAssignment) > -1) {
            var oneDayAgo = 24 * 60 * 60 * 1000; // 24 hours ago in ms
            r.PayDate = new Date(r.EventDate.getTime() - oneDayAgo);
          } else {
            r.PayDate = new Date(r.EventDate.getTime());
          }

          r.EventDate.setUTCMilliseconds(r.EventTime.ms);
          return r;
        }, this);

        var oModel = this.viewModel.getData().results;
        var formRow = this.rowNumber;

        oModel[formRow].formIsOpen = false;
        oModel[formRow].hasError = true;
        oModel[formRow].formDate = null;
        oModel[formRow].formTime = null;
        oModel[formRow].note = "";
        var newRowToBeAdded = Object.assign(massagedData[0]);

        oModel.splice(this.rowNumber, 0, newRowToBeAdded);
		this.viewModel.setProperty("/results", []);
        this.viewModel.setProperty("/results", oModel);
        var that = this;

          that.viewModel.setProperty("/busy", false);
          if (that.scrollPosition) {
            that.byId("PunchDetailPage")
              .getDomRef()
              .firstChild
              .firstChild
              .scrollTop = that.scrollPosition;
          }

      },
      openForm: function (evt) {
        var bindingContext = evt.getSource().getBindingContext("viewModel");
        this.viewModel.setProperty("formIsOpen", true, bindingContext);
      },
      closeForm: function (evt) {
        var bindingContext = evt.getSource().getBindingContext("viewModel");
        this.viewModel.setProperty("formIsOpen", false, bindingContext);
      },
      getScrollPosition: function () {
        return this.byId("PunchDetailPage")
          .getDomRef()
          .firstChild
          .firstChild
          .scrollTop;
      },
      showAll: function () {
        this.pernr = "";
        this.requestData();
      }

    });
  });