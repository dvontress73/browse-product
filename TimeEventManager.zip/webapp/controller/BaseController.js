sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	Controller,
	MessageBox,
	Filter,
	FilterOperator
) {
	"use strict";

	return Controller.extend("dart.hcm.timeevtmgr.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function () {
			return this.getOwnerComponent()
				.getRouter();
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel : function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		
		createEvent: function (evt) {
			var ctx = evt.getSource().getBindingContext("viewModel");
			var oViewModel = this.getModel("viewModel");
			
			// Dig for a context date, datetime or viewmodel
			var datetime = oViewModel.getProperty("datetime", ctx)
				|| oViewModel.getProperty("date", ctx);

			// If not in context, find date and reset time of day
			if (!datetime) {
				datetime =  oViewModel.getProperty("/datetime")
					|| oViewModel.getProperty("/startDate");

				// Make sure it's a date
				if (datetime) {
					var current = new Date();
					datetime.setHours(current.getHours, current.getMinutes(), current.getSeconds());
				}
			}

			// Look for employeeNumber in ctx and viewModel key
			var employeeNumber = oViewModel.getProperty("employeeNumber", ctx)
				|| oViewModel.getProperty("/employeeNumber");
			var oRouter = this.getRouter();
			
			var options = { query: {} };
			if (employeeNumber) {
				options.query.employeeNumber = employeeNumber;
			}
			if (datetime) {
				options.query.datetime = datetime.getTime();
			}

			oRouter.navTo("createPunch", options);
		},
		
		goHome: function () {
			this.getRouter().navTo("worklist", {}, true /*no history*/);
		},
		
		parseErrorMessage: function (err) {
			var isJson = err.headers["Content-Type"].indexOf("application/json") > -1;

    		if (err.responseText && isJson) {
        		var response = JSON.parse(err.responseText);
        		if (response.error) {
        			MessageBox.error(response.error.message.value);
        		}
    		} else {
    			MessageBox.error(err.responseText);
    		}

		},
		
		getSubordinateFilter: function () {
			return new Filter({
				path: "SubGroupExclusion",
		    	operator: FilterOperator.EQ,
		    	value1: "Exempt"
			});
		},
		
		// send current date as utc date to get correct filters. 
		_dateForFilter: function(date){
			var newDate = new Date(0);
			newDate.setUTCFullYear(date.getFullYear());
			newDate.setUTCMonth(date.getMonth());
			newDate.setUTCDate(date.getDate());
			return newDate.getTime(); 
		}
	});
});