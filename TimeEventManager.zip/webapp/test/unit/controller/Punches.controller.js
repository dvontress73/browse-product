sap.ui.define([
	"dart/hcm/timeevtmgr/controller/Punches.controller",
	"dart/hcm/timeevtmgr/controller/BaseController"
], function(
	PunchesController,
	BaseController
) {
	"use strict";

	QUnit.module("Punches Controller (second screen)", {

		beforeEach: function() {
			this.controller = new PunchesController();
		},

		afterEach: function() {

		}
	});

	QUnit.test("Navigate from 10/31 to 10/31, not 10/1", function(assert) {
		var correctDate = new Date(2019, 9, 31);
		var event = {
			getSource: function(){
				return {
					getBindingContext: function(){
					}
				};
			}
		};
		
		var stub = sinon.stub(this.controller, "getModel");
		stub.returns({
			getProperty: function(){
				return correctDate;
			}
		});
		
		var routerStub = sinon.stub(BaseController.prototype, "getRouter");
		var routerSpy = sinon.spy();
		routerStub.returns({
			navTo: routerSpy
		});
		
		this.controller.navigateToPunchDetails(event);

		assert.equal(
			routerSpy.args[0][1].query.start, 
			correctDate.getTime());
	});
});