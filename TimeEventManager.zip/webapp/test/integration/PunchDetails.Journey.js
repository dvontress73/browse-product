/* global QUnit */

sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/opaQunit",
	"dart/hcm/timeevtmgr/localService/mockserver",
	"dart/hcm/timeevtmgr/test/integration/DummyData",
	"dart/hcm/timeevtmgr/test/integration/pages/PunchDetails.Page"
], function (Opa5, opaTest, mockservers, DummyData, page) {
	"use strict";

	QUnit.module("Punch Details");
	
	Opa5.extendConfig({
		viewName: "Master",
		autoWait: true
	});
	
	opaTest("Handles DST with punches", 
		function(Given, When, Then){
		
		var hash = "/ActualVsPaid/PunchDetails/";
		hash += "000057628431"; // employee number
		hash += "/?start=1572753600000"; //the 3rd of nov to get dst times
		hash += "&end=1572753600000"; //same as start
		
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.timeevtmgr"
			},
			hash: hash
		});
		
		When.onThePunchDetailsPage.iWaitForTheTableToLoad();
		
		Then.onThePunchDetailsPage.iSeeTimeOf("12:42 PM");
		
		Then.iTeardownMyUIComponent();
	});
	
	opaTest("Handles DST when submitting a new punch", 
		function(Given, When, Then){
		
		//given example was a user attempting to add a date for 
		//11/3/2019, and then the screen showing 11/4 12:00am
		var date = new Date(2019,10,3,23,0,0);
		
		var hash = "/ActualVsPaid/PunchDetails/";
		hash += "000057628431"; // employee number
		hash += "/?start=1572753600000"; //the 3rd of nov to get dst times
		hash += "&end=1572753600000"; //same as start
		
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.timeevtmgr"
			},
			hash: hash
		});
		
		When.onThePunchDetailsPage.iSetupASpyForANewPunch();
		
		When.onThePunchDetailsPage.iEnterANewPunchFor(date);
		
		Then.onThePunchDetailsPage.iSubmittedAPunchFor(date);
		
		Then.iTeardownMyUIComponent();
	});
	
	opaTest("Returns to same position in scroll after submitting a new punch", 
		function(Given, When, Then){
		
		var postGet = function(event){
			var newEntries = [];
			for(var i = 1; i <= 49; i++){
				newEntries.push(
					Object.assign(DummyData.AvP(), {
						PunchDate: '/Date(' + (new Date(2019, 11, i + 1)).getTime() + ')/'
					})
				);
			}
			//eslint-disable-next-line sap-no-ui5base-prop
			event.mParameters.oFilteredData.results = newEntries; 
		};
		
		mockservers.actualPaid().attachAfter("GET", postGet, "ActualVsPaid");
			
		var hash = "/ActualVsPaid/PunchDetails/";
		hash += "000057628431"; // employee number
		hash += "/?start=1575176400000"; //the 3rd of nov to get dst times
		hash += "&end=1579323600000"; //same as start 
		
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.timeevtmgr"
			},
			hash: hash
		});
		
		When.onThePunchDetailsPage.iScrollToTheBottom();                    
		
		When.onThePunchDetailsPage.iNoteMyScrollHeight();
		
		When.onThePunchDetailsPage.iEnterANewPunchFor(new Date());
		
		Then.onThePunchDetailsPage.iReturnedToThePreviousScrollHeight();
		
		Then.iTeardownMyUIComponent();
	});
});