jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"sap/ui/test/opaQunit"
	], function (Opa5) {
		"use strict";
	Opa5.extendConfig({
		viewNamespace: "dart.hcm.timeevtmgr.view"
	});

	sap.ui.require([
		"dart/hcm/timeevtmgr/test/integration/PunchDetails.Journey"
	], function () {
	});
});