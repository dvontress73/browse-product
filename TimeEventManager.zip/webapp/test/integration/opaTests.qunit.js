/* global QUnit */
jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
jQuery.sap.require("sap.ui.qunit.qunit-coverage");

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"dart/hcm/timeevtmgr/localService/mockserver",
		"dart/hcm/timeevtmgr/test/integration/AllJourneys"
	], function(mockserver) {
		this.mockServers = mockserver.init();
		
		QUnit.start();
	});
});