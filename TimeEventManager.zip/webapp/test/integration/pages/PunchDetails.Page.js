sap.ui.require([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/actions/Press"
], function(Opa5, AggregationFilled, Properties, Press){
	"use strict";
	
	var spy, scrollTop, entries;
	
	Opa5.createPageObjects({
		onThePunchDetailsPage: {
			actions: {
				iWaitForTheTableToLoad: function(){
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Table",
						matchers: new AggregationFilled({name: "items"})
					});
				},
				iSetupASpyForANewPunch: function(){
					return this.waitFor({
						viewName: "PunchDetails",
						id: "PunchDetailPage",
						success: function(page){
							var model = page.getModel("timeEvents");
							spy = sinon.spy(model, "createEntry");
						}
					});
				},
				iEnterANewPunchFor: function(enteredDate){
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Button",
						matchers: [
							new Properties({
								text: "Enter New Event"
							}),
							function(ele){
								var items = ele.getParent()
									.getParent()
									.getParent()
									.getAggregation("items");
								var isLastItem = items[items.length - 1] === ele.getParent().getParent();
								return isLastItem;
							}
						],
						actions: new Press(),
						success: function(buttons){
							this.waitFor({
								viewName: "PunchDetails",
								controlType: "sap.m.DatePicker",
								success: function(datePickers){
									//format is mm/dd/yy
									var str = (enteredDate.getMonth() + 1)
										.toString()
										.padStart(2, "0");
									str += "/";
									str += enteredDate.getDate()
										.toString()
										.padStart(2, "0");
									str += "/";
									str += enteredDate.getFullYear()
										.toString()
										.slice(2);
									// don't set the one in the header
									// need a better way to filter this.
									datePickers[1].setValue(str);
								}
							});
							
							this.waitFor({
								viewName: "PunchDetails",
								controlType: "sap.m.TimePicker",
								success: function(timePickers) {
									var str = enteredDate.getHours()
										.toString()
										.padStart(2, "0");
									str += ":";
									str += enteredDate.getMinutes()
										.toString()
										.padStart(2, "0");
									timePickers[0].setValue(str);
								}
							});
							
							this.waitFor({
								viewName: "PunchDetails",
								controlType: "sap.m.Button",
								matchers: new Properties({
									text: "Submit New Event"
								}),
								actions: new Press()
							});
						}
					});
				},
				iScrollToTheBottom: function(){
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Table",
						matchers: new AggregationFilled({name: "items"}),
						timeout: 30,
						success: function(tables){
							var table = tables[0].getDomRef();
							table.parentElement.scrollTop = table.scrollHeight;
						}
					});
				},
				iNoteMyScrollHeight: function() {
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Table",
						matchers: new AggregationFilled({name: "items"}),
						success: function(tables){
							var table = tables[0].getDomRef();
							scrollTop = table.parentElement.scrollTop;
						}
					});
				}
			},
			assertions: {
				iSeeTimeOf: function(timeStr){
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Text",
						matchers: new Properties({
							text: timeStr
						}), 
						success: function(){
							Opa5.assert.ok(true);
						}, 
						error: function(){
							Opa5.assert.ok(false, "did not find time of " + timeStr);
						}
					});
				},
				iSubmittedAPunchFor: function(enteredDate){
					return this.waitFor({
						viewName: "PunchDetails",
						id: "PunchDetailPage",
						success: function(){
							Opa5.assert.ok(
								spy.calledOnce,
								"Punch posted"
							);
							
							var model = spy.lastCall.args[1].properties;
							var hasHours = model.EventTime.indexOf(enteredDate.getHours() + "H") > -1;
							var hasMinutes = model.EventTime.indexOf(enteredDate.getMinutes() + "M") > -1;
							
							Opa5.assert.ok(hasHours, "contains correct hour entry");
							Opa5.assert.ok(hasMinutes, "contains correct minutes entry");
						}
					});
				},
				iReturnedToThePreviousScrollHeight: function(){
					return this.waitFor({
						viewName: "PunchDetails",
						controlType: "sap.m.Table",
						matchers: new AggregationFilled({name: "items"}),
						success: function(tables){
							var table = tables[0].getDomRef();
							Opa5.assert.ok(table.parentElement.scrollTop === scrollTop, "scroll height matches");
						}
					});
				}
			}
		}
	});
});