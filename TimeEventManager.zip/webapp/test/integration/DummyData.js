sap.ui.define([], function(){
	return {
		PunchDetails: function(){
			return {
			    "type": "Form",
			    "formIsOpen": false,
			    "PayDate": new Date("2019-12-02T10:00:00.000Z"),
			    "formDate": null,
			    "schedule": "0800 8a430p30U MTWThF",
			    "employeeName": "Test User",
			    "employeeNum": "10000037",
			    "avp": {
					"SubGroupExclusion": "",
					"WSRuleDescription": "0800 8a430p30U MTWThF",
					"ActualEvaluatedHours": "0.00",
					"ActualEvaluatedMinutes": "",
					"AbsenceDetailType": "ABS",
					"Clockin1": "",
					"Clockin2": "",
					"Clockin3": "",
					"Clockin4": "",
					"Clockout1": "",
					"Clockout2": "",
					"Clockout3": "",
					"Clockout4": "",
					"ExceptionCodes": "",
					"StartDate": new Date("2019-12-01T00:00:00.000Z"),
					"EmployeeName": "Test User",
					"Selection": "",
					"EmployeeNum": "10000037",
					"PlannedWorkingHours": "8.00",
					"PunchDate": new Date("2019-12-02T00:00:00.000Z"),
					"EndDate": new Date("2020-01-01T00:00:00.000Z")
			    },
			    "hasError": true,
			    "hasWarning": false,
			    "exceptionsString": "Absent"
			};
		},
		AvP: function(){
			return {
				SubGroupExclusion: "ActualPaid",
				WSRuleDescription: "0800 8a430p30U MTWThF",
				ActualEvaluatedHours: "0.00",
				ActualEvaluatedMinutes: "",
				AbsenceDetailType: "ABS",
				Clockin1: "",
				Clockin2: "",
				Clockin3: "",
				Clockin4: "",
				Clockout1: "",
				Clockout2: "",
				Clockout3: "",
				Clockout4: "",
				ExceptionCodes: "",
				StartDate: "/Date(1572652800000)/",
				EmployeeName: "Dave Cramer",
				Selection: "MSS_TMV_EE_DIR",
				EmployeeNum: "000057628431",
				PlannedWorkingHours: "8.00",
				PunchDate: "/Date(1572912000000)/",
				EndDate: "/Date(1572843600000)/",
				__metadata: {
					id: "/sap/opu/odata/sap/ZHRF_ACTUAL_PAID_SRV/ActualVsPaid(EmployeeNum='000057628431',PunchDate=datetime'2019-11-05T00%3A00%3A00')",
					type: "ZHRF_ACTUAL_PAID_SRV.ActualVsPaid",
					uri: "/sap/opu/odata/sap/ZHRF_ACTUAL_PAID_SRV/ActualVsPaid(EmployeeNum='000057628431',PunchDate=datetime'2019-11-05T00%3A00%3A00')"
				}
			};
		}
	};
});