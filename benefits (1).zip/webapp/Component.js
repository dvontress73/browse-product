sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"dart/hcm/benefits/model/models",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/m/MessageToast"
], function (UIComponent, Device, models, Filter, FilterOperator, dependentUtils, MessageToast) {
	"use strict";

	return UIComponent.extend("dart.hcm.benefits.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.getModel("benefits").read("/welcome_terms_textSet");
			this.getModel("benefits").read("/empSubtypeSet");
			
			//starts with polyfil for IE
			if (!String.prototype.startsWith) {
			    Object.defineProperty(String.prototype, "startsWith", {
			        value: function(search, rawPos) {
			            var pos = rawPos > 0 ? rawPos | 0 : 0;
			            return this.substring(pos, pos + search.length) === search;
			        }
			    });
			}
			
			if(!Array.prototype.sortByAttribute) {
				Object.defineProperty(Array.prototype, "sortByAttribute", {
	    			value: function(attribute) {
	    				return this.sort(function(a, b){
	    					var aVal = a[attribute];
							var bVal = b[attribute];
							
							if(aVal < bVal){
								return -1;
							}
							
							if(bVal < aVal){
								return 1;
							}
							
							return 0;
	    				});
					}
				});
			}
			
			this.setModel(models.createHelpfulLinksModel(), "helpfullinks");
			this.getHelpfulLinks();
			
			dependentUtils.i18n = this.getModel("i18n");
			dependentUtils.benefitsModel = this.getModel("benefits");
			
			this.getModel("benefits").attachRequestCompleted(this.handleSAPMessage.bind(this));
			this.getModel("languageModel").setProperty("/currentLanguage",null);
			this.getModel("languageModel").setProperty("/showAllTabs",false);
			this.getModel("languageModel").setProperty("/en",true);
			this.getModel("languageModel").setProperty("/es",false);
		},
		getHelpfulLinks: function() {
			var languageFilter = new Filter({
				path: "spras",
				operator: FilterOperator.EQ,
				value1: "E"
			});
			this.getModel("benefits").read("/benefits_linkSet", {
				filters: [languageFilter],
				success: this.handleLinks.bind(this)
			});
		},
		handleLinks: function(links) {
			//TAC URL
			var linkArray = links.results.filter(function (l) {
				return l.url_id.startsWith("TAC");
			});
			this.getModel("helpfullinks").setProperty("/links", linkArray);
			
			//BCLF URL
			var bclfArray = links.results.filter(function (l) {
				return l.url_id.startsWith("BCLF");
			});
			this.getModel("helpfullinks").setProperty("/bclfLinks", bclfArray);
			//MetLife URL
			var metLife = links.results.filter(function (l) {
				return l.url_id.startsWith("MET");
			});
			if (metLife.length > 0) {
				this.getModel("helpfullinks").setProperty("/metLife", metLife[0].url);
				this.getModel("helpfullinks").setProperty("/metLifeText", metLife[0].text);
			}
			//SUPP Ins URL
			var suppIns = links.results.filter(function (l) {
				return l.url_id.startsWith("SUPP_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/suppInsLinks", suppIns);
			// if (suppIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/suppIns", suppIns[0].url);
			// }
			//SPLP Ins
			var splpIns = links.results.filter(function (l) {
				return l.url_id.startsWith("SPLP_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/splpInsLinks",splpIns);
			// if (suppIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/splpIns", splpIns[0].url);
			// }
			//DEPC Ins
			var depcIns = links.results.filter(function (l) {
				return l.url_id.startsWith("DEPC_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/depcInsLinks",depcIns);
			// if (depcIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/depcIns", depcIns[0].url);
			// }
			//Medical Url
			var medical = links.results.filter(function (l) {
				return l.url_id.startsWith("AMED_");
			});
			if (medical.length > 0) {
				this.getModel("helpfullinks").setProperty("/AMED", medical);
			}
			var dental = links.results.filter(function (l) {
				return l.url_id.startsWith("DENT_");
			});
			if (dental.length > 0) {
				this.getModel("helpfullinks").setProperty("/DENT", dental);
			}
			var vision = links.results.filter(function (l) {
				return l.url_id.startsWith("VISN_");
			});
			if (vision.length > 0) {
				this.getModel("helpfullinks").setProperty("/VISN", vision);
			}
			//ASK HR URL
			var askHRArray = links.results.filter(function (l) {
				return l.url_id.startsWith("ASK_HR");
			});
			if (askHRArray.length > 0) {
				this.getModel("helpfullinks").setProperty("/askHR", askHRArray[0].url);
			}
			
			
		}, 
		handleSAPMessage: function(event){
			var data = event.getParameter("response"); 
			
			if(data.headers["sap-message"]) {
				MessageToast.show(JSON.parse(data.headers["sap-message"]).message, {
					duration: 5000
				});
			}
		}
	});
});