sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Button",
	"sap/m/FlexBox",
	"sap/m/Slider",
	"sap/m/Text"
], function (Control, Button, FlexBox, Slider, Text) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.SliderWithButtons", {
		metadata: {
			properties: {
				valueIndex: {
					type: "int",
					defaultValue: 0
				},
				enabled: {
					type: "boolean",
					defaultValue: true
				},
				visible: {
					type: "boolean",
					defaultValue: true
				},
				max: {
					type: "int",
					defaultValue: 100
				},
				min: {
					type: "int",
					defaultValue: 0
				}
			},
			aggregations: {
				_slider: {
					type: "sap.m.Slider",
					multiple: false,
					visibility: "hidden"
				},
				_leftButton: {
					type: "sap.m.Button",
					multiple: false,
					visibility: "hidden"
				},
				_rightButton: {
					type: "sap.m.Button",
					multiple: false,
					visibility: "hidden"
				}
			},
			// defaultAggregation: "attributes",
			events: {
				change: {
					parameters: {
						value: {
							type: "int"
						}
					}
				},
				liveChange: {
					parameters: {
						value: {
							type: "int"
						}
					}
				}
			}
		},
		init: function () {
			var rightButton = new Button({
				icon: "sap-icon://add",
				type: "Transparent"
			});
			rightButton.attachPress(function(){
				this.fireEvent("change", {value: this.getValueIndex() + 1});
			}.bind(this));
			this.setAggregation("_rightButton", rightButton);
			
			var leftButton = new Button({
				icon: "sap-icon://less",
				type: "Transparent"
			});
			leftButton.attachPress(function(){
				this.fireEvent("change", {value: this.getValueIndex() - 1});
			}.bind(this));
			this.setAggregation("_leftButton", leftButton);
			
			var slider = new Slider({
				max: this.getProperty("max"),
				min: this.getProperty("min"),
				showHandleTooltip:false
			});
			slider.attachChange(function(event){
				this.fireEvent("change", {value: event.getParameter("value")});
			}.bind(this));
			slider.attachLiveChange(function(event){
				this.fireEvent("liveChange", {value: event.getParameter("value")});
			}.bind(this));
			this.setAggregation("_slider", slider);
		},
		setMax: function(max) {
			this.setProperty("max", max);
			this.getAggregation("_slider").setMax(max);
		},
		setMin: function(min) {
			this.setProperty("min", min);
			this.getAggregation("_slider").setMin(min);
		},
		setValueIndex: function(valueIndex){
			if(valueIndex >= this.getProperty("max")) {
				this.getAggregation("_rightButton").setEnabled(false);
				valueIndex = this.getProperty("max");
			} else {
				this.getAggregation("_rightButton").setEnabled(true);
			}
			
			if(valueIndex <= this.getProperty("min")){
				this.getAggregation("_leftButton").setEnabled(false);
				valueIndex = this.getProperty("min");
			} else {
				this.getAggregation("_leftButton").setEnabled(true); 
			}
			
			this.setProperty("valueIndex", valueIndex);
			this.getAggregation("_slider").setValue(valueIndex);
		},
		renderer: function (oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("sliderWithButtons");
			oRM.writeClasses();
			oRM.write(">");
			
			oRM.write("<div");
			oRM.addClass("sliderWithButtons-sliderArea");
			oRM.writeClasses();
			oRM.write(">");
			
			oRM.renderControl(oControl.getAggregation("_leftButton"));
			
			oRM.write("<div");
			oRM.addClass("sliderWithButtons-sliderArea-slider");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_slider"));
			oRM.write("</div>");
			
			oRM.renderControl(oControl.getAggregation("_rightButton"));
			
			oRM.write("</div>");
			
			oRM.renderControl(oControl.getAggregation("_displayvalue"));
			
			oRM.write("</div>");
		}
	});
});