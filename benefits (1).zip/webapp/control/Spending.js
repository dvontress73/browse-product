sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Text",
	"sap/m/Link",
	"sap/m/Button",
	"sap/m/Input",
	"sap/m/Select",
	"sap/ui/model/json/JSONModel"
], function (Control, Text, Link, Button, Input, Select, JSONModel) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.Spending", {
		metadata: {
			properties: {
				title: {
					type: "string"
				},
				max: {
					type: "string"
				},
				contribution: {
					type: "string"
				},
				enrolled: {
					type: "string"
				},
				frequency: {
					type: "string"
				},
				paycheck: {
					type: "string"
				}

			},
			aggregations: {
				_title: {
					type: "sap.m.Text",
					multiple: false
				},
				_link: {
					type: "sap.m.Link",
					multiple: false
				},
				_button: {
					type: "sap.m.Button",
					multiple: false
				},
				_contributionText: {
					type: "sap.m.Text",
					multiple: false
				},
				_contributionInput: {
					type: "sap.m.Input",
					multiple: false
				},
				_contributionFreq: {
					type: "sap.m.Select",
					multiple: false
				},

				_maxCont: {
					type: "sap.m.Text",
					multiple: false
				},
				_paycheck: {
					type: "sap.m.Text",
					multiple: false
				},
			},
			events: {
				change: {},
				input: {}
			}
		},
		init: function () {
			this.setAggregation("_title", new Text({
				text: this.getTitle()
			}).addStyleClass("bold-text").addStyleClass("planDetails-title"));

			this.setAggregation("_link", new Link({
				text	: "View Plan Details",
				visible : false
			}));

			this.setAggregation("_maxCont", new Text({
				text: this.getMax()
			}));

			this.setAggregation("_paycheck", new Text({
				text: this.getPaycheck()
			}));

			this.setAggregation("_contributionText", new Text({
				text: "Enter your Contribution : "
			}).addStyleClass("bold-text").addStyleClass("planDetails-title"));

			this.setAggregation("_button", new Button({
				text: "Choose",
				width: "225px",
				icon: "sap-icon://border",
				iconFirst: false,
				press: this._onSelect.bind(this)
			}).addStyleClass("sapUiSizeCompact"));

			this.setAggregation("_contributionInput", new Input({
				width: "6rem",
				enabled: false,
				change: this._onAmountInput.bind(this)
			})).addStyleClass("sapUiSizeCompact");

			this.setAggregation("_contributionFreq", new Select({
				width: "8rem",
				enabled: false,
				change: this._onAmountInput.bind(this)
			}).addStyleClass("sapUiSizeCompact"));

			var oFrequency = {
				"frequency": [{
					"id": "A",
					"name": "Annual"
				}, {
					"id": "P",
					"name": "Per-Paycheck"
				}]
			};
			var oJson = new JSONModel(oFrequency);
			var oSelect = this.getAggregation("_contributionFreq");
			oSelect.setModel(oJson, "freq");
			var oItemSelectTemplate = new sap.ui.core.Item({
				key: "{freq>id}",
				text: "{freq>name}"
			});
			oSelect.bindItems("freq>/frequency", oItemSelectTemplate);
		},

		_onAmountInput: function (oEvent) {
			if (oEvent.getSource().getId().indexOf("input") > 1) {
				this.setContribution(oEvent.getSource().getValue());
			} else {
				this.setFrequency(oEvent.getSource().getSelectedKey());
			}
			this.setPaycheck();
			this.fireInput();
		},
		_onSelect: function (oEvent) {
			var oButton = oEvent.getSource();
			if (oButton.getIcon().indexOf("complete") !== -1) {
				oButton.setIcon("sap-icon://border");
			} else {
				oButton.setIcon("sap-icon://complete");
			}

			var oInput = this.getAggregation("_contributionInput");
			if (oInput.getEnabled()) {
				oInput.setEnabled(false);
			} else {
				oInput.setEnabled(true);
			}

			var oSelect = this.getAggregation("_contributionFreq");
			if (oSelect.getEnabled()) {
				oSelect.setEnabled(false);
			} else {
				oSelect.setEnabled(true);
			}
			this.fireEvent("change");

		},
		//Setters are coming in from the view
		setFrequency: function (frequency) {
			this.setProperty("frequency", frequency, true);
			this.getAggregation("_contributionFreq").setSelectedKey(frequency);
		},

		setTitle: function (title) {
			this.setProperty("title", title, true);
			this.getAggregation("_title").setText(title);
		},

		setPaycheck: function (paychecks) {
			if (paychecks) {
				this.setProperty("paycheck", paychecks, true);
			}
			var parser = new sap.ui.model.type.Float();
			var str = "$";
			if (this.getAggregation("_contributionFreq").getSelectedKey() === "A") {
				var calculate = ( parser.parseValue( this.getContribution() || "0", "string") / parser.parseValue(this.getPaycheck() || "0", "string") ).toFixed(2).toString();
				
				//var calculate = ((this.getContribution() / this.getPaycheck()).toFixed(2)).toString();
				str = str + calculate + " per Paycheck";
			} else {
				calculate = ( parser.parseValue( this.getContribution() || "0", "string") * parser.parseValue(this.getPaycheck() || "0", "string") ).toFixed(2).toString();
				
				//calculate = ((this.getContribution() * this.getPaycheck()).toFixed(2)).toString();
				str = str + calculate + " Annually";
			}
			this.getAggregation("_paycheck").setText(str);
		},

		setContribution: function (amount) {
			this.setProperty("contribution", amount, true);
			this.getAggregation("_contributionInput").setValue(amount);
		},
		setMax: function (cont) {
			var str = "Up to $" + cont + " Maximum Contribution";
			this.setProperty("max", str, true);
			this.getAggregation("_maxCont").setText(str);
		},

		setPerPay: function (cont) {
			var str = "$" + cont + " Per Pay Check";
			this.setProperty("perPay", str, true);
			this.getAggregation("_paycheck").setText(str);
		},

		setEnrolled: function (enrolled) {
			this.setProperty("enrolled", enrolled, true);
			if (enrolled) {
				this.getAggregation("_contributionInput").setEnabled(true);
				this.getAggregation("_contributionFreq").setEnabled(true);
				this.getAggregation("_button").setIcon("sap-icon://complete");
			}
		},

		renderer: function (oRM, oControl) {

			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("spendingHeader");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_title"));
			oRM.write("</br>");
			oRM.renderControl(oControl.getAggregation("_link"));
			oRM.write("</div>");

			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("sapUiSizeCompact");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_button"));
			oRM.write("</br>");
			oRM.renderControl(oControl.getAggregation("_contributionText"));
			oRM.write("</br>");
			oRM.renderControl(oControl.getAggregation("_contributionInput"));
			oRM.renderControl(oControl.getAggregation("_contributionFreq"));
			oRM.write("</br>");
			oRM.renderControl(oControl.getAggregation("_maxCont"));
			oRM.write("</br>");
			oRM.renderControl(oControl.getAggregation("_paycheck"));
			
			oRM.write("</div>");
		}
	});
});