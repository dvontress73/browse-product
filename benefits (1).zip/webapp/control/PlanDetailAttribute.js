sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Title",
	"sap/m/Text"
], function (Control, Title, Text) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.PlanDetailAttribute", {
		metadata: {
			properties: {
				title: {
					type: "string"
				},
				value: {
					type: "string"
				}
			},
			aggregations: {
				_title: { type: "sap.m.Title", multiple: false, visibility: "hidden" },
				_value: { type: "sap.m.Text", multiple: false, visibility: "hidden" }
			}
		},
		init: function(){
			this.setAggregation("_title", new Title({ text: this.getTitle() }));
			this.setAggregation("_value", new Text({ text: this.getValue() }));
		},
		setTitle: function(title){
			this.setProperty("title", title, true);
			this.getAggregation("_title").setText(title);
		},
		setValue: function(value){
			this.setProperty("value", value, true);
			this.getAggregation("_value").setText(value);
		},
		renderer: function (oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("planDetails-attribute");
			oRM.writeClasses();
			oRM.write(">");
			
			oRM.renderControl(oControl.getAggregation("_title"));         
			oRM.renderControl(oControl.getAggregation("_value"));
			
			oRM.write("</div>");
		}
	});
});