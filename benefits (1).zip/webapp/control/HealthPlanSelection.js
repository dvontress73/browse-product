sap.ui.define([
	"sap/ui/core/Control",
	"dart/hcm/benefits/control/PlanDetails",
	"dart/hcm/benefits/control/PlanDetailAttribute",
	"sap/m/HBox",
	"sap/m/SegmentedButton",
	"sap/m/SegmentedButtonItem",
	"sap/m/Text",
	"sap/m/FlexBox"
], function (Control, PlanDetails, PlanDetailAttribute, HBox, SegmentedButton, SegmentedButtonItem, Text, FlexBox) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.HealthPlanSelection", {
		metadata: {
			properties: {
				levels: {
					type: "object[]", 
					defaultValue: []
				},
				selectedLevel: {
					type: "string",
					defaultValue: ""
				},
				selectedPlan: {
					type: "string",
					defaultValue: ""
				},
				plans: {
					type: "object[]",
					defaultValue: []
				},
				linkLocationAttribute: {
					type: "string"
				}
			},
			aggregations: {
				_levelSelect: {
					type: "sap.m.FlexBox",
					multiple: false,
					visibility: "hidden"
				},
				_planOptions: {
					type: "sap.m.HBox",
					multiple: false, 
					visibility: "hidden"
				}
			},
			events: {
				levelChange: {
					parameters: {
						selectedLevel: {type: "string"}
					}
				},
				planChange: {
					parameters: {
						selectedPlan: {type: "object"}
					}
				}
			}
		},
		init: function() {
		
			this.segmentedButton = new SegmentedButton({
				selectedKey: this.getProperty("selectedLevel") 
			});
			this.segmentedButton.attachSelectionChange(function(event){
				this.fireEvent("levelChange", {
					selectedLevel: event.getSource().getSelectedKey()
				});
			}.bind(this));
			this.segmentedButton.addStyleClass("healthPlanSegmentedButton");
			this.getProperty("levels").forEach(function(l){
				this.segmentedButton.addItem(new SegmentedButtonItem({ 
					text: l.text,
					key: l.key
				}));
			});
			
			var level = new FlexBox({
				alignItems: "Center",
				renderType: "Bare"
			});
			level.addItem(
				new Text({ text: "Compare Plan Prices: " })
			);
			
			level.addItem(this.segmentedButton);
			
			this.setAggregation("_levelSelect", level);
			
			var hbox = new HBox({
				alignItems: "Start",
				wrap: "Wrap"
			});
			this.setAggregation("_planOptions", hbox);
		},
		renderer: function(oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("healthPlans");
			oRM.addClass("sapUiResponsiveMargin");
			oRM.writeClasses();
			oRM.write(">");

			oRM.renderControl(oControl.getAggregation("_levelSelect"));
			
			oRM.renderControl(oControl.getAggregation("_planOptions"));
			
			oRM.write("</div>");
		},
		setSelectedLevel: function(val){
			this.segmentedButton.setSelectedKey(val);
			this.setProperty("selectedLevel", val);
			
			this.calculateVisiblePlans(); 
		},
		setSelectedPlan: function(val){
			this.setProperty("selectedPlan", val);
			
			this.calculateVisiblePlans();
		},
		setLevels: function(values){
			//destroyButtons should be depreciated, but destroyItems wasn't working. 
			this.segmentedButton.destroyItems();
			this.segmentedButton.destroyButtons();
			(values || []).forEach(function(val){
				this.segmentedButton.addItem(new SegmentedButtonItem({
					text: val.text,
					key: val.key
				}));
			}.bind(this));
			this.setProperty("levels", values);
		},
		setPlans: function(values){
			this.setProperty("plans", values);
			this.calculateVisiblePlans();
		},
		calculateVisiblePlans: function(){
			var hbox = this.getAggregation("_planOptions");
			hbox.destroyItems();
			
			var selectedLevel = this.getProperty("selectedLevel");
			var selectedPlan = this.getProperty("selectedPlan");
			(this.getProperty("plans") || [] ).filter(function(plan){
				return plan.level === selectedLevel || plan.level === "WAIV";
			}).forEach(function(plan){
				var selected = plan.key === selectedPlan;
				
				var planDetail = new PlanDetails({
					planTitle: plan.title,
					selected: selected,
					enabled: !selected,
					showLink:plan.level !== "WAIV" 
				});
				
				plan.attributes.forEach(function(att){
					planDetail.addAttribute(new PlanDetailAttribute(att));                        
				});
				
				planDetail.attachChange(this.handlePlanChange(plan));
				
				hbox.addItem(planDetail);
			}.bind(this));
		},
		handlePlanChange: function(plan){
			return function(event) {
				this.fireEvent("planChange", {
					selectedPlan: plan
				});
			}.bind(this);
		}
	});
});