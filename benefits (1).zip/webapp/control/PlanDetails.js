sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Button",
	"sap/m/FlexBox",
	"sap/m/Title",
	"sap/m/Link",
	"sap/m/Slider",
	"sap/m/Text",
	"sap/m/MessageStrip",
	"dart/hcm/benefits/control/SliderWithButtons"
], function (
	Control, 
	Button, 
	FlexBox, 
	Title, 
	Link, 
	Slider, 
	Text, 
	MessageStrip, 
	SliderWithButtons
) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.PlanDetail", {
		metadata: {
			properties: {
				planTitle: {
					type: "string"
				},
				linkText: {
					type: "string",
					defaultValue: "View Plan Detail"
				},
				selected: {
					type: "boolean",
					defaultValue: false
				},
				selectedText: {
					type: "string",
					defaultValue: "Choose"
				},
				messageText: {
					type: "string",
					defaultValue: ""
				},
				valueTitle: {
					type: "string"
				},
				sliderKey: {
					type: "string"
				},
				showButton: {
					type: "boolean",
					defaultValue: true
				},
				enabled: {
					type: "boolean", 
					defaultValue: true
				},
				showLink: {
					type: "boolean",
					defaultValue: true
				},
				showMessage: {
					type: "boolean",
					defaultValue: false
				},
				target: {
					type: "string",
					defaultValue: "_blank"
				},
				href:{
					type:"string",
					defaultValue:""
				}
			},
			aggregations: {
				selectButton: {
					type: "sap.m.Button",
					multiple: false
				},
				attributes: {
					type: "dart.hcm.benefits.control.PlanDetailAttribute",
					multiple: true,
					bindable: "bindable"
				},
				sliderValues: {
					type: "sap.ui.core.Item",
					multiple: true,
					bindable: "bindable"
				},
				_title: {
					type: "sap.m.Title",
					multiple: false,
					visibility: "hidden"
				},
				_link: {
					type: "sap.m.Link",
					multiple: false,
					visibility: "hidden",
					bindable: "bindable"
				},
				_valueTitle: {
					type: "sap.m.Text",
					multiple: false,
					visibility: "hidden"
				}, 
				_slider: {
					type: "dart.hcm.benefits.control.SliderWithButtons",
					multiple: false,
					visibility: "hidden"
				},
				_value: {
					type: "sap.m.Text",
					multiple: false,
					visibility: "hidden"
				},
				_message: {
					type: "sap.m.MessageStrip",
					multiple: false,
					visibility: "hidden"
				}
			},
			defaultAggregation: "attributes",
			events: {
				change: {
					parameters: {
						selected: {type: "boolean"},
						selectedKey: {type: "string"}
					}
				}
			}
		},
		init: function () {
			this.setAggregation("selectButton", new Button({
				text: this.getProperty("selectedText"),
				press: this._onSelected.bind(this),
				iconFirst: false
			})
				.addStyleClass("sapUiTinyMarginBottom"));
			this.setAggregation("_title", new Title({
				text: this.getPlanTitle()
			})
				.addStyleClass("bold-text")
				.addStyleClass("planDetails-title"));
				
			this.setAggregation("_link", new Link({
				text: this.getLinkText(),
				visible: this.getProperty("showLink"),
				href:this.getHref(),
				target:"_blank"
			}));

			this.setAggregation("_valueTitle", new Text({text: this.getValueTitle()})
				.addStyleClass("slider-title"));
			var slider =  new SliderWithButtons({
				enabled:true
			});
			slider.attachChange(this.handleSliderChange.bind(this));
			slider.attachLiveChange(this.handleSliderLiveChange.bind(this));
			this.setAggregation("_slider", slider);
			this.setAggregation("_value", new Text());
			
			this.setAggregation("_message", new MessageStrip({
					text: this.getProperty("messageText"),
					type: "Warning",
					visible: this.getProperty("showMessage")
				})
				.addStyleClass("planDetails-message"));
		},
		getSelectedValue: function(){
			var key = this.getProperty("sliderKey");
			var val = (this.getAggregation("sliderValues") || []).filter(function(sv){
				return sv.getKey() === key;
			})[0];
			
			if(val){
				return val.getText();
			}
			return null;
		},
		setShowLink: function(val){
			if(this.getAggregation("_link"))
				this.getAggregation("_link").setVisible(val);
			this.setProperty("showLink", val); 
		},
		setShowMessage: function(val){
			this.getAggregation("_message").setVisible(val);
			this.setProperty("showMessage", val);
		},
		setMessageText: function(val){
			this.getAggregation("_message").setText(val);
			this.setProperty("messageText", val);
		},
		setHref:function(val){
			if(this.getAggregation("_link"))
				this.getAggregation("_link").setHref(val);
				
			this.setProperty("href", val);
		},
		setEnabled: function(value){
			this.getAggregation("selectButton").setEnabled(value);
			this.getAggregation("_slider").setEnabled(value);
			
			if(this.getAggregation("_link"))
				this.getAggregation("_link").setEnabled(true); 
			// this.setProperty("enabled", value);
		},
		setPlanTitle: function (title) {
			this.setProperty("planTitle", title, true);
			this.getAggregation("_title").setText(title);
		},
		setLinkText: function (text) {
			this.setProperty("linkText", text, true);
			
			if(this.getAggregation("_link"))
				this.getAggregation("_link").setText(text);
		},
		setValueTitle: function (text) {
			this.setProperty("valueTitle", text, true);
			this.getAggregation("_valueTitle").setText(text);
		},
		setSliderKey: function(value){
			var items = this.getAggregation("sliderValues");
			if(!value || value === ""){
				if(items && items.length > 0){
					value = items[0].getKey();
				}
			}
			this.setProperty("sliderKey", value, true);
			this.getAggregation("_value").setText(this.getSelectedValue());
			
			if(items) {
				var index = items.findIndex(function(i){
					return i.getKey() === value;	
				});
				
				this.getAggregation("_slider").setValueIndex(index);
			}
		},
		addSliderValue: function(value){
			this.addAggregation("sliderValues", value, true);
			this.getAggregation("_slider").setMax(this.getAggregation("sliderValues").length - 1);
			
			if (value) {
				value.attachEvent("_change", this.onItemChange, this);
			}
		},
		setSelected: function(value){
			this.setProperty("selected", value);
			if(value){
				if((this.getAggregation("sliderValues") || []).length > 1){
					this.getAggregation("_slider").setVisible(true);
					this.getAggregation("_valueTitle").setVisible(true);
					this.getAggregation("_value").setVisible(true);
				}
				this.getAggregation("selectButton").setIcon("sap-icon://complete");
			} else {
				if((this.getAggregation("sliderValues") || []).length > 1){
					this.getAggregation("_slider").setVisible(false);
					this.getAggregation("_valueTitle").setVisible(false);
					this.getAggregation("_value").setVisible(false);
				}
				this.getAggregation("selectButton").setIcon("sap-icon://border");
			}
		},
		onItemChange: function(event) {
			this.getAggregation("_value").setText(this.getSelectedValue());
		},
		handleSliderChange: function(event) {
			var index = event.getParameter("value");
			var item = this.getAggregation("sliderValues")[index];
			this.setSliderKey(item.getKey());
			this._onChange();
		},
		handleSliderLiveChange: function(event) {
			var index = event.getParameter("value");
			var item = this.getAggregation("sliderValues")[index];
			this.getAggregation("_value").setText(item.getText());
		},
		_onSelected: function() {
			var selected = !this.getSelected();
			this.setSelected(selected);
			
			this._onChange();
		},
		_onChange: function () {
			this.fireEvent("change", {
				selected: this.getSelected(),
				selectedKey: this.getSliderKey()
			});
		},
		renderer: function (oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("planDetails");
			oRM.addClass("sapUiSmallMargin");
			oRM.writeClasses();
			oRM.write(">");

			oControl.renderHeaderBox(oRM, oControl);
			if(oControl.getProperty("showButton")){
				oRM.renderControl(oControl.getAggregation("selectButton"));
			}
			
			oRM.renderControl(oControl.getAggregation("_message"));
			
			if( oControl.getAggregation("sliderValues") &&
				oControl.getAggregation("sliderValues").length > 0){
				oControl.renderSliderArea(oRM, oControl);
			}
			
			if(oControl.getAggregation("attributes") && oControl.getAggregation("attributes").forEach){
				oControl.getAggregation("attributes").forEach(function(attribute){
					oRM.renderControl(attribute);
				});
			}
			
			oRM.write("</div>");
		},
		renderHeaderBox: function (oRM, oControl) {
			oRM.write("<div");
			oRM.addClass("planDetails-header");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_title"));
			
			if(oControl.getHref()) {
				oRM.renderControl(oControl.getAggregation("_link"));
			}
				
			oRM.write("</div>");
		},
		renderSliderArea: function( oRM, oControl) {
			oRM.write("<div");
			oRM.addClass("planDetails-slider");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_valueTitle"));
			if(oControl.getAggregation("sliderValues").length > 1){
				oRM.renderControl(oControl.getAggregation("_slider"));
			}
			oRM.renderControl(oControl.getAggregation("_value"));
			oRM.write("</div>");
		}
	});
});