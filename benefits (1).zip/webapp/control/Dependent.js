sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Title",
	"sap/m/Text",
	"sap/m/VBox",
	"sap/m/HBox",
	"sap/ui/core/Icon"
], function (Control, Title, Text, VBox, HBox, Icon) {
	"use strict";
	return Control.extend("dart.hcm.benefits.control.Dependent", {
		metadata: {
			properties: {
				fullName: {
					type: "string"
				},
				status: {
					type: "string"
				},
				showIcon: {
					type: "boolean", 
					defaultValue: false
				},
				relation: {
					type: "string"
				},
				birthDate: {
					type: "string"
				}
			},
			aggregations: {
				_container: { type: "sap.m.VBox", multiple: false, visibility: "hidden" }
			}
		},
		init: function(){
			var container = new VBox({ wrap: "Wrap" });
			
			var topHbox = new HBox({ wrap: "Wrap" });
			
			this.nameText = new Text({ text: this.getProperty("fullName") });
			this.nameText.addStyleClass("sapUiSmallMarginEnd")
				.addStyleClass("bold-text");
			topHbox.addItem(this.nameText);
			this.statusText = new Text({ text: this.formattedStatus() });
			topHbox.addItem(this.statusText);
			this.icon = new Icon({ 
				src: "sap-icon://message-warning",
				tooltip: "{i18n>documentationRequired}",
				alt:"{i18n>documentationRequired}",
				visible: this.getProperty("showIcon"),
				color: "orange",
				decorative: false
			});
			topHbox.addItem(this.icon);
			container.addItem(topHbox);
			
			var bottomHbox = new HBox({ wrap: "Wrap" });
			this.bottomText = new Text({ text: this.formattedBottomText() });
			bottomHbox.addItem(this.bottomText);
			container.addItem(bottomHbox);
			
			this.setAggregation("_container", container);
		},
		setFullName: function(value){
			this.setProperty("fullName", value);
			this.nameText.setText(value);
		},
		setStatus: function(value){
			this.setProperty("status", value);
			this.statusText.setText(this.formattedStatus());
		},
		setShowIcon: function(value){
			this.setProperty("showIcon", value);
			this.icon.setVisible(value);
		},
		setRelation: function(value){
			this.setProperty("relation", value);
			this.bottomText.setText(this.formattedBottomText());
		},
		setBirthDate: function(value){
			this.setProperty("birthDate", value);
			this.bottomText.setText(this.formattedBottomText());
		},
		formattedStatus: function() {
			var status = this.getProperty("status") || "";
			return "(" + status + ")";
		},
		formattedBottomText: function(){
			var relation = this.getProperty("relation") || "";
			var dob = this.getProperty("birthDate") || "";
			return relation + ", " + dob;
		},
		renderer: function (oRM, oControl) {
			oRM.renderControl(oControl.getAggregation("_container"));
		}
	});
});