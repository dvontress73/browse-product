/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
  "use strict";

  sap.ui.require([
    "dart/hcm/benefits/test/unit/allTests"
  ], function () {
    QUnit.start();
  });
});
