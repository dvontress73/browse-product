sap.ui.define([
	"dart/hcm/benefits/test/unit/controller/BenefitsWizard.controller",
	"dart/hcm/benefits/test/unit/controller/Base.controller"
], function () {
	"use strict";
});