/*global QUnit*/

sap.ui.define([
	"dart/hcm/benefits/controller/Base"
], function (Base) {
	"use strict";

	//This module tests the main controller of the app. Add any other relevant tests.
	//For more information on Qunit, see https://sapui5.hana.ondemand.com/#/topic/09d145cd86ee4f8e9d08715f1b364c51
	QUnit.module("Base Controller");

	QUnit.test("I should test the app controller loads", function (assert) {
		var oAppController = new Base();
		var sName = oAppController.getMetadata().getName();
		assert.ok(sName, "dart/hcm/benefits.controller.Base");
	});
	
	QUnit.test("sanitizeSapString cleans up line breaks", function(assert) {
		var controller = new Base();
		var inputString = "testing\r\n multiple \r\n\r\n line \r\nbreaks\r\n\r\n";
		var outputString = "testing multiple \r\n line breaks\r\n";
		assert.ok(controller.sanitizeSapString(inputString), outputString);
	});
});