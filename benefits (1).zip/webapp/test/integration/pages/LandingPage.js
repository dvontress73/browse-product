sap.ui.define([
		"sap/ui/test/Opa5",
		"sap/ui/test/actions/Press"
	], function(Opa5, Press) {
		"use strict";

		var sViewName = "LandingPage";
		
		function linkIsVisibleButDisabled(name, id) {
			return this.waitFor({
				id: id,
				viewName: sViewName,
				visible: false,
				success: function(link) {
					Opa5.assert.ok(!link.getProperty("enabled"), name + " link is visible and disabled");
				},
				errorMessage: "Was not able to find the control with the id " + id
			});
		}
		
		Opa5.createPageObjects({
			onTheLandingPage: {
				actions: {
					iAmANewHire: function() {
						return this.waitFor({
							id: "landingPage",
							viewName: sViewName,
							actions: new Press(),
							errorMessage: "Was not able to find the control with the id controlId"
						});
					}
				},
				assertions: {
					iCanSeeAndClickTheNewHireEnrollmentLink: function() {
						return this.waitFor({
							id: "newHireStartLink",
							viewName: sViewName,
							success: function(link) {
								Opa5.assert.ok(link.getProperty("enabled"), "New Hire link is visible and enabled");
							},
							errorMessage: "Was not able to find the control with the id newHireStartLink"
						});
					},
					iCanSeeAndNotClickTheBenefitsConfirmationLink: function() {
						return linkIsVisibleButDisabled.bind(this)("Benefits Summary", "benefitsSummaryLink");
					},
					iCanSeeAndNotClickTheDependetsLink: function() {
						return linkIsVisibleButDisabled.bind(this)("Dependents", "dependentsLink");
					},
					iCanSeeAndNotClickTheLifeInsuranceBeneficiariesLink: function() {
						return linkIsVisibleButDisabled.bind(this)("Insurance Beneficiaries", "lifeInsuranceLink");
					},
					iCanSeeAndNotClickTheSupplementalLifeLink: function() {
						return linkIsVisibleButDisabled.bind(this)("Supplemental Life", "supplementalBenefitsLink");
					},
					iCanSeeAndNotClickTheManagewellLink: function() {
						return linkIsVisibleButDisabled.bind(this)("Managewell", "managewellLink");
					}
				}
			}
		});
	}
);