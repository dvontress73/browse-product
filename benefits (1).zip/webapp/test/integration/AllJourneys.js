/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"dart/hcm/benefits/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"dart/hcm/benefits/test/integration/pages/LandingPage",
	"dart/hcm/benefits/test/integration/LandingPageJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "dart.hcm.benefits.view.",
		autoWait: true
	});
});