/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit"
], function(opaTest) {
	"use strict";

	QUnit.module("Landing Page as a new hire");

	opaTest("Should have a new hire enrollment link for new hires", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
	        },
	        hash: "/"
		});

		// Actions
		When.onTheLandingPage.iAmANewHire();

		// Assertions
		Then.onTheLandingPage.iCanSeeAndClickTheNewHireEnrollmentLink();

		// Cleanup
		Then.iTeardownMyApp();
	});
	
	opaTest("Should have a disabled link to benefits confirmation", function(Given, When, Then){
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
			},
			hash: "/"
		});
		
		When.onTheLandingPage.iAmANewHire();
		
		Then.onTheLandingPage.iCanSeeAndNotClickTheBenefitsConfirmationLink();
		
		Then.iTeardownMyApp();
	});
	
	opaTest("Should have a disabled link to my dependants", function(Given, When, Then){
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
			},
			hash: "/"
		});
		
		When.onTheLandingPage.iAmANewHire();
		
		Then.onTheLandingPage.iCanSeeAndNotClickTheDependetsLink();
		
		Then.iTeardownMyApp();
	});
	
	opaTest("Should have a disabled link to my life insurance beneficiaries", function(Given, When, Then){
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
			},
			hash: "/"
		});
		
		When.onTheLandingPage.iAmANewHire();
		
		Then.onTheLandingPage.iCanSeeAndNotClickTheLifeInsuranceBeneficiariesLink();
		
		Then.iTeardownMyApp();
	});


	opaTest("Should have a disabled link to supplemental life coverage", function(Given, When, Then){
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
			},
			hash: "/"
		});
		
		When.onTheLandingPage.iAmANewHire();
		
		Then.onTheLandingPage.iCanSeeAndNotClickTheSupplementalLifeLink();
		
		Then.iTeardownMyApp();
	});
	
	opaTest("Should have a disabled link to managewell", function(Given, When, Then){
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "dart.hcm.benefits"
			},
			hash: "/"
		});
		
		When.onTheLandingPage.iAmANewHire();
		
		Then.onTheLandingPage.iCanSeeAndNotClickTheManagewellLink();
		
		Then.iTeardownMyApp();
	});
});