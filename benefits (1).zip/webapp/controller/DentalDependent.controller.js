sap.ui.define([
	"dart/hcm/benefits/controller/HealthDependentBase",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/dependentUtils"
], function (
	Controller,
	NumberFormat,
	DependentUtils
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.DentalDependent", {
		planType: "DENT",
		dependentLimits: DependentUtils.dependentLimits.DENT,
		onInit: function() {
			this.getRouter().getRoute("DenDepStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});