sap.ui.define([
	"dart/hcm/benefits/controller/HealthDependentBase",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/dependentUtils"
], function (
	Controller,
	NumberFormat,
	DependentUtils
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.VisionDependent", {
		planType: "VISN",
		dependentLimits: DependentUtils.dependentLimits.VISN,
		onInit: function() {
			this.getRouter().getRoute("VisDepStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});