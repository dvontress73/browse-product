sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/UploadCollection",
	"sap/m/UploadCollectionParameter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/m/IconTabSeparator",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/m/MessageItem",
	"sap/m/MessageView",
	"sap/ui/Device",
	"sap/m/Dialog",
	"sap/m/MessageBox",
	"dart/hcm/benefits/utils/planUtils",
	"sap/ui/core/format/NumberFormat"

], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	UploadCollection,
	UploadCollectionParameter,
	MessageToast,
	Fragment,
	IconTabSeparator,
	DependentUtils,
	MessageItem,
	MessageView,
	Device,
	Dialog,
	MessageBox,
	planUtils,
	NumberFormat
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.BenefitsWizard", {
		steps: function () {
			return this.getView().byId("wizard").getItems()
				.filter(function (i) {
					return i.constructor !== IconTabSeparator;
				})
				.filter(function (i) {
					return i.getVisible();
				})
				.map(function (i) {
					return i.getKey();
				});
		},
		onInit: function () {

			this.getRouter().attachRouteMatched(this.onRouteMatched.bind(this));
			this.model = new JSONModel({
				enableNextStep: false,
				enablePreviousStep: false,
				showDependentReminderStep: true,
				showSupplementDependentStep: true,
				dependentReminderCount: 0,
				wizardBusy: false,
				showDentalDependentStep: true,
				showMedicalDependentStep: true,
				showVisionDependentStep: true,
				enableSubmit: false,
				titleText: "",
				validationMessages: [],
				isLoading: true,
				premium: "",
				isMobile: false,
				isJVCompleted: false,
				isJVHealth: false
			});
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
			this.setupMessagePopover();
			this.getView().setModel(this.model);
			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			if (oDeviceModel.getData().system.phone) {
				this.model.setProperty("/isMobile", true);
				this.desktopView = false;
			}

		},
		showToolTip: function () {
			MessageToast.show(this.getTranslatedText("totalDeductionToolTip"));
		},
		desktopView: false,
		onBeforeRendering: function () {
			if (!this.desktopView) { //to make sure this logic is called only once
				var oOverflowBar = this.getView().byId("idOverFlow");
				if (!this.model.getProperty("/isMobile")) {
					oOverflowBar.removeAllContent();
					//Destroy existing DOM ID
					if (this.getView().byId("saveExit")) {
						this.getView().byId("saveExit").destroy();
					};
					if (this.getView().byId("previousbutton")) {
						this.getView().byId("previousbutton").destroy();
					}
					if (this.getView().byId("nextButton")) {
						this.getView().byId("nextButton").destroy();
					}
					if (this.getView().byId("submitButton")) {
						this.getView().byId("submitButton").destroy();
					}
					if (this.getView().byId("validationMesssageButton")) {
						this.getView().byId("validationMesssageButton").destroy();
					}
					if (this.getView().byId("totalDeductions")) {
						this.getView().byId("totalDeductions").destroy();
					}
					if (this.getView().byId("idIcon")) {
						this.getView().byId("idIcon").destroy();
					}
					oOverflowBar.setHeight("2.5rem");
					var oText = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.footerFragments.totalPayCheck", this);
					for (var i = 0; i < oText.length; i++) {
						oOverflowBar.addContent(oText[i]);
					}
					var oButton = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.footerFragments.wizardFooterButton", this);
					for (var i = 0; i < oButton.length; i++) {
						oOverflowBar.addContent(oButton[i]);
					}
					this.getView().byId("idIcon").setTooltip(this.getTranslatedText("totalDeductionToolTip"));
					this.desktopView = true;
				} else {
					if (this.getView().byId("saveExit")) {
						this.getView().byId("saveExit").addStyleClass("sapUiSmallMarginTop");

					};
					if (this.getView().byId("previousbutton")) {
						this.getView().byId("previousbutton").addStyleClass("sapUiSmallMarginTop");
					}
					if (this.getView().byId("submitButton")) {
						this.getView().byId("submitButton").addStyleClass("sapUiSmallMarginTop");
						this.getView().byId("submitButton").addStyleClass("sapUiSizeCompact");
					}
					if (this.getView().byId("validationMesssageButton")) {
						this.getView().byId("validationMesssageButton").addStyleClass("sapUiSmallMarginTop");
						this.getView().byId("validationMesssageButton").addStyleClass("sapUiSizeCompact");
					}
					if (this.getView().byId("nextButton")) {
						// this.getView().byId("nextButton").setType("Default");
						this.getView().byId("nextButton").addStyleClass("sapUiSmallMarginTop");
						this.getView().byId("nextButton").addStyleClass("sapUiSizeCompact");
					}
					if (this.getView().byId("idIcon")) {
						// this.getView().byId("idIcon").addStyleClass("sapUiMediumMarginBottom");
					}
				}
			}
			var oHeader = this.getView().byId("pageHeader");
			if (!this.desktopView) {
				oHeader.removeAllContent();
				this.loadMobileFragment(oHeader);

			} else {
				oHeader.removeAllContent();
				this.loadDesktopFragment(oHeader);
			}
			this.setLanguage();
		},
		showAllTabsFn: function (pernr, event) {
			var that = this;
			this.benefitsModel().read("/continueEnrollmentSet(pernr='" + pernr + "',event='" + event + "')", {
				success: function (result) {
					if (result.showJV === "false") {
						result.showJV = false
					} else {
						result.showJV = true
					}

					if (!result.showJV) {
						if (!that.showAllTabs) {
							that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", false);
							that.showAllTabs = false;
							that.disableTabsForJV();
						} else {
							that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", true);
							that.showAllTabs = true;
							that.model.setProperty("/isJVCompleted", true);
							that.model.setProperty("/isJVHealthisJVHealth", true);
							that.model.setProperty("/showMedicalDependentStep", that.model.getProperty("/showMedicalDependentStep"));
							that.model.setProperty("/showDentalDependentStep", that.model.getProperty("/showDentalDependentStep"));
							that.model.setProperty("/showVisionDependentStep", that.model.getProperty("/showVisionDependentStep"));
							that.enableDependentReminderStep();
							that.enableSupplementalLifeDependentsStep();
							that.getView().byId("wizard").setSelectedKey(result.id_session);
						}

					} else {
						that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", true);
						that.showAllTabs = true;
						that.model.setProperty("/isJVCompleted", true);
						that.model.setProperty("/isJVHealth", true);
						that.model.setProperty("/showMedicalDependentStep", that.model.getProperty("/showMedicalDependentStep"));
						that.model.setProperty("/showDentalDependentStep", that.model.getProperty("/showDentalDependentStep"));
						that.model.setProperty("/showVisionDependentStep", that.model.getProperty("/showVisionDependentStep"));
						that.enableDependentReminderStep();
						that.enableSupplementalLifeDependentsStep();
						that.getView().byId("wizard").setSelectedKey(result.id_session);

					}
				}
			});
		},
		onRouteMatched: function (event) {

			this.getProxyPernr(event.getParameters().arguments.Pernr);
			this.model.setProperty("/isLoading", true);
			this.currentRoute = event.getParameter("name");
			this.routeArguments = event.getParameter("arguments");
			this.checkPermission(this.routeArguments.Pernr, this.routeArguments.Event, this.routeArguments.Begda, this.routeArguments.Endda);
			this.byId("wizard").setSelectedKey(this.currentRoute);

			this.getView().getModel().setProperty("/enableNextStep", this.enableNextStep());
			this.getView().getModel().setProperty("/enablePreviousStep", this.enablePreviousStep());
			this.benefitsModel().attachRequestCompleted(this.listenToBackendCalls.bind(this));
			this.mdvFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.mdvEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});
			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.mdvFilter, this.mdvEventFilter]
			});
			if (this.routeArguments.Event !== "NONE") {
				if (this.currentRoute === "SumStep") {
					this.model.setProperty("/enableSubmit", true);
					this.getValidationMessages().then(function () {
						this.model.setProperty("/isLoading", false);
					}.bind(this));
				} else {
					this.model.setProperty("/enableSubmit", false);
					this.model.setProperty("/isLoading", false);
				}
			} else {
				this.model.setProperty("/enableSubmit", false);
				this.model.setProperty("/isLoading", false);
			}
			if (this.routeArguments.Event === "NONE" && this.currentRoute === "SumStep") {
				this.model.setProperty("/enableSubmit", true);
			}
			this.getEname();
			this.getDeductions();
			this.disableTabsForJV();
			this.enableDependentReminderStep();
			this.enableSupplementalLifeDependentsStep();
			this.showAllTabsFn(this.routeArguments.Pernr, this.routeArguments.Event);
			
			if( this.byId("currentBenefitsBtn") ) {
				this.byId("currentBenefitsBtn").setVisible( this.routeArguments.Event === "OPEN" );
			}
		},
		disableTabsForJV: function () {
			//Medical Vision and Dental should not be shown in case of OPEN and HIRE Event
			// if (this.routeArguments.Event === "HIRE" || this.routeArguments.Event === "OPEN") {
			// 	this.model.setProperty("/isJVHealth", false);
			// }
			if (!this.showAllTabs) {
				if (this.routeArguments.Event === "HIRE" || this.routeArguments.Event === "OPEN") {
					this.model.setProperty("/isJVCompleted", false);
					this.model.setProperty("/isJVHealth", false);
					this.model.setProperty("/showMedicalDependentStep", false);
					this.model.setProperty("/showDentalDependentStep", false);
					this.model.setProperty("/showVisionDependentStep", false);
					this.model.setProperty("/showDependentReminderStep", false);
					this.model.setProperty("/showSupplementDependentStep", false);
				}
			}
		},
		enableTabsForJV: function (medical, dental, vision) {
			this.model.setProperty("/isJVCompleted", true);
			this.model.setProperty("/isJVHealth", true);
			this.model.setProperty("/showMedicalDependentStep", medical);
			this.model.setProperty("/showDentalDependentStep", dental);
			this.model.setProperty("/showVisionDependentStep", vision);
			this.model.setProperty("/showDependentReminderStep", this.model.getProperty("/showDependentReminderStep"));
			this.model.setProperty("/showSupplementDependentStep", this.model.getProperty("/showSupplementDependentStep"));
			this.goToRoute("MWStep");
		},
		onLanguageChange: function (oEvent) {

			if (this.desktopView) {
				this.changeLanguage(oEvent.getSource()._getSelectedItemText());
				this.updateStaticTexts(oEvent.getSource()._getSelectedItemText());
			} else {
				this.createRadioButton();
				this.dialog.open();
			}

		},
		closeDialog: function () {
			this.dialog.close();
		},
		updateStaticTexts: function (filterValue) {
			var lang;
			if (typeof filterValue === "undefined" || filterValue === "English" || filterValue === "Inglés") {
				lang = "E";
			} else {
				lang = "S";
			}
			this.benefitsModel().read("/welcome_terms_textSet", {
				filters: [
					new Filter({
						path: "lang",
						operator: FilterOperator.EQ,
						value1: lang
					})
				]
			});
		},
		onMobileLanguageSelection: function (oEvent) {
			this.changeLanguage(oEvent.getSource().getSelectedButton().getText());
			this.updateStaticTexts(oEvent.getSource().getSelectedButton().getText());
			this.dialog.close();
		},
		getDeductions: function () {

			var deductions = "/totalDeduction(pernr='" + this.routeArguments.Pernr + "',event='" + this.routeArguments.Event + "')";

			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});

		},
		handleDeductionSuccess: function (data) {
			this.model.setProperty("/premium", data.premium);
		},
		setupMessagePopover: function () {
			var link = new sap.m.Link({
				text: this.getTranslatedText("goToError")
			});
			link.attachPress(function () {
				if (this.step) {
					this.getRouter().navTo(this.step, this.routeArguments);
				}
				this.popover.close();
			}.bind(this));

			var messageTemplate = new sap.m.MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{text}',
				subtitle: '{subtitle}',
				counter: '{counter}',
				markupDescription: "{markupDescription}",
				link: link
			});

			this.popoverView = new MessageView({
				showDetailsPageHeader: false,
				itemSelect: function (event) {
					if (this.model.getProperty("/validationMessages").length > 1) {
						oBackButton.setVisible(true);
					}
					this.step = event.getParameter("item").getBindingContext().getProperty("step")
				}.bind(this),
				items: {
					path: "/validationMessages",
					template: messageTemplate
				}
			});
			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function (event) {
					this.popoverView.navigateBack();
					event.getSource().setVisible(false);
				}.bind(this)
			});
			var oCloseButton = new sap.m.Button({
				text: "Close",
				press: function () {
					this.popover.close();
				}.bind(this)
			});
			var oPopoverFooter = new sap.m.Bar({
				contentRight: oCloseButton
			});
			var oPopoverBar = new sap.m.Bar({
				contentLeft: [oBackButton],
				contentMiddle: [
					new sap.m.Text({
						text: this.getTranslatedText("errorsInBenefitsEnrollment")
					})
				]
			});
			this.popoverView.setModel(this.model);

			this.popover = new sap.m.Popover({
				customHeader: oPopoverBar,
				contentWidth: "440px",
				contentHeight: "440px",
				verticalScrolling: false,
				modal: true,
				content: [this.popoverView],
				footer: oPopoverFooter
			});
		},
		pernrKey: null,
		proxyUserId: null,
		getProxyPernr: function (data) {
			if (data !== "") {
				this.pernrKey = data;
			} else {
				this.pernrKey = "X";
			}
		},
		getEname: function () {
			this.proxyUserId = this.pernrKey;
			var sEname = "/getEnameSet('" + this.pernrKey + "')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		onSelect: function (event) {
			var route = event.getParameter("selectedKey");
			this.goToRoute(route);
		},
		getWizard: function () {
			return this.getView().byId("BenefitsWizard");
		},
		enableNextStep: function () {
			if (this.currentRoute === "JellyVisionStep") {
				return true;
			} else {
				var steps = this.steps();
				return steps.indexOf(this.currentRoute) < (steps.length - 1);
			}

		},
		enablePreviousStep: function () {
			return this.steps().indexOf(this.currentRoute) > 0;
		},
		goToNextStep: function (oEvent) {
			if (this.currentRoute === "JellyVisionStep") {
				this.jellyVisionRetrieve(oEvent);
			} else {
				var steps = this.steps();
				var nextStep = steps[steps.indexOf(this.currentRoute) + 1];
				this.goToRoute(nextStep);
			}

		},
		goToPreviousStep: function () {
			var steps = this.steps();
			var nextStep = steps[steps.indexOf(this.currentRoute) - 1];
			this.goToRoute(nextStep);
		},
		goToRoute: function (newStep) {
			this.updateCurrentStep(Object.assign({},
				this.routeArguments, {
					IdSession: newStep
				}), {
				success: function () {
					this.getRouter().navTo(newStep, this.routeArguments);
				}.bind(this)
			});
		},
		jellyVisionRetrieve: function (oEvent) {

			var payload = {
				"pernr": this.routeArguments.Pernr,
				"event": this.routeArguments.Event,
				"begda": this.routeArguments.Begda,
				"endda": this.routeArguments.Endda,
				"learnAcct" : ''
			}
			var that = this;
			this.model.setProperty("/wizardBusy", true);
			var key = this.benefitsModel().createKey("/jellyVision", payload);
			this.benefitsModel().update(key, payload, {
				success: function (result) {
					that.model.setProperty("/wizardBusy", false);
					that.showJVConfirmations(oEvent);
				}
			});
		},
		showAllTabs: false,
		showJVConfirmations: function (data) {
			debugger;
			var that = this;
			var oMessageTemplate = new sap.m.MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}',
				counter: '{counter}',
				markupDescription: '{markupDescription}',
			});

			this.mdvFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.mdvEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});
			var messages = [];
			this.showMedicalDep = true;
			this.showDentalDep = true;
			this.showVisionDep = true;
			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.mdvFilter, this.mdvEventFilter],
				success: function (result) {

					var enrolled = result.results.filter(function (r) {
						return r.enrolled === "X";
					});

					[{
						pltyp: "AMED",
						i18nKey: "Medical",
						step: "MedDepStep"
					}, {
						pltyp: "DENT",
						i18nKey: "Dental",
						step: "DenDepStep"
					}, {
						pltyp: "VISN",
						i18nKey: "Vision",
						step: "VisDepStep"
					}, {
						pltyp: "HCFX",
						i18nKey: "HCFX",
						step: "HCFX"
					}, {
						pltyp: "DCFX",
						i18nKey: "DCFX",
						step: "DCFX"
					}].forEach(function (info) {
						var plan = enrolled.filter(function (p) {
							return p.pltyp === info.pltyp;
						})[0];

						if (!plan) {
							if (info.i18nKey === "Medical") {
								info.step = "MedicalStep";
							} else if (info.i18nKey === "Dental") {
								info.step = "DentalStep";
							} else if (info.i18nKey === "Vision") {
								info.step = "VisionStep";
							} else if (info.i18nKey === "DCFX") {
								info.step = "DCFX";
							}
							if (info.i18nKey === "Medical" || info.i18nKey === "Dental" || info.i18nKey === "Vision") {
								messages.push({
									type: "Error",
									title: that.getTranslatedText(`${info.i18nKey}Error`),
									description: that.getTranslatedText(`validationMissing${info.i18nKey}`),
									step: info.step
								});
							}
						} else {
							if (info.i18nKey === "Medical") {
								info.step = "MedicalStep";
							} else if (info.i18nKey === "Dental") {
								info.step = "DentalStep";
							} else if (info.i18nKey === "Vision") {
								info.step = "VisionStep";
							} else if (info.i18nKey === "HCFX") {
								info.step = "HCFX";
							} else if (info.i18nKey === "DCFX") {
								info.step = "DCFX";
							}
							var planModel = {
								title: that.getTranslatedText(planUtils.getTitleKeyForPlan(plan)),
								sapEntity: plan,
								attributes: []
							};
							var desc = "Your Current " + info.i18nKey + " Selections are: \n\n" +
								"Selected Plan: " + planModel.title + "\n\n" +
								"Plan Level: " + that.getTranslatedText(planUtils.getTextKeyForPlanLevel(plan.depcv)) + "\n\n" +
								"Plan Premium: " + that.currencyFormatter.format([plan.amount, "$"]) + "\n";
							if (plan.pltyp === "HCFX" || plan.pltyp === "DCFX") {
								desc = "";
								desc = "Your Current " + that.getTranslatedText(plan.pltyp) + " Selections are: \n\n" +
									"Selected Plan: " + planModel.title + "\n\n" +
									"Plan Premium: " + that.currencyFormatter.format([plan.amount, "$"]) + "\n";
								if (plan.fsa_min === 'X') {
									desc = "";
									desc = "Your Current " + that.getTranslatedText(plan.pltyp) + " Selections are: \n\n" +
										"Selected Plan: " + planModel.title + "\n\n" +
										"Amount: " + that.currencyFormatter.format([plan.amount, "$"]) + "\n\n" +
										"Minimum Required Amount : $260.00";
									messages.push({
										type: "Warning",
										title: that.getTranslatedText(`${info.i18nKey}Error`),
										description:desc,
										// description: that.getTranslatedText(`validationMissing${info.i18nKey}`),
										step: info.step
									});
									return;
								}
							}
							//Do not show Dependent tab if the plan is waived
							if (plan.pltyp === "AMED" && plan.depcv === "WAIV") {
								that.showMedicalDep = false;
							} else if (plan.pltyp === "DENT" && plan.depcv === "WAIV") {
								that.showDentalDep = false;
							} else if (plan.pltyp === "VISN" && plan.depcv === "WAIV") {
								that.showVisionDep = false;
							}
							messages.push({
								type: "Success",
								title: that.getTranslatedText(`${info.i18nKey}Success`),
								description: desc,
								step: info.step
							});

						}
					});
					var oModel = new JSONModel();
					var headingText = "Enrollment Summary";
					var state = "Success";
					var showTabs = true;
					var buttonText = "Continue";
					var incompleteEnrollment = ""
					for (var i = 0; i < messages.length; i++) {
						if (messages[i].type === "Error" && messages[i].step!== "DCFX") {
							headingText = "Incomplete Enrollment";
							state = "Warning"
							showTabs = false;
							buttonText = "Close"
							break;
						}
					}
					oModel.setData(messages);
					that.oMessageView = new sap.m.MessageView({
						showDetailsPageHeader: false,
						itemSelect: function () {
							oBackButton.setVisible(true);
						},
						items: {
							path: "/",
							template: oMessageTemplate
						}
					});

					var oBackButton = new sap.m.Button({
						icon: sap.ui.core.IconPool.getIconURI("nav-back"),
						visible: false,
						press: function () {
							that.oMessageView.navigateBack();
							that.setVisible(false);
						}
					});

					that.oMessageView.setModel(oModel);
					var oDialog = new Dialog({
						content: [that.oMessageView],
						state: state,
						beginButton: new sap.m.Button({
							press: function () {
								this.getParent().close();
								if (showTabs) {
									that.showAllTabs = true;
									that.enableTabsForJV(that.showMedicalDep, that.showDentalDep, that.showVisionDep);
								}
							},
							text: buttonText
						}),
						customHeader: new sap.m.Bar({
							contentMiddle: [
								new sap.m.Text({
									text: headingText
								})
							],
							contentLeft: [oBackButton]
						}),
						contentHeight: "300px",
						contentWidth: "500px",
						verticalScrolling: false
					});
					oDialog.open();
				}
			});
		},
		enableDependentReminderStep: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.model.setProperty("/wizardBusy", true);
			this.benefitsModel().read("/empDepBenSet", {
				filters: [this.oFilter],
				success: function (dependents) {
					var needsDocuments = dependents.results.filter(function (d) {
						return d.status_id === "1";
					});

					this.getModel().setProperty("/dependentReminderCount", needsDocuments.length);

					if (needsDocuments.length > 0) {
						this.getModel().setProperty("/showDependentReminderStep", true);
					} else {
						this.getModel().setProperty("/showDependentReminderStep", false);
					}

					this.model.setProperty("/wizardBusy", false);
				}.bind(this)
			});
		},
		enableSupplementalLifeDependentsStep: function () {

			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});

			this.model.setProperty("/wizardBusy", true);
			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: function (result) {
					var suppLife = result.results.filter(function (i) {
						return i.bplan === "SUPP" && i.enrolled === "X";
					})[0];

					if (suppLife) {
						this.getModel().setProperty("/showSupplementDependentStep", true);
					} else {
						this.getModel().setProperty("/showSupplementDependentStep", false);
					}

					this.model.setProperty("/wizardBusy", false);
				}.bind(this)
			});
		},
		submit: function () {

			var sumIcon = this.getView().byId("SumStep");
			if (this.model.getProperty("/validationMessages") != 0) {
				sumIcon.setIconColor("Negative");
				var messages = this.model.getProperty("/validationMessages");
				sumIcon.setCount(messages.length);
				var message = {};
				var aMockMessages = [];
				for (var i = 0; i <= messages.length - 1; i++) {
					message.type = 'Error';
					message.title = messages[i].title;
					message.description = messages[i].text;
					message.counter = i + 1;
					aMockMessages.push(message);
					message = {};
				}

				var oModel = new JSONModel();
				oModel.setData(aMockMessages);
				var link = new sap.m.Link({
					text: this.getTranslatedText("goToError")
				});

				link.attachPress(function () {
					if (this.step) {
						// this.getRouter().navTo(this.step, this.routeArguments);
						this.goToRoute(this.step);
					}
					this.oDialog.close();
				}.bind(this));

				var oMessageTemplate = new MessageItem({
					type: '{type}',
					title: '{title}',
					description: '{description}',
					subtitle: '{subtitle}',
					counter: '{counter}',
					markupDescription: '{markupDescription}',
					link: link
				});

				this.oMessageView = new MessageView({
					showDetailsPageHeader: false,
					itemSelect: function (event) {
						oBackButton.setVisible(true);
						this.step = this.model.getProperty("/validationMessages")[event.getParameter("item").getBindingContext().sPath.split("/")[1]]
							.step;
					}.bind(this),
					items: {
						path: "/",
						template: oMessageTemplate
					}
				});
				this.oMessageView.setModel(oModel);
				var that = this;
				this.oMessageView.setModel(oModel);
				var oBackButton = new sap.m.Button({
					icon: sap.ui.core.IconPool.getIconURI("nav-back"),
					visible: false,
					press: function () {
						that.oMessageView.navigateBack();
						this.setVisible(false);
					}
				});

				this.oDialog = new Dialog({
					resizable: true,
					content: this.oMessageView,
					state: 'Error',
					beginButton: new sap.m.Button({
						press: function () {
							this.getParent().close();
						},
						text: "Close"
					}),
					customHeader: new sap.m.Bar({
						contentMiddle: [
							new Text({
								text: "Error"
							})
						],
						contentLeft: [oBackButton]
					}),
					contentHeight: "50%",
					contentWidth: "50%",
					verticalScrolling: false
				});
				this.oDialog.open();
			} else {
				sumIcon.setIconColor("Default");
				sumIcon.setCount();
				this.oPlanFilter = new sap.ui.model.Filter({
					path: "pernr",
					operator: FilterOperator.EQ,
					value1: this.routeArguments.Pernr
				});
				this.oPlanEvent = new sap.ui.model.Filter({
					path: "event",
					operator: FilterOperator.EQ,
					value1: this.routeArguments.Event
				});
				this.oFilter = new sap.ui.model.Filter({
					path: "Pernr",
					operator: FilterOperator.EQ,
					value1: this.routeArguments.Pernr
				});
				var that = this;
				var oDialog = this.getView().byId("BusyDialog");
				if (this.routeArguments.Event === "HIRE") {
					this.benefitsModel().read("/employeeAdjReasonSet", {
						filters: [this.oFilter],
						success: function (result) {

							for (var i = 0; i < result.results.length; i++) {
								if (result.results[i].AdjReasonCode === "OPEN") {
									var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
									MessageBox.information(
										that.getTranslatedText("openOverlapsHire"), {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);

								}
							}
						}
					});
				}
				oDialog.open();
				if (this.isValid()) {
					this.submitEnrollments(this.routeArguments.Pernr, this.routeArguments.Event, this.routeArguments.Begda, this.routeArguments.Endda);
					this.goToRoute("CurrentBenefits");
				}
				oDialog.close();
			}
		},
		getValidationMessages: function () {
			var promises = [];
			this.model.setProperty("/isLoading", true);

			promises.push(new Promise(this.validateMDV.bind(this)));
			promises.push(new Promise(this.validateBeneficiaries.bind(this)));
			promises.push(new Promise(this.validateManagewell.bind(this)));
			promises.push(new Promise(this.validateUnum.bind(this)));

			Promise.all(promises).then(function (messages) {
				this.model.setProperty("/validationMessages", messages.flat());
			}.bind(this));

			return Promise.allSettled(promises);
		},

		validateUnum: function (successFn, failureFn) {
			var oFilterPernr = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});

			var oFilterEvent = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});

			var oFilterBegda = new sap.ui.model.Filter({
				path: "begda",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Begda
			});
			var that = this;
			this.benefitsModel().read("/continueEnrollmentSet", {
				filters: [oFilterPernr, oFilterEvent, oFilterBegda],
				success: function (result) {
					var messages = [];
					if (result.results[0].id_session === "AddBenStep" && result.results[0].check == "true") {
						var info = {
							i18nKey: "unumTitle",
							step: result.results[0].id_session
						};
						messages.push({
							title: that.getTranslatedText(`${info.i18nKey}`),
							text: that.getTranslatedText(`validationMissing${info.i18nKey}`),
							step: info.step
						});
					}
					successFn(messages);
				},

			});

		},

		validateManagewell: function (successFn, failureFn) {
			var key = "/manageWell(pernr='" + this.routeArguments.Pernr + "',event='" + this.routeArguments.Event + "')";
			var that = this;
			this.benefitsModel().read(key, {
				success: function (result) {
					var messages = [];
					var info = {
						i18nKey: "managewellTitle",
						step: "MWStep"
					};
					if (result.check === "true") {
						messages.push({
							title: that.getTranslatedText(`${info.i18nKey}`),
							text: that.getTranslatedText(`validationMissing${info.i18nKey}`),
							step: info.step
						});
					}
					successFn(messages);
				}
			});

		},

		validateMDV: function (successFn, failureFn) {
			this.mdvFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.mdvEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});

			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.mdvFilter, this.mdvEventFilter],
				success: function (result) {
					var messages = [];
					var enrolled = result.results.filter(function (r) {
						return r.enrolled === "X";
					});

					[{
						pltyp: "AMED",
						i18nKey: "Medical",
						step: "MedDepStep"
					}, {
						pltyp: "DENT",
						i18nKey: "Dental",
						step: "DenDepStep"
					}, {
						pltyp: "VISN",
						i18nKey: "Vision",
						step: "VisDepStep"
					}].forEach(function (info) {
						var plan = enrolled.filter(function (p) {
							return p.pltyp === info.pltyp;
						})[0];

						if (!plan) {
							if (info.i18nKey === "Medical") {
								info.step = "MedicalStep";
							} else if (info.i18nKey === "Dental") {
								info.step = "DentalStep";
							} else if (info.i18nKey === "Vision") {
								info.step = "VisionStep";
							}
							messages.push({
								title: this.getTranslatedText(`${info.i18nKey}Error`),
								text: this.getTranslatedText(`validationMissing${info.i18nKey}`),
								step: info.step
							});
						} else if (plan.depcv !== "WAIV") {
							var dependentLevels = DependentUtils.dependentLimits[info.pltyp];
							var dependentLimit = dependentLevels[plan.depcv];
							var lowerDependentLimitKey = Object.keys(dependentLevels).indexOf(plan.depcv) - 1;
							var lowerDependentLimit = dependentLevels[Object.keys(dependentLevels)[lowerDependentLimitKey]];
							if (plan.depcv === "EEFA" || plan.depcv === "EFAM") {
								lowerDependentLimit = 2;
							} else if (plan.depcv === "EE+1") {
								lowerDependentLimit = 1;
							}
							var dependentCount = 0;
							for (var i = 1; i <= 20; i++) {
								var num = ("00" + i).slice(-2);
								if (plan["dty" + num] !== "") {
									dependentCount++;
									break;
								}
							}

							if (dependentCount > dependentLimit) {
								messages.push({
									title: this.getTranslatedText(`${info.i18nKey}Error`),
									text: this.getTranslatedText(`validation${info.i18nKey}MoreDependentsThanPlan`),
									step: info.step
								});
							}
							if (plan.depcv === "EEFA" || plan.depcv === "EFAM") {
								var dependentCount = 0;
								for (var i = 1; i <= 20; i++) {
									var num = ("00" + i).slice(-2);
									if (plan["dty" + num] !== "") {
										dependentCount++;
									}
								}
								if (dependentCount < lowerDependentLimit) {
									messages.push({
										title: this.getTranslatedText(`${info.i18nKey}Error`),
										text: this.getTranslatedText(`validation${info.i18nKey}CanGoDownLevel`),
										step: info.step
									});
								}
							} else {
								if (dependentCount < lowerDependentLimit) {
									messages.push({
										title: this.getTranslatedText(`${info.i18nKey}Error`),
										text: this.getTranslatedText(`validation${info.i18nKey}CanGoDownLevel`),
										step: info.step
									});
								}
							}

						}
					}.bind(this));

					successFn(messages);
				}.bind(this)
			});
		},
		validateBeneficiaries: function (successfn, rejectfn) {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArguments.Event
			});
			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: function (result) {
					var messages = [];
					var enrolled = result.results.filter(function (r) {
						return r.enrolled === "X";
					}).forEach(function (ins) {
						var hasError = false;
						var totalPrimary = 0;
						var totalContingent = 0;
						for (var i = 1; i <= 20; i++) {
							var num = ("00" + i).slice(-2);
							var primary = parseFloat(ins["bpt" + num]);
							if (!ins["bpt" + num]) {
								primary = 0;
							}
							var contingent = parseFloat(ins["cbpt" + num]);
							if (!ins["cbpt" + num]) {
								contingent = 0;
							}
							totalPrimary += primary;
							totalContingent += contingent;
							if (primary && contingent) {
								hasError = true;
							}
						}
						if (totalPrimary !== 100) {
							hasError = true;
						}
						if (totalContingent !== 100) {
							// hasError = true;
						}

						if (hasError) {
							var key = {
								//SPLP: "SupplementalSpouse", // this doesn't have a beneficiary allocation
								SUPP: "SupplementalLife",
								BCLF: "Life"
							}[ins.bplan];

							if (key) {
								var step = {
									SUPP: "SuppBenStep",
									BCLF: "LifeInsStep"
								}[ins.bplan];
								messages.push({
									title: this.getTranslatedText(`${key}Error`),
									text: this.getTranslatedText(`validation${key}Text`),
									step: step
								});
							}
						}
					}.bind(this));
					successfn(messages);
				}.bind(this)
			})
		},
		isValid: function () {
			return this.model.getProperty("/validationMessages").length === 0;
		},
		listenToBackendCalls: function (event) {
			var url = event.getParameter("url");
			var data = event.getParameter("response");
			var success = event.getParameter("success");
			// var headers = event.getParameter("headers");
			var method = event.getParameter("method");

			if (success) {
				if (method === "PUT" || method === "POST") {
					if (this.model.getProperty("/validationMessages").length > 0 && !this.model.getProperty("/isLoading")) {
						// would like to handle this differently, but it's probably the best way for now
						this.getValidationMessages().then(function () {
							this.model.setProperty("/isLoading", false);
						}.bind(this));
					}
				}

				if (url.indexOf("lifeInsHeadSet") > -1) {
					if (method === "PUT") {
						// var bc = this.benefitsModel().createBindingContext("/" + url);
						// if (this.benefitsModel().getProperty("enrolled", bc) === "X") {
						// 	this.model.setProperty("/showSupplementDependentStep", true);
						// } else if (url.includes("SUPP")) {
						// 	this.model.setProperty("/showSupplementDependentStep", false);
						// }
					}
				} else if (url.indexOf("mdvPlanSet") > -1) {
					if (method === "GET") {
						var results = JSON.parse(data.responseText).d.results;
						var enrolledInMedicalNeedingDependents = results
							.filter(function (d) {
								return d.pltyp === "AMED" && d.depcv !== "WAIV" && d.enrolled === "X";
							}).length > 0;

						this.model.setProperty("/showMedicalDependentStep", enrolledInMedicalNeedingDependents);

						var enrolledInDentalNeedingDependents = results
							.filter(function (d) {
								return d.pltyp === "DENT" && d.depcv !== "WAIV" && d.enrolled === "X";
							}).length > 0;

						this.model.setProperty("/showDentalDependentStep", enrolledInDentalNeedingDependents);

						var enrolledInVisionNeedingDependents = results
							.filter(function (d) {
								return d.pltyp === "VISN" && d.depcv !== "WAIV" && d.enrolled === "X";
							}).length > 0;

						this.model.setProperty("/showVisionDependentStep", enrolledInVisionNeedingDependents);
					}
					if (method === "POST") {
						//is one of the medical plans
						if (data.pltyp === "AMED") {
							if (data.bplan === "1090") {
								this.model.setProperty("/showMedicalDependentStep", false);
							} else {
								this.model.setProperty("/showMedicalDependentStep", true);
							}
						}

						if (data.pltyp === "DENT") {
							if (data.bplan === "1090") {
								this.model.setProperty("/showDentalDependentStep", false);
							} else {
								this.model.setProperty("/showDentalDependentStep", true);
							}
						}

						if (data.pltyp === "VISN") {
							if (data.bplan === "1090") {
								this.model.setProperty("/showVisionDependentStep", false);
							} else {
								this.model.setProperty("/showVisionDependentStep", true);
							}
						}
					}
				}
			}

		},
		validationType: function (messages) {
			return "Reject";
		},
		validationText: function (messages) {
			return this.getTranslatedText("validationMessagesButton", messages.length);
		},
		onSaveExitPress: function () {
			this.getRouter().navTo("LandingPage", {
				Pernr: this.routeArguments.Pernr
			});
		},
		showValidationMessages: function (event) {
			this.popoverView.navigateBack();
			this.popover.openBy(event.getSource());
		},
		
		openCurrentEnrollments : function() {
			var nextStep = "CurrentBenefits";
		
			function onSessionCreated(data) {
				var __location = window.location;
				//"/currentBenefits/{Pernr}/{Begda}/{Endda}/{Event}/
				window.open(
					__location.pathname + "?sap-ushell-config=headerless#ZHCM-Benefits&//currentBenefits/" + this.pernrKey + "/" + data.Begda + "/" + data.Endda  + "/ANY/",
					"openCurrentEnrollments",
					"location=no,menubar=no"
				);
			}
			
			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: this.currentEventCode,
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		}
	});
});