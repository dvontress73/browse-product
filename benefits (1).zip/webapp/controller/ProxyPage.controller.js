sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/m/IconTabSeparator"
], function (Controller, JSONModel, IconTabSeparator) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.ProxyPage", {

		onInit: function () {
			this.model = new JSONModel({
				titleText: "",
				isHRCRep: "",
				isVisible: false,
				busyVisible: true,
				isDesync: false,
				pageVisible: false,
				ssn: "",
				dob: "",
				ename: "",
				emp_name: "",
				terminal: "",
				zsync_date: "",
				zsync_time: "",
				sync_active: "",
				isSyncActive: false,
				couns_name: "",
				couns_pernr: "",
				disableValidate: true

			});
			this.getView().setModel(this.model);
			this.validateUser();
			this.getEname();
			this.getRouter().attachRouteMatched(this.onRouteMatched.bind(this));

		},
		getEname: function () {
			var sEname = "/getEnameSet('00000')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		pernrKey: null,
		validateEmp: function () {
			// this.model.setProperty("/isVisible", true);
			var empNo = this.getView().byId("idEmpNo").getValue();
			if (empNo !== "") {
				var validateEmp = "/empVerificationSet('" + empNo + "')";
				this.benefitsModel().read(validateEmp, {
					success: this.handleValidateSuccess.bind(this),
					error: this.handleError.bind(this)
				});
			} else {
				this.getView().byId("idEmpNo").setValueState("Error");
				this.getView().byId("idEmpNo").setvalueStateText("Emp id is required");
			}

		},
		handleError: function (data) {
			this.getView().byId("idEmpNo").setValueState("Error");
		},
		handleValidateSuccess: function (data) {
			if (data.ssn === "" && data.dob === "" && data.ename === "") {
				this.getView().byId("idEmpNo").setValueState("Error");
			} else {
				this.model.setProperty("/isVisible", true);
				this.model.setProperty("/ssn", data.ssn);
				this.model.setProperty("/dob", data.dob);
				this.model.setProperty("/ename", data.ename);
				this.getView().byId("idEmpNo").setValueState("Success");
				this.getView().byId("nextButton").setVisible(true);
				this.pernrKey = data.pernr;

			}
		},
		onClear: function () {
			this.model.setProperty("/isVisible", false);
			this.getView().byId("idEmpNo").setValueState("None");
			this.getView().byId("idEmpNo").setValue("");
			this.getView().byId("nextButton").setVisible(false);
		},
		currentRoute: null,
		onRouteMatched: function (event) {
			this.currentRoute = event.getParameter("name");
		},

		onBeforeRendering: function () {

		},
		onDesync: function () {
			var otoday = new Date();
			var oTime = otoday;
			var dd = String(otoday.getDate()).padStart(2, '0');
			var mm = String(otoday.getMonth() + 1).padStart(2, '0'); //January is 0!
			var yyyy = otoday.getFullYear();
			otoday = yyyy + mm + dd;
			var hh = String(oTime.getHours());
			var min = String(oTime.getMinutes());
			var ss = String(oTime.getSeconds());
			oTime = hh + min + ss;

			var payload = {
				"validate": "true",
				"pernr": this.pernrKey,
				"emp_name": this.model.getProperty("/ename"),
				"terminal": "",
				"zsync_date": this.model.getProperty("/zsync_date"),
				"zsync_time": this.model.getProperty("/zsync_time"),
				"zdsync_date": otoday,
				"zdsync_time": oTime,
				"sync_active": "",
				"couns_name": this.model.getProperty("/couns_name")
			};

			var that = this;
			this.benefitsModel().update("/proxyEmpSet('true')", payload, {
				success: function () {
					that.model.setProperty("/disableValidate", true);
					that.model.setProperty("/isSyncActive", false);
					location.reload();
				}

			});
		},
		goToNextStep: function () {
			var otoday = new Date();
			var oTime = otoday;
			var dd = String(otoday.getDate()).padStart(2, '0');
			var mm = String(otoday.getMonth() + 1).padStart(2, '0'); //January is 0!
			var yyyy = otoday.getFullYear();
			otoday = yyyy + mm + dd;
			var hh = String(oTime.getHours());
			var min = String(oTime.getMinutes());
			var ss = String(oTime.getSeconds());
			oTime = hh + min + ss;

			var payload = {
				"validate": "true",
				"pernr": this.pernrKey,
				"emp_name": this.model.getProperty("/ename"),
				"terminal": "",
				"zsync_date": otoday,
				"zsync_time": oTime,
				"sync_active": "A",
				"couns_name": this.model.getProperty("/couns_name")
			};

			var that = this;
			this.benefitsModel().update("/proxyEmpSet('true')", payload, {
				success: function () {
					that.getRouter().navTo(
						"LandingPage", {
							Pernr: that.pernrKey
						});
				}

			});

		},
		continueProxy: function () {
			this.getRouter().navTo(
				"LandingPage", {
					Pernr: this.pernrKey
				});
		},
		validateUser: function () {
			var proxy = "/proxyEmpSet('X')";
			this.benefitsModel().read(proxy, {
				success: this.handleproxySuccess.bind(this)
			});
		},
		handleproxySuccess: function (data) {
			this.model.setProperty("/isHRCRep", data.validate);
			if (data.validate === "false") {
				this.getRouter().navTo("LandingPage", {
					Pernr: data.pernr
				});
			} else {
				this.model.setProperty("/pageVisible", true);
				if (data.sync_active === 'A') {
					this.model.setProperty("/isHRCRep", data.validate);
					this.model.setProperty("/disableValidate", false);
					this.model.setProperty("/isSyncActive", true);

				}
				this.model.setProperty("/couns_name", data.couns_name);
				this.model.setProperty("/couns_pernr", data.pernr);
				this.pernrKey = data.pernr;
				this.model.setProperty("/emp_name", data.emp_name);
				this.model.setProperty("/terminal", data.terminal);
				this.model.setProperty("/zsync_date", data.zsync_date);
				this.model.setProperty("/zsync_time", data.zsync_time);
				this.model.setProperty("/sync_active", data.sync_active);
				this.model.setProperty("/busyVisible", false);
			}
		}

	});

});