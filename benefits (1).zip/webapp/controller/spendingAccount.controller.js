sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.spendingAccount", {
		onInit: function () {
			this.getRouter().getRoute("SpendingAccStep").attachPatternMatched(this.onRouteMatched.bind(this));
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.getPlans();
		},

		initLocalModel: function () {
			this.model = new JSONModel({
				freq: []
			});
			this.getView().setModel(this.model);
		},

		getPlans: function () {

			var oPFilter = new Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			var oEFilter = new Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});
			this.benefitsModel().read("/empSpendingAccSet", {
				filters: [oPFilter, oEFilter],
				success: this.getRelevantPlans.bind(this)
			});
		},

		getRelevantPlans: function (result) {
			var that = this;
			result.results.forEach(function (plan) {
				that.model.setProperty("/selectedPlan" + plan.pltyp, plan);
			});
		},

		onPlanSelect: function (oEvent) {

			var pltyp;
			var oButton = oEvent.getSource();
			if (oButton.getId().indexOf("HSA") !== -1) {
				pltyp = "HCFX";
			} else {
				pltyp = "DCFX";
			}
			var modelData = this.model.getProperty("/selectedPlan" + pltyp);
			if (modelData.enrolled) {
				modelData.enrolled = "";
				modelData.contribution = "0.00";
				modelData.frequency = "";
				this.key = this.benefitsModel().createKey("/empSpendingAccSet", {
					pernr: modelData.pernr,
					begda: modelData.begda,
					endda: modelData.endda,
					pltyp: modelData.pltyp,
					event: modelData.event
				});
				var that = this;
				this.benefitsModel().update(this.key, modelData, {
					success: function (result) {
						that.getPlans.bind(that);
						that.getDeductions();
					},
					error: function (ret) {}
				});

			} else {
				this.model.getProperty("/selectedPlan" + pltyp).enrolled = "X";
				this.model.getProperty("/selectedPlan" + pltyp).frequency = "A";
			}
			this.getView().getModel().refresh(true);
		},

		getDeductions: function () {
			var deductions = "/totalDeduction(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";
			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});
		},
		handleDeductionSuccess: function (data) {
			var wizardModel = this.getView().getParent().getParent().getParent().getModel();
			wizardModel.setProperty("/premium", data.premium);
		},
		onAmountInput: function (oEvent) {
			var convertContribution;
			var that = this;
			
			var parser = new sap.ui.model.type.Float();
			
			if (oEvent.getSource().getId().indexOf("idDSA") !== -1) {
				var modelData = this.getView().getModel().getProperty("/selectedPlanDCFX");
				modelData.contribution = parser.parseValue(this.getView().byId("idDSA").getAggregation("_contributionInput").getValue(), "string");
			} else {
				modelData = this.getView().getModel().getProperty("/selectedPlanHCFX");
				modelData.contribution = parser.parseValue(this.getView().byId("idHSA").getAggregation("_contributionInput").getValue(), "string");
			}
			if (modelData.contribution.toString() === "NaN") {
					oEvent.getSource().getAggregation("_contributionInput").setValueState("Error");
				oEvent.getSource().getAggregation("_contributionInput").setValueStateText(
					"Error: Not a Number");
				return;
			}
			if (modelData.frequency === "P") {
				convertContribution = modelData.contribution * modelData.total_pay_cheque;
			} else {
				convertContribution = modelData.contribution;
			}

			if (parseFloat(convertContribution) >= parseFloat(modelData.min_contri) &&
				parseFloat(convertContribution) <= parseFloat(modelData.max_contri)) {
				oEvent.getSource().getAggregation("_contributionInput").setValueState("None");
			} else {
				oEvent.getSource().getAggregation("_contributionInput").setValueState("Error");
				oEvent.getSource().getAggregation("_contributionInput").setValueStateText(
					"Error: Amount is outside of minimum or maximum allowable contribution.");
				return;
			}
			this.key = this.benefitsModel().createKey("/empSpendingAccSet", {
				pernr: modelData.pernr,
				begda: modelData.begda,
				endda: modelData.endda,
				pltyp: modelData.pltyp,
				event: modelData.event
			});

			modelData.contribution = modelData.contribution.toString();
			this.benefitsModel().update(this.key, modelData, {
				success: function (result) {
					that.getPlans.bind(that);
					that.getDeductions();
				},
				error: function (ret) {}
			});
		},
		goHome: function () {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		}
	});
});