sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button",
	"sap/m/MessageBox",
	"sap/m/DialogType",
	"sap/m/ButtonType",

], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	MessageToast,
	Fragment,
	Dialog,
	Text,
	Button,
	MessageBox,
	DialogType,
	ButtonType
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.SuppInsurance", {
		onInit: function () {
			this.getHelpfulLinks();
			this.getRouter().getRoute("SuppInsStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.getRouter().getRoute("SuppInsurance").attachPatternMatched(this.onRouteMatched.bind(this));
			if (sap.ui.core.format.NumberFormat) {
				this.currencyFormatter = sap.ui.core.format.NumberFormat.getCurrencyInstance();
			}
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.routeName = route.getParameters().name;
			this.initLocalModel();
			this.getInsurances();
			this.getHeaderInformation();

		},
		suppEmp: null,
		suppSpouse: null,
		suppChild: null,
		initLocalModel: function () {
			this.model = new JSONModel({
				insurances: {},
				currency: "$",
				SUPPPremium: "0",
				SPLPPremium: "0",
				DEPCPremium: "0",
				employeeName: "You",
				enableSubmit: false,
				enableNext: true
			});
			this.getView().setModel(this.model);
		},
		getHeaderInformation: function () {
			var key = this.benefitsModel()
				.createKey("/empl_headSet", this.routeArgs);
			this.benefitsModel().read(key, {
				success: function (header) {
					this.model.setProperty("/employeeName", header.ename);
				}.bind(this)
			});
		},
		getInsurances: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: this.transformInsurances.bind(this)
			});
		},
		transformInsurances: function (result) {
			var insurances = {
				SUPP: {
					name: "SUPP",
					enabled: true,
					selectedKey: null,
					amounts: [],
					enrolled: false
				},
				SPLP: {
					name: "SPLP",
					enabled: false,
					selectedKey: null,
					amounts: [],
					enrolled: false
				},
				DEPC: {
					name: "DEPC",
					enabled: false,
					selectedKey: null,
					amounts: [],
					enrolled: false
				}
			};

			result.results.sort(function (a, b) {
				var aAmount = parseFloat(a.amount, 10);
				var bAmount = parseFloat(b.amount, 10);
				if (aAmount > bAmount) {
					return 1;
				} else if (bAmount > aAmount) {
					return -1;
				} else {
					return 0;
				}
			}).forEach(function (i) {
				if (!insurances[i.bplan]) {
					insurances[i.bplan] = {
						name: i.bplan,
						enabled: i.bplan === "SUPP",
						selectedKey: null,
						amounts: [],
						enrolled: false
					};
				}

				insurances[i.bplan].amounts.push({
					key: i.bopti,
					amount: i.amount,
					premium: i.premium || 0,
					sapElement: i
				});
				if (i.enrolled) {
					insurances[i.bplan].selectedKey = i.bopti;
					insurances[i.bplan].enrolled = true;
					this.model.setProperty("/" + i.bplan + "Premium", i.premium || 0);
				}
			}.bind(this));
			if (insurances.SUPP.selectedKey !== null) {
				insurances.SPLP.enabled = true;
				insurances.DEPC.enabled = true;
			}
		
			if (this.routeName === "SuppInsurance") {
				var LandingPageValidations = this.landingPageValidations(insurances);
				insurances = LandingPageValidations;
			}
			this.model.setProperty("/insurances", insurances);
			var showSpouseInsurance = false;
			for (var i = 0; i <= result.results.length - 1; i++) {
				if (result.results[i].pltyp === "SPLP") {
					showSpouseInsurance = true;
					break;
				}
			}
			if (this.getView().byId("suppSpouse")) {
				this.getView().byId("suppSpouse").setVisible(showSpouseInsurance);

			} else {
				this.getView().getAggregation("content")[0].getAggregation("content")[0].byId("suppSpouse").setVisible(showSpouseInsurance);
			}

			if (!this.model.getProperty("/insurances/SUPP/enrolled")) {
				if (this.getView().byId("suppEmp")) {
					this.getView().byId("suppEmp").getAggregation("_slider").setProperty("enabled",
						this.model.getProperty("/insurances/SUPP/enrolled"));
				} else {
					this.getView().getAggregation("content")[0].getAggregation("content")[0].
					byId("suppEmp").getAggregation("_slider").setProperty("enabled",
						this.model.getProperty("/insurances/SUPP/enrolled"));
				}
			}
			if (!this.model.getProperty("/insurances/SPLP/enrolled")) {
				if (this.getView().byId("suppSpouse")) {
					this.getView().byId("suppSpouse").getAggregation("_slider").setProperty("enabled",
						this.model.getProperty("/insurances/SPLP/enrolled"));

				} else {
					this.getView().getAggregation("content")[0].getAggregation("content")[0].
					byId("suppSpouse").getAggregation("_slider").setProperty("enabled",
						this.model.getProperty("/insurances/SPLP/enrolled"));
				}
			}
			if (this.routeName === "SuppInsurance") {
				if (!this.model.getProperty("/insurances/SUPP/enrolled")) {
					if (this.getView().getParent().getParent().byId("nextButton")) {
						this.getView().getParent().getParent().byId("nextButton").setVisible(false);
						this.getView().getParent().getParent().byId("submitButton").setVisible(true);
					} else {
						this.getView().byId("nextButton").setVisible(false);
						this.getView().byId("submitButton").setVisible(true);
					}
				}else{
					if (this.getView().getParent().getParent().byId("nextButton")) {
						this.getView().getParent().getParent().byId("nextButton").setVisible(true);
						this.getView().getParent().getParent().byId("submitButton").setVisible(false);
					} else {
						this.getView().byId("nextButton").setVisible(true);
						this.getView().byId("submitButton").setVisible(false);
					}
				}
				// debugger;
				// if(this.getView().getContent()[0].getContent()[0].getProperty("viewName").indexOf("wizardFragment") !==-1){
				// 		var model = this.getView().getContent()[0].getContent()[0].getModel();
				// 		model.setProperty("/insurances",this.model.getProperty("/insurances"));
				// }
			}
		},
		formatPremiumValue: function (value, currency, frequency) {
			var val = this.currencyFormatter.format([value, currency]);
			return frequency.replace("{0}", val);
		},
		noEventerror: false,
		landingPageValidations: function (insurances) {
			//Additional Rules To only allow to reduce coverage from Landing Page

			//Check for If the person is enrolled in a plan
			if (insurances.DEPC) {
				if (insurances.DEPC.selectedKey === null) {
					insurances.DEPC.enabled = false;
				}
			}
			if (insurances.SPLP) {
				if (insurances.SPLP.selectedKey === null) {
					insurances.SPLP.enabled = false;
				} else {
					var splpAmount = insurances.SPLP.amounts.filter(function (p) {
						return p.key <= insurances.SPLP.selectedKey;
					});
					insurances.SPLP.amounts = splpAmount;
				}
			}

			if (insurances.SUPP) {
				//If no SUPP, cannot select anything else as well
				if (insurances.SUPP.selectedKey === null) {
					insurances.SUPP.enabled = false;
					insurances.SPLP.enabled = false;
					insurances.DEPC.enabled = false;
				} else {
					var suppAmount = insurances.SUPP.amounts.filter(function (p) {
						return p.key <= insurances.SUPP.selectedKey;
					});
					insurances.SUPP.amounts = suppAmount;
				}
			}
			return insurances;
		},
		validateSelections: function () {
			this.suppEmp = this.model.getProperty("/insurances/SUPP/enrolled");
			this.suppSpouse = this.model.getProperty("/insurances/SPLP/enrolled");
			this.suppChild = this.model.getProperty("/insurances/DEPC/enrolled");

			//Check suppSpouse
			if (this.routeArgs.Event === 'ANY') {
				if (this.suppSpouse === false || this.suppSpouse === null) {
					if (this.getView().byId("suppChild").getSelected() === true) {
						this.noEventerror = true;
					}
				}
				if (this.suppEmp === false || this.suppEmp === null) {
					if (this.getView().byId("suppEmp").getSelected() === true) {
						this.noEventerror = true;
					}
				}
				if (this.suppChild === false || this.suppChild === null) {
					if (this.getView().byId("suppChild").getSelected() === true) {
						this.noEventerror = true;
					}
				}
			}
		},
		onInsuranceChange: function (event) {
		
			var isDEPC, isSPLP;
			this.model = this.getView().getModel();
			isDEPC = this.model.getProperty("/insurances/DEPC/enrolled");
			isSPLP = this.model.getProperty("/insurances/SPLP/enrolled");

			if (this.routeName !== "SuppInsurance") {
				var wizardModel = this.getView().getParent().getParent().getParent().getModel();
				if (event.getSource().getSelected()) {
					wizardModel.setProperty("/showSupplementDependentStep", true);
				} else {
					wizardModel.setProperty("/showSupplementDependentStep", false);
				}
			}
			// this.validateSelections();
			var sliderKey = event.getSource().getSliderKey();
			var splpSliderKey = this.getView().byId("suppSpouse").getSliderKey();
			if (!this.noEventerror) {
				if (!event.getSource().getSelected()) {
					event.getSource().setSliderKey("0001");
					if (this.model.getProperty("/insurances/SPLP/enabled")) {
						this.getView().byId("suppSpouse").setSliderKey("0001");
					}
				}
				var obj = event.getSource()
					.getAggregation("sliderValues")
					.filter(function (i) {
						return i.getBindingContext().getProperty("sapElement").bopti === event.getParameter("selectedKey");
					})[0];

				if (!obj) {
					obj = event.getSource()
						.getAggregation("sliderValues")[0];
				}

				var sapElement = obj.getBindingContext()
					.getProperty("sapElement");
				sapElement.bopti = event.getParameter("selectedKey");
				var insuranceType = sapElement.bplan;
				var val = "X";
				if (!event.getParameter("selected")) {
					this.model.setProperty("/insurances/" + insuranceType + "/enrolled", null);
					this.model.setProperty("/" + insuranceType + "Premium", "0");
					val = "";
				} else {
					this.model.setProperty("/" + insuranceType + "Premium", sapElement.premium || "0");
				}
				var key = this.benefitsModel().createKey("/lifeInsHeadSet", sapElement);
				var bc = this.benefitsModel().createBindingContext(key);
				this.benefitsModel().setProperty("enrolled", val, bc);

				if (insuranceType === "SUPP" && event.getParameter("selected")) {
					//need to unenroll in all other insurances if user is unenrolling in supp
					this.model.setProperty("/insurances/SPLP/enabled", true);
					this.model.setProperty("/insurances/DEPC/enabled", true);
				}
				if (insuranceType === "SPLP" && !event.getParameter("selected")) {
					//Disable slider Movement
					this.getView().byId("suppSpouse").getAggregation("_slider").setProperty("enabled", event.getParameter("selected"));
				} else if (insuranceType === "SPLP" && event.getParameter("selected")) {
					//Enable slider Movement
					this.getView().byId("suppSpouse").getAggregation("_slider").setProperty("enabled", event.getParameter("selected"));
				}
				if (insuranceType === "SUPP" && !event.getParameter("selected")) {
					//Disable slider Movement

					this.getView().byId("suppEmp").getAggregation("_slider").setProperty("enabled", event.getParameter("selected"));
					//need to unenroll in all other insurances if user is unenrolling in supp
					this.model.setProperty("/insurances/SPLP/enabled", false);
					this.model.setProperty("/insurances/DEPC/enabled", false);

					this.model.setProperty("/insurances/SPLP/enrolled", false);
					this.model.setProperty("/insurances/DEPC/enrolled", false);
					this.getView().byId("suppSpouse").setSelected(false);
					this.getView().byId("suppChild").setSelected(false);
					this.model.setProperty("/SPLPPremium", "0");

					this.model.getProperty("/insurances/SPLP/amounts")
						.concat(this.model.getProperty("/insurances/DEPC/amounts"))
						.forEach(function (a) {
							var key = this.benefitsModel().createKey("/lifeInsHeadSet", a.sapElement);
							var bc = this.benefitsModel().createBindingContext(key);
							this.benefitsModel().setProperty("enrolled", "", bc);
						}.bind(this));
				} else if (insuranceType === "SUPP" && event.getParameter("selected")) {
					//Enable slider Movement
					this.getView().byId("suppEmp").getAggregation("_slider").setProperty("enabled", event.getParameter("selected"));
				}
				var boolEnrolled;
				if (event.getSource().getSelected()) {
					boolEnrolled = "X";
				} else {
					boolEnrolled = "";
				}
				if (insuranceType === "SPLP" || insuranceType === "DEPC") {
					this.updateToBackEnd(key, sliderKey, insuranceType, boolEnrolled);

				}
				if (insuranceType === "SUPP") {
					//If increase of Coverage/Enroll
					if (event.getSource().getSelected()) {
						this.updateToBackEnd(key, sliderKey, insuranceType, boolEnrolled);
					} else {

						//Remove All Coverages
						//Child Coverage Removal
						if (isDEPC) {
							var depcKey = "/lifeInsHeadSet(event='" + this.routeArgs.Event + "',pltyp='DEPC',bopti='0001')";

							this.updateToBackEnd(depcKey, "0001", "DEPC", "");
						}
						//Spouse Coverage Removal
						if (isSPLP) {
							var splpKey = "/lifeInsHeadSet(event='" + this.routeArgs.Event + "',pltyp='SPLP',bopti='" + splpSliderKey + "')";
							if (!this.model.getProperty("/insurances/SPLP/enrolled")) {
								if (this.getView().byId("suppSpouse").getVisible()) {
									this.updateToBackEnd(splpKey, splpSliderKey, "SPLP", "");
								}
							}
						}
						//Emp Coverage Removal
						this.updateToBackEnd(key, sliderKey, "SUPP", "");
					}

				}

			} else {

				this.getView().byId("suppEmp").setSelected(this.suppEmp);
				this.getView().byId("suppSpouse").setSelected(this.suppSpouse);
				this.getView().byId("suppChild").setSelected(this.suppChild);
				this.noEventerror = false;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					" You can only cancel or reduce coverage; cannot add new or increase your coverage. For More details, contact HRC", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
		},
		updateToBackEnd: function (key, sliderKey, insuranceType, boolEnrolled) {
			if (this.routeName === "SuppInsurance") {
				if (!this.model.getProperty("/insurances/SUPP/enrolled")) {
					this.getView().getParent().getParent().byId("nextButton").setVisible(false);
					this.getView().getParent().getParent().byId("submitButton").setVisible(true);
				}
			}
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var that = this;
			var amount = this.getModel().getProperty("/insurances/" + insuranceType + "/");
			var payload = amount.amounts.filter(function (p) {
				return p.key === sliderKey;
			});

			payload[0].sapElement.enrolled = boolEnrolled;

			this.benefitsModel().update(key, payload[0].sapElement, {
				success: function () {
					that.getInsurances();
					that.getDeductions();
					oBusy.close();
				},
				error: function () {
					oBusy.close();
				}
			});
		},
		getDeductions: function () {

			var deductions = "/totalDeduction(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";

			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});
		},
		handleDeductionSuccess: function (data) {
			var wizardModel = this.getView().getParent().getParent().getParent().getModel();
			wizardModel.setProperty("/premium", data.premium);
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},
		toSuppBene: function (evt) {
			var that = this;
			this.getRouter()
				.navTo("SuppBeneficiaries", {
					Pernr: that.routeArgs.Pernr,
					Event: that.routeArgs.Event,
					Begda: that.routeArgs.Begda,
					Endda: that.routeArgs.Endda
				});
		},
		reset: function () {
			
			
			
			
			
			var pltyp = "SUPP";
			var bopti = "0001";
			var that = this;
			var key = "/resetValuesSet(Pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "',pltyp='" + pltyp +
				"',bplan='" + pltyp + "',bopti='" + bopti + "')";

			this.benefitsModel().remove(key, {
				method: "DELETE",
				success: function (data) {
					// that.getRouter().getRoute("SuppInsurance").attachPatternMatched(that.onRouteMatched.bind(this));
					// that.initLocalModel();
					// that.getInsurances();
					// that.getHeaderInformation();
					MessageBox.alert("Reset Successfull, please make sure your beneficiaries are correct and press back to make any changes",{
						onClose:function(){
							that.getView().byId("nextButton").firePress();		
						}
					});
					
				}
			});

		},
		getHelpfulLinks: function () {
			var languageFilter = new Filter({
				path: "spras",
				operator: FilterOperator.EQ,
				value1: "E"
			});
			this.benefitsModel().read("/benefits_linkSet", {
				filters: [languageFilter],
				success: this.handleLinks.bind(this)
			});
		},
		handleLinks: function (links) {
			//TAC URL
			var linkArray = links.results.filter(function (l) {
				return l.url_id.startsWith("TAC");
			});
			this.getModel("helpfullinks").setProperty("/links", linkArray);

			//BCLF URL
			var bclfArray = links.results.filter(function (l) {
				return l.url_id.startsWith("BCLF");
			});
			this.getModel("helpfullinks").setProperty("/bclfLinks", bclfArray);
			//MetLife URL
			var metLife = links.results.filter(function (l) {
				return l.url_id.startsWith("MET");
			});
			if (metLife.length > 0) {
				this.getModel("helpfullinks").setProperty("/metLife", metLife[0].url);
				this.getModel("helpfullinks").setProperty("/metLifeText", metLife[0].text);
			}
			//SUPP Ins URL
			var suppIns = links.results.filter(function (l) {
				return l.url_id.startsWith("SUPP_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/suppInsLinks", suppIns);
			// if (suppIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/suppIns", suppIns[0].url);
			// }
			//SPLP Ins
			var splpIns = links.results.filter(function (l) {
				return l.url_id.startsWith("SPLP_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/splpInsLinks", splpIns);
			// if (suppIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/splpIns", splpIns[0].url);
			// }
			//DEPC Ins
			var depcIns = links.results.filter(function (l) {
				return l.url_id.startsWith("DEPC_LIFE");
			});
			this.getModel("helpfullinks").setProperty("/depcInsLinks", depcIns);
			// if (depcIns.length > 0) {
			// 	this.getModel("helpfullinks").setProperty("/depcIns", depcIns[0].url);
			// }
			//Medical Url
			var medical = links.results.filter(function (l) {
				return l.url_id.startsWith("AMED_");
			});
			if (medical.length > 0) {
				this.getModel("helpfullinks").setProperty("/AMED", medical);
			}
			var dental = links.results.filter(function (l) {
				return l.url_id.startsWith("DENT_");
			});
			if (dental.length > 0) {
				this.getModel("helpfullinks").setProperty("/DENT", dental);
			}
			var vision = links.results.filter(function (l) {
				return l.url_id.startsWith("VISN_");
			});
			if (vision.length > 0) {
				this.getModel("helpfullinks").setProperty("/VISN", vision);
			}
			//ASK HR URL
			var askHRArray = links.results.filter(function (l) {
				return l.url_id.startsWith("ASK_HR");
			});
			if (askHRArray.length > 0) {
				this.getModel("helpfullinks").setProperty("/askHR", askHRArray[0].url);
			}

			var that = this;
			//Supplemental Life Changes
			var suppInsLink = this.getModel("helpfullinks").getProperty("/suppInsLinks");
			if (suppInsLink.length > 0 && suppInsLink !== undefined) {
				var suppIns = suppInsLink.filter(function (p) {
					return p.event === that.routeArgs.Event;
				});
				if (suppIns.length > 0) {
					this.getModel("helpfullinks").setProperty("/suppIns", suppIns[0].url);
				}
			}
			//Supplemental Spouse Life Changes

			var splpInsLink = this.getModel("helpfullinks").getProperty("/splpInsLinks");
			if (splpInsLink.length > 0 && splpInsLink !== undefined) {
				var splpIns = splpInsLink.filter(function (p) {
					return p.event === that.routeArgs.Event;
				});
				if (splpIns.length > 0) {
					this.getModel("helpfullinks").setProperty("/splpIns", splpIns[0].url);
				}
			}
			//Supp Child Changes

			var depcInsLink = this.getModel("helpfullinks").getProperty("/depcInsLinks");
			if (depcInsLink.length > 0 && depcInsLink !== undefined) {
				var depcIns = depcInsLink.filter(function (p) {
					return p.event === that.routeArgs.Event;
				});
				if (depcIns.length > 0) {
					this.getModel("helpfullinks").setProperty("/depcIns", depcIns[0].url);
				}
			}
		},
		toSummary: function () {
			var that = this;
			if (!this.oConfirmation) {
				this.oConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Submit?."
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							//Get the model of the child view and check 100% prim ben
							that.oConfirmation.close();
							var key = that.benefitsModel().createKey("/resetValuesSet", {
								Pernr: that.routeArgs.Pernr,
								event: that.routeArgs.Event,
								pltyp: "SUPP",
								bplan: "SUPP",
								bopti: "0001"
							});
							var payload = {};
							payload.Pernr = that.routeArgs.Pernr;
							payload.event = that.routeArgs.Event;
							payload.pltyp = "SUPP";
							payload.bplan = "SUPP";
							payload.bopti = "0001";

							that.benefitsModel().update(key, payload, {
								method: "PUT",
								success: function (odata, Response) {
									that.getRouter()
										.navTo("CurrentBenefits", {
											Pernr: that.routeArgs.Pernr,
											Event: that.routeArgs.Event,
											Begda: that.routeArgs.Begda,
											Endda: that.routeArgs.Endda
										});

								},
								error: function (cc, vv) {

								}
							});

						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oConfirmation.open();

		}

	});
});