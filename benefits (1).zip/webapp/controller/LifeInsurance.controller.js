sap.ui.define([
	"dart/hcm/benefits/controller/BeneficiaryBase",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button",
	"sap/m/DialogType",
	"sap/m/ButtonType",
	"sap/m/MessageBox"
], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	MessageToast,
	Fragment,
	Dialog,
	Text,
	Button,
	DialogType,
	ButtonType,
	MessageBox
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.LifeInsurance", {
		onInit: function () {
			this.getRouter().getRoute("LifeInsStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.getRouter().getRoute("LifeInsurance").attachPatternMatched(this.onRouteMatched.bind(this));
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.getLifeInsuranceInfo();
			this.benefitsModel().read("/relationBeneficiarieSet");
			var languageFilter = new Filter({
				path: "spras",
				operator: FilterOperator.EQ,
				value1: "E"
			});
			var that = this;
			var PernrFilter = new Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			var bclfArray = this.getModel("helpfullinks").getProperty("/bclfLinks");
			if (bclfArray !== undefined) {
				var bclfLinks = bclfArray.filter(function (p) {
					return p.event === that.routeArgs.Event;
				});

				if (bclfLinks.length > 0) {
					this.getModel("helpfullinks").setProperty("/bclf", bclfLinks[0].url);
				}
			}

		},
		initLocalModel: function () {
			this.model = new JSONModel({
				showIndividualForm: false,
				showOrganizationForm: false,
				isEdit: false,
				dialogTitle: "",
				beneficiary: {},
				beneficiaries: [],
				totalPrimary: 0,
				totalContingent: 0,
				contingentStatus: "None",
				primaryStatus: "None",
				lifeInsuranceAmount: 0,
				lifeInsuranceCurrency: "$",
				plan: true,
				href: "",
				selectedPlan: {}
			});

			this.getView().setModel(this.model);
		},
		getLifeInsuranceInfo: function () {

			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: function (result) {
					var life = result.results.filter(function (i) {
						return i.bplan === "BCLF";
					})[0];
					if (life) {
						this.model.setProperty("/lifeInsuranceAmount", life.amount);
						this.model.setProperty("/selectedPlan", life);
						this.getBeneficiaries(life);
					} else {
						this.model.setProperty("/plan", false);
						this.model.setProperty("/selectedPlan", {});
					}
				}.bind(this)
			});
		},
		updateBeneficiaryAllocations: function () {
			var that = this;
			var allocations = {};
			this.model.getProperty("/beneficiaries").forEach(function (ben, index) {
				var key = ("00" + (index + 1)).slice(-2);
				allocations["dty" + key] = ben.sapBen.subty;
				allocations["did" + key] = ben.sapBen.objps;
				allocations["bpt" + key] = ben.primaryPercent || "0"; // these fields are strings in SAP
				allocations["cbpt" + key] = ben.contingentPercent || "0";
			});
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: function (result) {
					var life = result.results.filter(function (i) {
						return i.bplan === "BCLF";
					})[0];
					var path = this.benefitsModel().createKey("/lifeInsHeadSet", life);
					this.benefitsModel().update(path, Object.assign(life, allocations), {
						success: function (msg) {
							that.oBusyDialog.close();
						},
						error: function (msg) {
							that.oBusyDialog.close();
							MessageToast.show("there was an error saving allocations");
						}
					});
				}.bind(this)
			});
		},
		closeDialog: function () {
			this.getBeneficiaries(this.model.getProperty("/selectedPlan"));
			Controller.prototype.closeDialog.bind(this)();
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},

		reset: function () {
			var selectedPlan = this.model.getProperty("/selectedPlan");
			var key = "/resetValuesSet(Pernr='" + selectedPlan.Pernr + "',event='" + selectedPlan.event + "',pltyp='" + selectedPlan.pltyp +
				"',bplan='" + selectedPlan.bplan + "',bopti='" + selectedPlan.bopti + "')";

			this.benefitsModel().remove(key, {
				method: "DELETE",
				success: function (data) {
					window.location.reload();
				}
			});

		},

		toSummary: function () {
			var that = this;
			if (!this.oConfirmation) {
				this.oConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Submit?."
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							//Get the model of the child view and check 100% prim ben
							that.oConfirmation.close();
							var oModel = that.getView().getAggregation("content")[0].getAggregation("content")[0].getModel();
							if (oModel.getProperty("/primaryStatus") === "Error"  || oModel.getProperty("/contingentStatus") === "Error") {
								MessageBox.error("Primary percentage not equals 100%");
								return;
							} else {
								var selectedPlan = oModel.getProperty("/selectedPlan");
								var key = that.benefitsModel().createKey("/resetValuesSet", {
									Pernr: selectedPlan.Pernr,
									event: selectedPlan.event,
									pltyp: selectedPlan.pltyp,
									bplan: selectedPlan.bplan,
									bopti: selectedPlan.bopti
								});
								var payload = {};
								payload.Pernr = selectedPlan.Pernr;
								payload.event = selectedPlan.event;
								payload.pltyp = selectedPlan.pltyp;
								payload.bplan = selectedPlan.bplan;
								payload.bopti = selectedPlan.bopti;

								that.benefitsModel().update(key, payload, {
									method: "PUT",
									success: function (odata, Response) {
										that.getRouter()
											.navTo("CurrentBenefits", {
												Pernr: that.routeArgs.Pernr,
												Event: that.routeArgs.Event,
												Begda: that.routeArgs.Begda,
												Endda: that.routeArgs.Endda
											});

									},
									error: function (cc, vv) {

									}
								});
							}
						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oConfirmation.open();

		}
	});
});