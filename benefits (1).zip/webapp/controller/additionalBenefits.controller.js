sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"dart/hcm/benefits/utils/planUtils",
	"sap/ui/core/format/NumberFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/m/Button",
	"sap/m/DialogType",
	"sap/m/ButtonType",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/Text"
], function (
	Controller,
	JSONModel,
	PlanUtils,
	NumberFormat,
	Filter,
	FilterOperator,
	dependentUtils,
	Button,
	DialogType,
	ButtonType,
	MessageBox,
	Dialog,
	Text
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.additionalBenefits", {
		onInit: function () {
			this.getRouter().getRoute("AddBenStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.getRouter().getRoute("AdditionalBenefits").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.routeName = route.getParameters().name;
			this.initLocalModel();
			this.getPlans();
			this.getLinks();
		},
		initLocalModel: function () {
			this.model = new JSONModel({
				hasHospital: false,
				hasAccident: false,
				hasIllness: false,
				selectedHospital: "",
				selectedAccident: "",
				selectedIllness: "",
				accidentPremium: "$0.00 / month",
				hospitalPremium: "$0.00 / month",
				illnessPremium: "",
				hospitalLink: "",
				criticalLink: "",
				accidentLink: "",
				accidentAdditional: "",
				accidentAdditionalText: "",
				hospitalPlans: [],
				accidentPlans: [],
				checkBoxIllness: true,
				checkBoxAccident: true,
				checkBoxHospital: true,
				illnessPlans: [{
						text: this.getTranslatedText("employeeOnly"),
						key: "MCRI"
					},
					//   {
					// 	text: this.getTranslatedText("employeePlusSpouse"),
					// 	key: "SCRI"
					// }
				],
				selectedEmployeeIllnessValue: 0,
				selectedSpouseIllnessValue: 0,
				employeeIllnessValues: [],
				spouseIllnessValues: [],
				tobaccoUse: false,
				spouseTobaccoUse: false,
				rawData: []
			});
			this.getView().setModel(this.model);
			var that = this;
			var plan;
			this.oFilter = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});

			this.benefitsModel().read("/empDepBenSet", {
				filters: [this.oFilter],
				success: function (data) {
					var empPlusSpose = {
						text: that.getTranslatedText("employeePlusSpouse"),
						key: "SCRI"
					};
					that.plan = that.model.getProperty("/illnessPlans");
					for (var i = 0; i < data.results.length; i++) {
						if (data.results[i].subty === "1") {
							that.plan.push(empPlusSpose);
							break;
						}
					}
					that.model.setProperty("/illnessPlans", that.plan);
				}
			});

		},
		getLinks: function () {
			var languageFilter = new Filter({
				path: "spras",
				operator: FilterOperator.EQ,
				value1: "E"
			});
			this.getModel("benefits").read("/benefits_linkSet", {
				filters: [languageFilter],
				success: this.handleLinks.bind(this)
			});
		},
		handleLinks: function (links) {
			var hospitalLink = links.results.filter(function (l) {
				return l.url_id.startsWith("UNUM_HOSPITAL");
			});
			var criticalLink = links.results.filter(function (l) {
				return l.url_id.startsWith("UNUM_CRITICAL");
			});
			var accidentLink = links.results.filter(function (l) {
				return l.url_id.startsWith("UNUM_ACCIDENT");
			});
			var accidentAdditional = links.results.filter(function (l) {
				return l.url_id.startsWith("UNUM_ACC_FLYER");
			});
			if (hospitalLink[0]) {
				this.model.setProperty("/hospitalLink", hospitalLink[0].url);
			}
			if (criticalLink[0]) {
				this.model.setProperty("/criticalLink", criticalLink[0].url);
			}
			if (accidentLink[0]) {
				this.model.setProperty("/accidentLink", accidentLink[0].url);
			}
			if (accidentAdditional[0]) {
				this.model.setProperty("/accidentAdditional", accidentAdditional[0].url);
			}
			if (accidentAdditional[0]) {
				this.model.setProperty("/accidentAdditionalText", accidentAdditional[0].text);
			}

		},
		getPlans: function () {
			this.oMDVFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventMDVFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.oMDVFilter, this.oEventMDVFilter],
				success: function (result) {
					this.model.setProperty("/rawData", result.results.filter(function (r) {
						return ["DENT", "AMED", "VISN"].indexOf(r.pltyp) === -1;
					}));
					this.pivotPlans();
				}.bind(this)
			});
		},
		pivotPlans: function () {
			this.parsePlans("MHSI", "hospital");
			this.parsePlans("MACP", "accident");

			var hasEmployeeIllness = false;
			var hasSpouseIllness = false;
			// Employee only illness
			var employeeOnlyIllness = [];
			var employeePremium = "0";
			var coverageLevel = "0";
			var selectedEmployee;
			this.model.getProperty("/rawData")
				.filter(function (d) {
					return d.pltyp === "MCRI";
				}).forEach(function (p) {
					if (p.enrolled === "X") {
						hasEmployeeIllness = true;
						this.model.setProperty("/tobaccoUse", p.smoke === "X");
						// Start of Change by Mohit on 7.10.2020 for bug 125667
						//employeePremium = p.amount;
						employeePremium = p.premium;
						coverageLevel = p.amount;
						// End of Change by Mohit on 7.10.2020 for bug 125667
						selectedEmployee = p;
					}

					employeeOnlyIllness.push({
						value: parseFloat(p.amount || "0"),
						premium: p.amount,
						sapEntity: p
					});
				}.bind(this));
			employeeOnlyIllness = employeeOnlyIllness.sortByAttribute("value");
			this.model.setProperty("/employeeIllnessValues", employeeOnlyIllness);
			if (selectedEmployee) {
				var index = employeeOnlyIllness.findIndex(function (p) {
					return p.sapEntity === selectedEmployee;
				});
				this.model.setProperty("/selectedEmployeeIllnessValue", index);
			}

			// employee + spouse illness
			var employeeSpouseIllness = [];
			var spousePremium = "0";
			var spouseCoverage = "0";
			var selectedSpouse;
			this.model.getProperty("/rawData")
				.filter(function (d) {
					return d.pltyp === "SCRI";
				}).forEach(function (p) {
					if (p.enrolled === "X") {
						hasSpouseIllness = true;

						// Start of Change by Mohit on 7.10.2020 for bug 125667
						//spousePremium = p.amount;
						spousePremium = p.premium;
						spouseCoverage = p.amount;
						// End of Change by Mohit on 7.10.2020 for bug 125667
						this.model.setProperty("/spouseTobaccoUse", p.smoke === "X");
						selectedSpouse = p;
					}

					employeeSpouseIllness.push({
						value: parseFloat(p.amount || "0"),
						premium: p.amount,
						sapEntity: p
					});
				}.bind(this));
			employeeSpouseIllness = employeeSpouseIllness.sortByAttribute("value");
			this.model.setProperty("/spouseIllnessValues", employeeSpouseIllness);
			if (selectedSpouse) {
				var index = employeeSpouseIllness.findIndex(function (p) {
					return p.sapEntity === selectedSpouse;
				});
				this.model.setProperty("/selectedSpouseIllnessValue", index);
			}

			this.model.setProperty(
				"/illnessPremium",
				this.getTranslatedText(
					"perMonth",
					this.currencyFormatter.format([parseFloat(spousePremium) + parseFloat(employeePremium), "$"])
				)
			);
			if ( this.model.getProperty('/hasIllness') == false ) { //ADO#219661 To Fix issue Criticall Illness
				this.model.setProperty("/hasIllness", hasSpouseIllness || hasEmployeeIllness);
			}
			if (hasSpouseIllness) {
				this.model.setProperty("/selectedIllness", "SCRI");
			} else if (hasEmployeeIllness) {
				this.model.setProperty("/selectedIllness", "MCRI");
			}

			//From Landing Page, Employees can only reduce the coverage
			if (this.routeName === "AdditionalBenefits") {
				var that = this;
				//Accident Coverage
				if (this.model.getProperty("/hasAccident")) {
					this.getModel().setProperty("/checkBoxAccident", true);
					var allowedAccidentPlan = this.model.getProperty("/accidentPlans");
					allowedAccidentPlan.sort();
					var currentAccidentPremium = allowedAccidentPlan.filter(function (p) {
						return p.key === that.model.getProperty("/selectedAccident");

					});

					if (currentAccidentPremium[0].key === "EE") {
						allowedAccidentPlan = allowedAccidentPlan.filter(function(plan){
							return plan.key === "EE"
						});
					} else if (currentAccidentPremium[0].key === "EECH") {
						var index = allowedAccidentPlan.findIndex(function(plan){
							return plan.key === currentAccidentPremium[0].key
						});
						
						while(index < allowedAccidentPlan.length - 1){
							allowedAccidentPlan.pop();
						}
					} else if (currentAccidentPremium[0].key === "EESP") {
						allowedAccidentPlan.pop();
						var childIndex = allowedAccidentPlan.findIndex((el) => el.key === 'EECH');
						allowedAccidentPlan.splice(childIndex, 1);
					}

					this.model.setProperty("/accidentPlans", allowedAccidentPlan);
				} else {
					this.getModel().setProperty("/checkBoxAccident", false);
				}
				//Hospital Coverage
				if (this.model.getProperty("/hasHospital")) {
					this.getModel().setProperty("/checkBoxHospital", true);
					var allowedHospitalPlan = this.model.getProperty("/hospitalPlans");
					allowedHospitalPlan.sort();
					var currentHospitalPremium = allowedHospitalPlan.filter(function (p) {
						return p.key === that.model.getProperty("/selectedHospital");

					});
				
					if (currentHospitalPremium[0].key === "EE") {
						allowedHospitalPlan = allowedHospitalPlan.filter(function (plan) {
							return plan.key === currentHospitalPremium[0].key
						});
					} else if (currentHospitalPremium[0].key === "EECH") {
						index = allowedHospitalPlan.findIndex(function(plan){
							return plan.key === currentHospitalPremium[0].key
						});
						
						while(index < allowedHospitalPlan.length - 1){
							allowedHospitalPlan.pop();
						}
						
					} else if (currentHospitalPremium[0].key === "EESP") {
						allowedHospitalPlan.pop();
						var childIndex = allowedHospitalPlan.findIndex((el) => el.key === 'EECH');
						allowedHospitalPlan.splice(childIndex, 1);

					}
					this.model.setProperty("/hospitalPlans", allowedHospitalPlan);
				} else {
					this.getModel().setProperty("/checkBoxHospital", false);
				}
				//Illness Coverage
				if (this.model.getProperty("/hasIllness")) {
					this.getModel().setProperty("/checkBoxIllness", true);
					var allowedIllnessPlan = this.model.getProperty("/illnessPlans");
					allowedIllnessPlan.sort();
					var empOnlyIndex = employeeOnlyIllness.findIndex((e1) => e1.sapEntity.enrolled === "X");
					if (empOnlyIndex > -1) {
						empOnlyIndex = empOnlyIndex + 1;
						employeeOnlyIllness.splice(empOnlyIndex);
					}
					var currentIllnessPlan = this.model.getProperty("/selectedIllness");
					if (currentIllnessPlan === "MCRI") {

						allowedIllnessPlan.splice(1);
						this.model.setProperty("/selectedSpouseIllnessValue", "");
					}
					//Disable + button for Employee
					if (this.getView().byId("emplSlider")) {
						this.getView().byId("emplSlider").getAggregation("_rightButton").setEnabled(false);
					} else {
						this.getView().getAggregation("content")[0].getAggregation("content")[0].byId("emplSlider").getAggregation("_rightButton").setEnabled(
							false);
					}
					//Disable + button for Spouse
					if (this.getView().byId("spouseSlider")) {
						this.getView().byId("spouseSlider").getAggregation("_rightButton").setEnabled(false);
					} else {
						this.getView().getAggregation("content")[0].getAggregation("content")[0].byId("spouseSlider").getAggregation("_rightButton").setEnabled(
							false);
					}
					this.model.setProperty("/illnessPlans", allowedIllnessPlan);
				} else {
					this.getModel().setProperty("/checkBoxIllness", false);
				}

				// this.getView().getContent()[0].getContent()[0].setModel(this.getModel());
			}
		},
		parsePlans: function (key, type) {
			var plans = [];
			var lowerKey = type[0].toLowerCase() + type.substring(1);
			var upperKey = type[0].toUpperCase() + type.substring(1);
			this.model.getProperty("/rawData")
				.filter(function (d) {
					return d.pltyp === key;
				}).forEach(function (plan) {
					var premium = this.getTranslatedText("perMonth", plan.premium);
					plans.push({
						key: plan.depcv,
						type: plan.pltyp,
						text: this.getTranslatedText(PlanUtils.getTextKeyForPlanLevel(plan.depcv)),
						selectable: this.isPlanSelectable(plan),
						premium: premium,
						sapEntity: plan
					});

					if (plan.enrolled) {
						this.model.setProperty("/has" + upperKey, true);
						this.model.setProperty("/selected" + upperKey, plan.depcv);
						this.model.setProperty("/" + lowerKey + "Premium", premium);
					}
				}.bind(this));
			this.model.setProperty("/" + lowerKey + "Plans", plans);
		},
		reset: function () {
			var pltyp = "MHSI";
			var bopti = "0001";
			var that = this;
			var key = "/resetValuesSet(Pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "',pltyp='" + pltyp +
				"',bplan='" + pltyp + "',bopti='" + bopti + "')";

			this.benefitsModel().remove(key, {
				method: "DELETE",
				success: function (data) {
					location.reload();
					// window.location.reload();
					// that.getRouter().getRoute("AdditionalBenefits").attachPatternMatched(that.onRouteMatched.bind(this));
					// that.initLocalModel();
					// that.getPlans();
				}
			});

		},
		onPlanSelect: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			var plan = event.getParameter("selectedItem").getBindingContext().getProperty("");
			plan.sapEntity.Pernr = this.routeArgs.Pernr;
			if (plan.type === "MHSI") {
				this.model.setProperty("/hospitalPremium", plan.premium);
			} else if (plan.type === "MACP") {
				this.model.setProperty("/accidentPremium", plan.premium);
			}
			var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity));
			this.benefitsModel().setProperty("enrolled", "X", bc);
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity);
			plan.sapEntity.enrolled = "X";
			this.benefitsModel().update(key, plan.sapEntity, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});
		},
		getDeductions: function () {
			var deductions = "/totalDeduction(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";

			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});
		},
		handleDeductionSuccess: function (data) {
			var wizardModel = this.getView().getParent().getParent().getParent().getModel();
			wizardModel.setProperty("/premium", data.premium);
		},
		isPlanSelectable: function (plan) {
			return true;
		},
		onCheckboxUncheck: function (event) {
			if (!event.getParameter("selected")) {
				var eventId = event.getSource().getId();
				var plans = [];
				if (eventId.includes("hospital")) {
					this.model.setProperty("/selectedHospital", "");
					this.model.setProperty("/hospitalPremium", "$0.00 / month");
					plans = this.model.getProperty("/rawData").filter(function (d) {
						return d.pltyp === "MHSI";
					});
					var getEnrolledHospital = plans.filter(function (p) {
						return p.enrolled === "X";
					});
					//UnEnroll only if there is an Enrolled Plan
					if (getEnrolledHospital.length > 0) {
						this.unenrollPlans(getEnrolledHospital[0]);
					}
				} else if (eventId.includes("accident")) {
					this.model.setProperty("/selectedAccident", "");
					this.model.setProperty("/accidentPremium", "$0.00 / month");
					plans = this.model.getProperty("/rawData").filter(function (d) {
						return d.pltyp === "MACP";
					});
					var getEnrolledAccident = plans.filter(function (p) {
						return p.enrolled === "X";
					});
					//UnEnroll only if there is an Enrolled Plan
					if (getEnrolledAccident.length > 0) {
						this.unenrollPlans(getEnrolledAccident[0]);
					}
				} else if (eventId.includes("illness")) {
					//Get Employee Illness Plans
					var selectedIllnessPlans = [];
					this.model.setProperty("/selectedIllness", "");
					var illnessPlan = this.model.getProperty("/employeeIllnessValues");
					for (var i = 0; i < illnessPlan.length; i++) {
						selectedIllnessPlans.push(illnessPlan[i].sapEntity);
					}
					plans = selectedIllnessPlans.filter(function (d) {
						return d.pltyp === "MCRI" || d.pltyp === "SCRI";
					});
					var getEnrolledIllness = plans.filter(function (p) {
						return p.enrolled === "X";
					});
					//UnEnroll only if there is an Enrolled Plan
					if (getEnrolledIllness.length > 0) {
						this.unenrollPlans(getEnrolledIllness[0]);
					}
					//Get Spouse Illness Plans
					illnessPlan = this.model.getProperty("/spouseIllnessValues");
					for (i = 0; i < illnessPlan.length; i++) {
						selectedIllnessPlans.push(illnessPlan[i].sapEntity);
					}
					plans = selectedIllnessPlans.filter(function (d) {
						return d.pltyp === "MCRI" || d.pltyp === "SCRI";
					});
					getEnrolledIllness = plans.filter(function (p) {
						return p.enrolled === "X";
					});
					//UnEnroll only if there is an Enrolled Plan
					if (getEnrolledIllness.length > 0) {
						this.unenrollPlans(getEnrolledIllness[0]);
					}
				}

				// plans.forEach(function (p) {
				// 	var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", p));
				// 	this.benefitsModel().setProperty("enrolled", "", bc);
				// }.bind(this));
				// this.benefitsModel().submitChanges({
				// 	success: [this.getPlans(), this.getDeductions()]
				// });
			} else {
				//if the checkbox is checked update emp
				if (this.routeName === "AddBenStep") {
					var key = this.benefitsModel().createKey("/empl_headSet", {
						Pernr: this.routeArgs.Pernr,
						Begda: this.routeArgs.Begda,
						Endda: this.routeArgs.Endda
					});

					this.benefitsModel().update(key, {
						Pernr: this.routeArgs.Pernr,
						Begda: this.routeArgs.Begda,
						Endda: this.routeArgs.Endda,
						Event: this.routeArgs.Event,
						hospital: (event.getSource().getId().includes("hospital")).toString(),
						accident: (event.getSource().getId().includes("accident")).toString(),
						critical: (event.getSource().getId().includes("illness")).toString(),
						IdSession: "AddBenStep"
					});
				}
			}
		},
		unenrollPlans: function (plan) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan);
			plan.enrolled = "";
			this.benefitsModel().update(key, plan, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});
		},
		onEmployeeIllnessSelect: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			this.onEmployeeIllnessLiveChange(event);
			var value = event.getParameter("value");
			var plan = this.model.getProperty("/employeeIllnessValues")[value];
			var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity));
			this.benefitsModel().setProperty("enrolled", "X", bc);
			var smoke = this.model.getProperty("/tobaccoUse") == true ? "X" : "";
			this.benefitsModel().setProperty("smoke", smoke, bc);
			plan.sapEntity.smoke = smoke;
			plan.sapEntity.enrolled = "X";
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity);
			this.benefitsModel().update(key, plan.sapEntity, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});

		},
		onEmployeeIllnessLiveChange: function (event) {
			var value = event.getParameter("value");
			// var employeePremium = this.model.getProperty("/employeeIllnessValues")[value].premium;
			var employeePremium = this.model.getProperty("/employeeIllnessValues")[value].sapEntity.premium;

			var spouseValue = this.model.getProperty("/selectedSpouseIllnessValue");
			//var spousePremium = spouseValue ? this.model.getProperty("/spouseIllnessValues")[spouseValue].premium : "0";

			var spousePremium = spouseValue ? this.model.getProperty("/spouseIllnessValues")[spouseValue].sapEntity.premium : "0";

			var premium = this.getTranslatedText(
				"perMonth",
				this.currencyFormatter.format([parseFloat(spousePremium) + parseFloat(employeePremium), "$"])
			);

			this.model.setProperty("/illnessPremium", premium);
			this.model.setProperty("/selectedEmployeeIllnessValue", value);
		},
		onSpouseIllnessSelect: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			this.onSpouseIllnessLiveChange(event);
			var value = event.getParameter("value");
			var plan = this.model.getProperty("/spouseIllnessValues")[value];
			var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity));
			this.benefitsModel().setProperty("enrolled", "X", bc);
			var smoke = this.model.getProperty("/spouseTobaccoUse") == true ? "X" : "";
			this.benefitsModel().setProperty("smoke", smoke, bc);
			plan.sapEntity.smoke = smoke;
			plan.sapEntity.enrolled = "X";
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity);
			this.benefitsModel().update(key, plan.sapEntity, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});
		},
		onSpouseIllnessLiveChange: function (event) {
			var value = event.getParameter("value");
			//var spousePremium = this.model.getProperty("/spouseIllnessValues")[value].premium;
			var spousePremium = this.model.getProperty("/spouseIllnessValues")[value].sapEntity.premium;
			var employeeValue = this.model.getProperty("/selectedEmployeeIllnessValue");
			// var employeePremium = employeeValue ? this.model.getProperty("/employeeIllnessValues")[employeeValue].premium : "0";
			var employeePremium = employeeValue ? this.model.getProperty("/employeeIllnessValues")[employeeValue].sapEntity.premium : "0";

			var premium = this.getTranslatedText(
				"perMonth",
				this.currencyFormatter.format([parseFloat(spousePremium) + parseFloat(employeePremium), "$"])
			);

			this.model.setProperty("/illnessPremium", premium);
			this.model.setProperty("/selectedSpouseIllnessValue", value);
		},
		getValueFromIndex: function (index, values) {
			if (index === undefined || values === undefined || values.length === 0) {
				return "";
			}
			return this.currencyFormatter.format([
				values[index].value,
				"$"
			]);
		},
		onIllnessPlanChange: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			var newType = event.getParameter("selectedItem").getKey();
			// if (!newType) {
			// 	this.model.getProperty("/rawData").filter(function (p) {
			// 		return p.pltyp === "MCRI";
			// 	}).forEach(function (p) {
			// 		var bc = this.benefitsModel.createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", p));
			// 		this.benefitsModel().setProperty("enrolled", "", bc);
			// 	}.bind(this));
			// }

			//Emp+Spouse
			if (newType === "SCRI") {
				//Get Selected Employee Plan
				var empPlan = this.model.getProperty("/rawData").filter(function (p) {
					return p.pltyp === "SCRI" || p.pltyp === "MCRI";
				});
				var enrolledEmp = empPlan.filter(function (p) {
					return p.enrolled === "X";
				});
				//Get Binding Context
				var index = this.model.getProperty("/selectedSpouseIllnessValue");
				var selected = this.model.getProperty("/spouseIllnessValues")[index];
				var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", selected.sapEntity));

				selected.sapEntity.enrolled = "X";
				if (enrolledEmp.length !== 0) {
					//UnEnroll the Spouse Coverage only if the plan is MCRI
					if (newType !== "SCRI") {
						enrolledEmp[0].enrolled = "";
					}
					//Create Key
					var updateKey = this.benefitsModel().createKey("/mdvPlanSet", enrolledEmp[0]);

					////UnEnroll the Emp Coverage in the backend and Enroll Spouse Coverage
					this.benefitsModel().update(updateKey, enrolledEmp[0], {
						success: function () {
							that.benefitsModel().update(bc.getPath(), selected.sapEntity, {
								success: function () {
									jQuery.sap.delayedCall(500, this, function () {
										that.getPlans();
										that.getDeductions();
										oDialog.close();
									});
								},
								error: function () {
									oDialog.close();
								}
							});
						}
					});
				} else {
					empPlan = this.model.getProperty("/employeeIllnessValues")[0].sapEntity;
					empPlan.enrolled = "X";
					var empKey = this.benefitsModel().createKey("/mdvPlanSet", empPlan);
					var spouseKey = this.benefitsModel().createKey("/mdvPlanSet", selected.sapEntity);
					this.benefitsModel().update(empKey, empPlan, {
						success: function () {
							that.benefitsModel().update(spouseKey, selected.sapEntity, {
								success: function () {
									jQuery.sap.delayedCall(100, this, function () {
										that.getPlans();
										that.getDeductions();
										oDialog.close();
									});
								},
								error: function () {
									oDialog.close();
								}
							});
						}
					});
				}

			}

			//Employee Only
			if (newType === "MCRI") {
				//Get All SCRI Plans
				var spousePlan = this.model.getProperty("/rawData").filter(function (p) {
					return p.pltyp === "SCRI";
				});
				//Get Enrolled Plan
				var enrolledSpouse = spousePlan.filter(function (p) {
					return p.enrolled === "X";
				});

				index = this.model.getProperty("/selectedEmployeeIllnessValue");
				selected = this.model.getProperty("/employeeIllnessValues")[index];
				bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", selected.sapEntity));
				that = this;
				selected.sapEntity.enrolled = "X";

				if (enrolledSpouse.length !== 0) {
					//UnEnroll the Spouse Coverage
					enrolledSpouse[0].enrolled = "";
					//Create Key
					updateKey = this.benefitsModel().createKey("/mdvPlanSet", enrolledSpouse[0]);

					////UnEnroll the Spouse Coverage in the backend and Enroll Employee Coverage
					this.benefitsModel().update(updateKey, enrolledSpouse[0], {
						success: function () {
							that.benefitsModel().update(bc.getPath(), selected.sapEntity, {
								success: function () {
									jQuery.sap.delayedCall(100, this, function () {
										that.getPlans();
										that.getDeductions();
										oDialog.close();
									});
								},
								error: function () {
									oDialog.close();
								}
							});
						}
					});
				} else {
					var Empkey = this.benefitsModel().createKey("/mdvPlanSet", selected.sapEntity);
					this.benefitsModel().update(Empkey, selected.sapEntity, {
						success: function () {
							jQuery.sap.delayedCall(100, this, function () {
								that.getPlans();
								that.getDeductions();
								oDialog.close();
							});
						},
						error: function () {
							oDialog.close();
						}
					});
				}

			}

		},
		updateEmployeeTobacco: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;

			var tobacco = event.getParameter("selectedItem").getKey() === "true" ? "X" : "";
			var index = this.model.getProperty("/selectedEmployeeIllnessValue");
			var plan = this.model.getProperty("/employeeIllnessValues")[index];
			var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity));
			this.benefitsModel().setProperty("smoke", tobacco, bc);
			plan.sapEntity.smoke = tobacco;
			plan.sapEntity.enrolled = "X";
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity);
			this.benefitsModel().update(key, plan.sapEntity, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});
		},
		updateSpouseTobacco: function (event) {
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
			var that = this;
			var tobacco = event.getParameter("selectedItem").getKey() === "true" ? "X" : "";
			var index = this.model.getProperty("/selectedSpouseIllnessValue");
			var plan = this.model.getProperty("/spouseIllnessValues")[index];
			var bc = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity));
			this.benefitsModel().setProperty("smoke", tobacco, bc);
			plan.sapEntity.smoke = tobacco;
			plan.sapEntity.enrolled = "X";
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan.sapEntity);
			this.benefitsModel().update(key, plan.sapEntity, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getPlans();
						that.getDeductions();
						oDialog.close();
					});
				},
				error: function () {
					oDialog.close();
				}

			});
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},
		toSummary: function () {
			var that = this;
			if (!this.oConfirmation) {
				this.oConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Submit?."
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							//Get the model of the child view and check 100% prim ben
							that.oConfirmation.close();
							var key = that.benefitsModel().createKey("/resetValuesSet", {
								Pernr: that.routeArgs.Pernr,
								event: 'ANY',
								pltyp: 'UNUM',
								bplan: '5301',
								bopti: '0001'
							});
							var payload = {};
							payload.Pernr = that.routeArgs.Pernr;
							payload.event = 'ANY';
							payload.pltyp = 'UNUM';
							payload.bplan = '5301';
							payload.bopti = '0001';

							that.benefitsModel().update(key, payload, {
								method: "PUT",
								success: function (odata, Response) {
									that.getRouter()
										.navTo("CurrentBenefits", {
											Pernr: that.routeArgs.Pernr,
											Event: that.routeArgs.Event,
											Begda: that.routeArgs.Begda,
											Endda: that.routeArgs.Endda
										});

								},
								error: function (cc, vv) {

								}
							});
						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oConfirmation.open();

		}
	});
});