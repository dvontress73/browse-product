sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/Device",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/ButtonType",
	"sap/m/Button",
	"sap/m/Text",
	"sap/m/MessageBox",
	
], function (Controller, JSONModel, Filter, FilterOperator, Device, Dialog, DialogType, ButtonType, Button, Text, MessageBox) {
	"use strict";

	var controller;

	return Controller.extend("dart.hcm.benefits.controller.LandingPage", {
		
		onInit: function () {
			controller = this;
			
			this.texts = {};
			this.model = new JSONModel({
				titleText: "",
				canStartNewHire: false,
				canDoOpenEnrollment: false,
				canSeeBenefitsSummary: true,
				canEditDependents: true,
				canEditLifeInsurance: false,
				canEditSupplemental: false,
				canEditManagewell: false,
				canEditUNUMM: false,
				canSelectQLE: false,
				notEligible: false,
				allEvents: [],
				selectableEvents: [],
				welcomeText: "",
				inFlight: [],
				ieBrowser: false,
				disableProxyLink: false,
				isMobile: false,
				showContinue: false,
				showNoBclfError: false,
				showNoSuppError: false,
				hasSpouse: false,
				showState: false,
				qleText: "",
				qleSelection: "",
				hasQLE:false
			});

			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			// this.getView().setModel(oDeviceModel, "device");
			this.getView().setModel(this.model);
			if (oDeviceModel.getData().browser.name === 'ie') {
				this.model.setProperty("/ieBrowser", true);
				this.model.setProperty("/canSeeBenefitsSummary", false);
				this.model.setProperty("/canEditDependents", false);
			} else {

				this.getRouter()
					.getRoute("LandingPage")
					.attachPatternMatched(this.onRouteMatched.bind(this));
			}
			if (oDeviceModel.getData().system.phone) {
				this.model.setProperty("/isMobile", true);
				this.desktopView = false;
			}
			this.currentLanguage = this.getOwnerComponent().getModel("languageModel").getProperty("/currentLanguage");
			this.enableContinue();

			this.benefitsModel().callFunction("/getJellyVisionAvailability", {
				success : function(oData) {
					var d = oData.getJellyVisionAvailability;
					controller.OpenEnrollmentStartDate = d.StartDate;
					var now = new Date().getTime();
					
					if( now > d.AvailableFrom.getTime() && now < d.AvailableTo.getTime() ) {
						controller.byId("openEnrollmentEducationViaAskAlex").setVisible(true);
					} else {
						controller.byId("openEnrollmentEducationViaAskAlex").setVisible(false);
					}
				}
			} );
		},
		showAllTabsFn: function (pernr, event) {
			var that = this;
			this.benefitsModel().read("/continueEnrollmentSet(pernr='" + pernr + "',event='" + event + "')", {
				success: function (result) {
					if (result.showJV === "false") {
						that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", false);
					} else {
						that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", true);
					}
				}
			});
		},
		enableContinue: function () {
			var that = this;
			this.benefitsModel().read("/continueEnrollmentSet(pernr='" + this.pernrKey + "',event='" + this.currentEventCode + "')", {
				success: function (data) {
					controller.model.setProperty("/continueEnrollment", data);
					
					if (data.showContinue === "false") {
						if (that.getView().byId("clickToContinue")) {
							that.model.setProperty("/showContinue", false);
						}

					} else {
						if (that.getView().byId("clickToContinue")) {
							that.getView().byId("clickToContinue").setVisible(true);
							that.model.setProperty("/showContinue", true);
						}
					}
					if (data.showJV === "false") {
						that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", false);
					} else {
						that.getOwnerComponent().getModel("languageModel").setProperty("/showAllTabs", true);
					}

				}
			});
		},
		onRouteMatched: function (oEvt) {
			this.getProxyPernr(oEvt.getParameters().arguments.Pernr);
			this.getTexts();
			this.pernrKey = oEvt.getParameters().arguments.Pernr;
			this.getAllAvailableEvents();
			this.getCurrentBenefits();
			this.getInFlightChanges();
			this.getEname();
			this.validateUser();
			
		},

		findQLE: function () {
			this.benefitsModel().read("/qleExists('" + this.pernrKey + "')", {
				success: function (result) {
					this.model.setProperty("/hasQLE",result.hasQle);
					this.model.setProperty("/showContinue",result.hasQle);
					this.model.setProperty("/qleExists", result);
					
					this.model.checkUpdate(true);
				}.bind(this)
			});
		},

		currentLanguage: null,
		desktopView: true,
		onBeforeRendering: function () {
			var oHeader = this.getView().byId("pageHeader");
			var oVbox = this.getView().byId("hrcBox");
			if (!this.desktopView) {
				if (oHeader) {
					oHeader.removeAllContent();
				}
				if (oVbox) {
					oVbox.removeAllItems();
				}

				this.loadMobileFragment(oHeader);

			} else {
				if (oHeader) {
					oHeader.removeAllContent();
					this.loadDesktopFragment(oHeader);
				}
			}
			this.setLanguage();
			this.enableContinue();
		},
		onLanguageChange: function (oEvent) {

			if (this.desktopView) {
				this.changeLanguage(oEvent.getSource()._getSelectedItemText());
				this.getTexts(oEvent.getSource()._getSelectedItemText()); //Update Dynamic Text
			} else {
				this.createRadioButton();
				this.dialog.open();
			}

		},
		closeDialog: function () {
			this.dialog.close();
		},
		onMobileLanguageSelection: function (oEvent) {
			this.changeLanguage(oEvent.getSource().getSelectedButton().getText());
			this.getTexts(oEvent.getSource().getSelectedButton().getText()); //Update Dynamic Text
			this.dialog.close();
		},
		handleproxySuccess: function (data) {
			if (data.validate === "true") {
				this.model.setProperty("/disableProxyLink", true);
			}
		},
		reload: false,
		disableProxyLink: function () {
			this.reload = true;
			if (this.reload) {
				this.reload = false;
				this.getRouter()
					.navTo("ProxyPage", true);
				location.reload();
			}

		},
		validateUser: function () {
			var proxy = "/proxyEmpSet('X')";
			this.benefitsModel().read(proxy, {
				success: this.handleproxySuccess.bind(this)
			});
		},
		pernrKey: null,
		currentEvent: null,
		currentEventCode: null,
		getProxyPernr: function (data) {
			if (data !== "") {
				this.pernrKey = data;
			} else {
				this.pernrKey = "X";
			}
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.pernrKey
			});
		},
		getLandingPageLinks: function (pernr, event) {
			var landingPageLinks = "/landingPageLinksSet(pernr='" + pernr + "',event='" + event + "')";
			this.benefitsModel().read(landingPageLinks, {
				success: this.handleLinksSuccess.bind(this)
			});
		},
		
		handleLinksSuccess: function (data) {
			if (data.continueLink === "true") {
				data.continueLink = true;
			} else {
				data.continueLink = false;
			}
			if (data.bclfLink === "true") {
				data.bclfLink = true;
			} else {
				data.bclfLink = false;
			}
			if (data.suppLink === "true") {
				data.suppLink = true;
			} else {
				data.suppLink = false;
			}
			
			if( this.model.getProperty("/canSelectQLE") ) {
				this.benefitsModel().read("/check_server", {
					success: function (result) {
						if (result.results[0].server) {
							this.model.setProperty("/canSelectQLE", true);
						} else {
							this.model.setProperty("/canSelectQLE", false);
						}
					}.bind(this)
				});
			}
			
			if (!data.suppLink) {
				this.model.setProperty("/showNoSuppError", true);
			}
			if (!data.bclfLink) {
				this.model.setProperty("/showNoBclfError", true);
			}

			this.model.setProperty("/showContinue", data.continueLink);
		},
		getEname: function () {

			var sEname = "/getEnameSet('" + this.pernrKey + "')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		getTexts: function (filterValue) {
			var lang;
			if (typeof filterValue === "undefined" || filterValue === "English" || filterValue === "Inglés") {
				lang = "E";
			} else {
				lang = "S";
			}
			this.benefitsModel().read("/welcome_terms_textSet", {
				filters: [
					new Filter({
						path: "lang",
						operator: FilterOperator.EQ,
						value1: lang
					})
				],
				success: this.handleTextSuccess.bind(this)
			});
		},
		getAllAvailableEvents: function () {
			this.benefitsModel().read("/employeeAdjReasonSet", {
				filters: [this.oFilter],
				success: this.handleEventSuccess.bind(this)
			});
		},
		getCurrentBenefits: function () {
			this.benefitsModel().read("/empPlanSet", {
				success: this.handleCurrentBenefits.bind(this)
			});
		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		handleTextSuccess: function (data) {
			var welcome = data.results.filter(function (r) {
				return r.type === "welcome";
			})[0];
			this.model.setProperty("/welcomeText", this.sanitizeSapString(welcome.text));

			this.texts = data;
		},
		handleEventSuccess: function (data) {
			var that = this;
			this.getView().byId("clickToContinue").setVisible(false);
			this.currentEvent = data.results[0].AdjReasonCode;
			this.currentEventCode = data.results[0].AdjReasonCode;
			this.checkPermission(this.pernrKey, this.currentEventCode, "", "");
			var eventsAsLinks = ["HIRE", "OPEN", "ANY"];

			if (this.currentEvent === "ANY" || this.currentEvent === "NONE") {
				this.model.setProperty("/canSeeBenefitsSummary", true);
			}

			var events = data.results;
			var eventCodes = events.map(function (e) {
				return e.AdjReasonCode;
			});
			this.model.setProperty("/allEvents", events);
			this.model.setProperty("/selectableEvents", events.filter(function (e) {
				return eventsAsLinks.indexOf(e.AdjReasonCode) === -1;
			}));

			this.model.setProperty("/canStartNewHire", eventCodes.indexOf("HIRE") > -1);
			this.getView().byId("clickToContinue").setVisible(eventCodes.indexOf("HIRE") > -1);
			this.enableContinue();
			this.model.setProperty("/canDoOpenEnrollment", eventCodes.indexOf("OPEN") > -1);

			if (eventCodes.indexOf("HIRE") === -1 && eventCodes.indexOf("NONE") === -1) {
				this.model.setProperty("/canEditLifeInsurance", false);
				this.model.setProperty("/canEditSupplemental", false);
				this.model.setProperty("/canEditManagewell", true);
				this.model.setProperty("/canSelectQLE", true);
				
				this.model.setProperty("/canSelectAlex", true);
				// this.currentEvent = "HIRE";

			}
			if (eventCodes.indexOf("OPEN") === 0) {
				this.model.setProperty("/canSelectQLE", false);
				this.model.setProperty("/canSelectAlex", false);
				this.currentEvent = "OPEN";
			}

			if (eventCodes.indexOf("ANY") === 0) {
				this.model.setProperty("/canEditLifeInsurance", true);
				this.model.setProperty("/canEditSupplemental", true);
				this.model.setProperty("/canEditUNUMM", true);
				this.currentEvent = "ANY";
			}

			//When new hire overlaps open enrollment
			if (eventCodes.indexOf("OPEN") > -1 && eventCodes.indexOf("HIRE") > -1) {
				//this.model.setProperty("/canSelectQLE", false);
				this.getView().byId("openEnrollmentLink").setEnabled(false);
				// this.currentEvent = "HIRE";
			} else {
				//this.model.setProperty("/canSelectQLE", true);
				this.getView().byId("openEnrollmentLink").setEnabled(true);
			}

			if (eventCodes.indexOf("NONE") > -1) {
				this.model.setProperty("/canEditDependents", true);
				this.model.setProperty("/canEditManagewell", true);
				this.model.setProperty("/canSeeBenefitsSummary", false);
				this.getView().byId("clickToContinue").setVisible(false);

			} else {
				this.model.setProperty("/canEditDependents", true);
			}

			this.model.setProperty("/notEligible", events.length === 0 || eventCodes.indexOf("NONE") !== -1);
			//Links should work based on the Current Event
			//TAC Links
			var linksArr = this.getModel("helpfullinks").getData().links;
			var TACLinks = linksArr.filter(function (l) {
				return l.url_id.startsWith("TAC");
			});
			var linkArray = TACLinks.filter(function (p) {
				return p.event === that.currentEvent;
			});
			this.getModel("helpfullinks").setProperty("/links", linkArray);

			//BCLF Links

			var bclfArray = this.getModel("helpfullinks").getProperty("/bclfLinks");
			var bclfLinks = bclfArray.filter(function (p) {
				return p.event === that.currentEvent;
			});
			if (bclfLinks.length > 0) {
				this.getModel("helpfullinks").setProperty("/bclf", bclfLinks[0].url);
			}

			//Supplemental Life Changes
			var suppInsLink = this.getModel("helpfullinks").getProperty("/suppInsLinks");
			var suppIns = suppInsLink.filter(function (p) {
				return p.event === that.currentEvent;
			});
			if (suppIns.length > 0) {
				this.getModel("helpfullinks").setProperty("/suppIns", suppIns[0].url);
			}
			//Supplemental Spouse Life Changes
			var splpInsLink = this.getModel("helpfullinks").getProperty("/splpInsLinks");
			var splpIns = splpInsLink.filter(function (p) {
				return p.event === that.currentEvent;
			});
			if (splpIns.length > 0) {
				this.getModel("helpfullinks").setProperty("/splpIns", splpIns[0].url);
			}
			//Supp Child Changes
			var depcInsLink = this.getModel("helpfullinks").getProperty("/depcInsLinks");
			var depcIns = depcInsLink.filter(function (p) {
				return p.event === that.currentEvent;
			});
			if (depcIns.length > 0) {
				this.getModel("helpfullinks").setProperty("/depcIns", depcIns[0].url);
			}
			this.getLandingPageLinks(data.results[0].Pernr, this.currentEventCode);
			this.findQLE();
		},
		
		handleCurrentBenefits: function (data) {},
		
		startOpenEnrollment: function () {
			var nextStep = "TermsAndConditions";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}

			// need to post to create a new "OPEN Enrollment" session
			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: "OPEN",
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		
		startNewHire: function () {
			var nextStep = "WelcomeVideo";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}

			// need to post to create a new "NewHire" session
			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: "HIRE",
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		goToAdditionalBenifits: function () {
			var nextStep = "AdditionalBenefits";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}
			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: this.currentEventCode,
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		onSelectChange: function (oEvt) {
			this.model.setProperty("/showState", false);
			this.model.setProperty("/hasSpouse", false);
			this.getView().byId("idQLEBtn").setEnabled(true);
			if (oEvt.getSource().getSelectedKey().indexOf("CHGC") != -1) {
				this.model.setProperty("/showState", true);
			}
		},
		goToBenefitsSummary: function () {
			var nextStep = "CurrentBenefits";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						// Pernr: data.Pernr,
						Pernr: this.pernrKey,
						// Event: data.Event,
						Event: "ANY",
						Begda: data.Begda,
						Endda: data.Endda
					});

			}
			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: this.currentEventCode,
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		editLifeInsurance: function () {
			var nextStep = "LifeInsurance";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}
			if (this.model.getProperty("/showNoBclfError")) {
				if (!this.bclfDialog) {
					this.bclfDialog = new Dialog({
						type: DialogType.Message,
						title: "Error",
						state: 'Error',
						content: new Text({
							text: "You are currently not enrolled in Basic Life Insurance. Please Contact HRC if you think this is an error."
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.bclfDialog.close();
							}.bind(this)
						})
					});
					this.bclfDialog.open();
				} else {
					this.bclfDialog.open();
				}
			} else {

				this.benefitsModel().create("/empl_headSet", {
					Pernr: this.pernrKey,
					Event: this.currentEventCode,
					Status: "saved",
					IdSession: nextStep
				}, {
					success: onSessionCreated.bind(this)
				});
			}
		},
		editSupplemental: function () {
			var nextStep = "SuppInsurance";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}
			if (this.model.getProperty("/showNoSuppError")) {
				if (!this.suppDialog) {
					this.suppDialog = new Dialog({
						type: DialogType.Message,
						title: "Error",
						state: 'Error',
						content: new Text({
							text: "You are currently not enrolled in Supplemental Life Insurance. Please Contact HRC if you think this is an error."
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.suppDialog.close();
							}.bind(this)
						})
					});
					this.suppDialog.open();
				} else {
					this.suppDialog.open();
				}
			} else {

				this.benefitsModel().create("/empl_headSet", {
					Pernr: this.pernrKey,
					Event: this.currentEventCode,
					Status: "saved",
					IdSession: nextStep
				}, {
					success: onSessionCreated.bind(this)
				});
			}
		},
		onQLEPress: function () {
			var that = this;
			var qleText = this.texts.results.filter(function (result) {
				return result.type === that.getView().byId("QLESelect").getSelectedKey();
			});
			
			this.model.setProperty("/qleSelection", this.getView().byId("QLESelect")._getSelectedItemText());
			this.model.setProperty("/qleText", qleText[0].text);
			if (this.getView().byId("QLESelect").getSelectedKey() === "MAR") {
				var oFilter = new sap.ui.model.Filter({
					path: "pernr",
					operator: FilterOperator.EQ,
					value1: this.pernrKey
				});
				this.benefitsModel().read("/empDepBenSet", {
					filters: [oFilter],
					success: function (result) {
						var spouseRecord = result.results.filter(function (dependent) {
							return dependent.subty === "1";
						});
						if (spouseRecord[0]) {
							that.model.setProperty("/hasSpouse", true);
							that.model.setProperty("/spouseName", spouseRecord[0].favor + " " + spouseRecord[0].fanam);
						}
					},
				});
			}
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.dialogs.qleStart", this);
				// connect dialog to the root view of this component (models, lifecycle)
				this.getView().addDependent(this.dialog);
			}
			this.dialog.open();
		},
		cancelDialog: function (oEvt) {
			oEvt.getSource().getParent().close();
		},
		goToManagewell: function () {
			var nextStep = "ManageWell";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}

			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: this.currentEventCode,
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		
		submitQle: function (oEvt) {
			this.days = "";
			
			if( this.getView().byId("idDate").getDateValue().getTime() > Date.now() ) {
				MessageBox.error(
					"Date of the QLE can't be in the future"
				);
				
				return;
			} 
			
			var str = "/qleEvent(PERNR='" + this.pernrKey + "',TYPE='" + this.getView().byId("QLESelect").getSelectedKey() + "',BEGDA='" + this.getView().byId("idDate").getValue() + "')";

			var payload = {
				"PERNR": this.pernrKey,
				"TYPE": this.getView().byId("QLESelect").getSelectedKey(),
				"BEGDA": this.getView().byId("idDate").getValue(),
				"ENDDA": "",
				"ERDAT": "",
				"ERZET": "",
				"ERNAM": "",
				"STATUS": "",
				"INVALID": ""
			};
			
			if (this.getView().byId("stateCoverage")) {
				payload.STATE = "X";
			}

			this.model.setProperty("/qleData", payload);
			
			this.benefitsModel().update(str, payload, {
				success: this.handleQLESuccess.bind(this),
				error: function (response) {
					if (response.responseText.indexOf("error") !== -1) {
						MessageBox.error(
							"You are outside of the allowable timeframe to make changes to your benefits due to this QLE. You may make changes to your benefits during the next Open Enrollment period"
						);
					}
				}
			});

		},

		handleQLESuccess: function () {
			this.getView().byId("qleDialog").close();
			var key = this.benefitsModel().createKey("/qleEvent", {
				PERNR: this.model.getProperty("/qleData").PERNR,
				TYPE: this.model.getProperty("/qleData").TYPE,
				BEGDA: this.model.getProperty("/qleData").BEGDA,
			});

			var that = this;
			this.benefitsModel().read(key, {
				success: function (result) {
					that.model.setProperty("/qleData", result);
					that.getRouter()
						.navTo("TermsAndConditions", {
							Pernr: that.pernrKey,
							Event: result.TYPE,
							Begda: result.BEGDA,
							Endda: result.ENDDA
						});

				}
			});

		},
		editDependents: function () {
			var nextStep = "Dependents";

			function onSessionCreated(data) {
				this.getRouter()
					.navTo(nextStep, {
						Pernr: this.pernrKey,
						Event: data.Event,
						Begda: data.Begda,
						Endda: data.Endda
					});

			}

			this.benefitsModel().create("/empl_headSet", {
				Pernr: this.pernrKey,
				Event: this.currentEventCode,
				Status: "saved",
				IdSession: nextStep
			}, {
				success: onSessionCreated.bind(this)
			});
		},
		
		getUserId: function () {
			return sap.ushell.Container.getService("UserInfo").getUser().getId();
		},
		
		getInFlightChanges: function () {
			this.benefitsModel().read("/empl_headSet", {
				success: function (result) {
					this.model.setProperty("/inFlight", result.results);
				}.bind(this)
			});
		},
		
		continueEnrollment: function () {
			this.benefitsModel().read("/continueEnrollmentSet(pernr='" + this.pernrKey + "',event='" + this.currentEventCode + "')", {
				success: this.handleContinueSuccess.bind(this)
			});
		},
		
		handleContinueSuccess: function (data) {
			var nextStep = data.id_session;

			if( this.model.getProperty("/hasQLE") ) {
				var qleExists = this.model.getProperty("/qleExists");

				var UIDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				
				var SAPDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				});				

				this.getRouter().navTo("QLEMain", {
					Pernr: qleExists.pernr,
					Event: qleExists.event,
					Begda: UIDateFormat.format( SAPDateFormat.parse(qleExists.begda) ),
					Endda: UIDateFormat.format( SAPDateFormat.parse(qleExists.endda) )
				});

			} else {
				this.getRouter().navTo(nextStep, {
					Pernr: data.pernr,
					Event: data.event,
					Begda: data.begda,
					Endda: data.endda
				});
			}
		},
		
		textForInFlightPlan: function (event) {
			if( this.model.getProperty("/hasQLE") ) {
				return this.getTranslatedText("continueEnrollment", "Qualifying Life Event");
			} else {
				return this.getTranslatedText("continueEnrollment", this.currentEvent);	
			}
		},
		
		
		goToJellyVision : function () {
			var that = this;

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			
			var continueEnrollment = controller.model.getProperty("/continueEnrollment");

			if( continueEnrollment.begda ) {
				var key = this.benefitsModel().createKey("jellyVision", {
					pernr : this.pernrKey,
					event : "HIRE",
					begda : continueEnrollment.begda,
					endda : continueEnrollment.endda,
					learnAcct : ""
				});
			} else {
				var key = this.benefitsModel().createKey("jellyVision", {
					pernr : this.pernrKey,
					event : "OPEN",
					begda : dateFormat.format( new Date() ),
					endda : '99991231',
					learnAcct : ""
				});
			}
			
			this.benefitsModel().read("/" + key, {
				success: function (result) {
					that.createHTMLForm(result.jvURL, result.saml);
				},
				error: function (response) {
					var msg = that.getTranslatedText("jvError");
					MessageBox.error(msg);
				}
			});
		},
		
		createHTMLForm: function (jvAction, samlValue) {
			if (samlValue === "" || jvAction === "") {
				var msg = this.getTranslatedText("jvError");
				MessageBox.error(msg);
			} else {
				var formId = this.getView().byId("formAction").getId();
				var viewId = formId.replace("formAction", "");
				var inputVal = viewId + "samlInput";
				document.getElementById(inputVal).value = samlValue;
				document.getElementById(formId).action = jvAction;
				document.getElementById(formId).submit();
			}
		},
		
		goToEnrollmentEducationViaAskAlex : function(){
			var that = this;
			
			if (!this.oJVConfirmation) {
				this.oJVConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({ text: "You are leaving the Dart Enrollment System. Once you have made your enrollment selections, close the Ask Alex window to return."}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							that.goToJellyVision();
							this.oJVConfirmation.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oJVConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oJVConfirmation.open();
		},		
		
		goToJellyVisionOpenEnrollment : function () {
			var that = this;

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});

			var TZOffsetMs = controller.OpenEnrollmentStartDate.getTimezoneOffset() * 60 * 1000;
				
			var key = this.benefitsModel().createKey("jellyVision", {
				pernr : this.pernrKey,
				event : "OPEN",
				begda : dateFormat.format( new Date(controller.OpenEnrollmentStartDate.getTime() + TZOffsetMs) ),
				endda : '99991231',
				learnAcct : "L"
			});

			this.benefitsModel().read("/" + key, {
				success: function (result) {
					that.createHTMLFormOpenEnrollment(result.jvURL, result.saml);
				},
				error: function (response) {
					var msg = that.getTranslatedText("jvError");
					MessageBox.error(msg);
				}
			});
		},
		
		createHTMLFormOpenEnrollment: function (jvAction, samlValue) {
			if (samlValue === "" || jvAction === "") {
				var msg = this.getTranslatedText("jvError");
				MessageBox.error(msg);
			} else {
				var formId = this.getView().byId("formActionOpenEnrollmentEducationViaAskAlex").getId();
				var viewId = formId.replace("formActionOpenEnrollmentEducationViaAskAlex", "");
				var inputVal = viewId + "samlInputOpenEnrollmentEducationViaAskAlex";
				document.getElementById(inputVal).value = samlValue;
				document.getElementById(formId).action = jvAction;
				document.getElementById(formId).submit();
			}
		},		
		
		goToOpenEnrollmentEducationViaAskAlex : function(){
			var that = this;
			
			if (!this.oJVConfirmationOpenEnrollment) {
				this.oJVConfirmationOpenEnrollment = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({ text: "You are leaving the Dart Enrollment System. Once you have made your enrollment selections, close the Ask Alex window to return."}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							that.goToJellyVisionOpenEnrollment();
							this.oJVConfirmationOpenEnrollment.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oJVConfirmationOpenEnrollment.close();
						}.bind(this)
					})
				});
			}

			this.oJVConfirmationOpenEnrollment.open();
		},		
	});
});