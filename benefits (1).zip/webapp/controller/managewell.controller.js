sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (
	Controller,
	JSONModel,
	MessageToast
) {
	"use strict";

	var emailRegex =
		/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

	return Controller.extend("dart.hcm.benefits.controller.managewell", {
		onInit: function () {
			this.getRouter().getRoute("MWStep").attachPatternMatched(this.attachRouteMatched.bind(this));
			this.getRouter().getRoute("ManageWell").attachPatternMatched(this.attachRouteMatched.bind(this));
		},
		attachRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();

		},
		initLocalModel: function () {
			this.model = new JSONModel({
				wantsToBeEnrolled: false,
				email: "",
				emailStatus: "None",
				emailStatusText: "",
				emailConfirmation: "",
				emailConfirmationStatus: "None",
				emailConfirmationStatusText: "",
				message: "",
				messageType: "None"
			});
			this.getView().setModel(this.model);
			this.getManagewellFlag();
		},
		getManagewellFlag: function () {
			var key = "/manageWell(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";
			var that = this;
			this.benefitsModel().read(key, {
				success: function (result) {
					if (result.check === "true") {
						that.model.setProperty("/wantsToBeEnrolled", true);
					}
				}
			});
		},
		validateEmail: function (event) {
			var value = event.getParameter("value");
			if (emailRegex.test(value)) {
				this.model.setProperty("/emailStatus", "None");
				this.model.setProperty("/emailStatusText", "");
			} else {
				this.model.setProperty("/emailStatus", "Error");
				this.model.setProperty("/emailStatusText", this.getTranslatedText("notAnEmail"));
			}

			//	this.sendToBackend();
		},

		sendChecked: function (event) {
			this.benefitsModel().create("/manageWell", {
				email: "",
				pernr: this.routeArgs.Pernr,
				check: event.getSource().getSelected().toString(),
				event: this.routeArgs.Event
			});
		},

		validateEmailConfirmation: function (event) {
			var value = event.getParameter("value");
			if (emailRegex.test(value)) {
				this.model.setProperty("/emailConfirmationStatus", "None");
				this.model.setProperty("/emailConfirmationStatusText", "");
			} else {
				this.model.setProperty("/emailConfirmationStatus", "Error");
				this.model.setProperty("/emailConfirmationStatusText", this.getTranslatedText("notAnEmail"));
			}

			if (value !== this.model.getProperty("/email")) {
				this.model.setProperty("/emailConfirmationStatus", "Error");
				this.model.setProperty("/emailConfirmationStatusText", this.getTranslatedText("emailDoesNotMatch"));
			} else {
				this.model.setProperty("/emailConfirmationStatus", "None");
				this.model.setProperty("/emailConfirmationStatusText", "");
			}

			//	this.sendToBackend();
		},
		sendToBackend: function () {
			if (this.model.getProperty("/emailStatus") === "None" && this.model.getProperty("/emailConfirmationStatus") === "None") {
				var email = this.model.getProperty("/email");
				var emailConfirmation = this.model.getProperty("/emailConfirmation");

				if (email && emailConfirmation) {
					this.benefitsModel().create("/manageWell", {
						email: email,
						pernr: this.routeArgs.Pernr,
						event: this.routeArgs.Event
					}, {
						success: function (data, response) {
							if (this.responseHasError(response)) {
								this.model.setProperty("/message", JSON.parse(response.headers["sap-message"]).message);
								this.model.setProperty("/messageType", "Error");
							} else {
								this.model.setProperty("/message", JSON.parse(response.headers["sap-message"]).message);
								this.model.setProperty("/messageType", "Success");
							}
						}.bind(this)
					});
				}
			} else {
				var msg = this.getTranslatedText("emailDoesNotMatch");
				MessageToast.show(msg);
			}
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		}
	});
});