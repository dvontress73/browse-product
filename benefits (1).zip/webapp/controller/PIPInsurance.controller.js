sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.PIPInsurance", {
		onInit: function () {
			this.getRouter()
				.getRoute("PIPInsurance")
				.attachPatternMatched(this.onRouteMatched.bind(this));

			this.model = new JSONModel({
				links: [],
				titleText: "",
				PIPText: ""
			});
			this.getView().setModel(this.model);
		},
		onRouteMatched: function (route) {
			this.getProxyPernr(route.getParameters().arguments.Pernr);
			//UI5 doesn't support rel attribute on links. 
			$(".link-box a").attr("rel", "noreferrer noopener");
			this.routeArgs = route.getParameters().arguments;
			this.getEname();
			this.getTexts();
		},
		pernrKey: null,
		getProxyPernr: function (data) {
			if (data !== "") {
				this.pernrKey = data;
			} else {
				this.pernrKey = "X";
			}
		},
		getTexts: function () {
			this.benefitsModel().read("/welcome_terms_textSet", {
				success: this.handleTextSuccess.bind(this)
			});
		},
		handleTextSuccess: function (data) {
			var welcome = data.results.filter(function (r) {
				return r.type === "pipInsr";
			})[0];
			this.model.setProperty("/PIPText", this.sanitizeSapString(welcome.text));
		},
		getEname: function () {
			var sEname = "/getEnameSet('" + this.pernrKey + "')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		declineTac: function () {
			function onSuccess() {
				this.getRouter().navTo("LandingPage");
			}

			this.updateCurrentStep(Object.assign({},
				this.routeArgs, {
					IdSession: "decline"
				}
			), {
				success: onSuccess.bind(this)
			});
		},
		acceptTac: function () {
			function onSuccess() {
				this.getRouter().navTo("DependentsStep", this.routeArgs);
			}
			this.updateCurrentStep(Object.assign({},
				this.routeArgs, {
					IdSession: "manageDependents"
				}), {
				success: onSuccess.bind(this)
			});
		}
	});

});