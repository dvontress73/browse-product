sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	MessageToast
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.BeneficiaryBaseController", {
		formatPercentageTotal: function (percent) {
			if (percent !== undefined) {
				return this.getTranslatedText("totalPercent", percent.toString());
			}
			return "";
		},
		initValidationModel: function () {
			this.validationModel = new JSONModel({
				Pernr: "",
				subty: "",
				subtyStatus: "None",
				favor: "",
				favorStatus: "None",
				fanam: "",
				fanamStatus: "None",
				orgnm: "",
				orgnmStatus: "None",
				relationship: "",
				relationshipStatus: "None",
				createButton: false
			});
			this.getView().setModel(this.validationModel, "validation");
		},
		updateTotals: function () {
			this.oBusyDialog = new sap.m.BusyDialog();
			var pNegative, numberEntered, pDecimal, errorMessage, cNegative, cDecimal = "";
			var bens = this.model.getProperty("/beneficiaries");
			for (var i = 0; i < bens.length; i++) {
				numberEntered = bens[i].primaryPercent;
				if (numberEntered < 0) {
					pNegative = "X";
				}
				if ((numberEntered - Math.floor(numberEntered)) !== 0) {
					pDecimal = "X";
				}
				numberEntered = bens[i].contingentPercent;
				if (numberEntered < 0) {
					cNegative = "X";
				}
				if ((numberEntered - Math.floor(numberEntered)) !== 0) {
					cDecimal = "X";
				}

			}
			this.model.setProperty("/totalPrimary", bens.reduce(function (t, c) {
				return t + parseFloat(c.primaryPercent || "0");
			}, 0));
			this.model.setProperty("/totalContingent", bens.reduce(function (t, c) {
				return t + parseFloat(c.contingentPercent || "0");
			}, 0));
			if (pNegative !== "X" && pDecimal !== "X" && cNegative !== "X" && cDecimal !== "X") {
				if (this.isValid()) {
					this.oBusyDialog.open();
					this.updateBeneficiaryAllocations();
				} else {
					this.oBusyDialog.close();
				}

			} else {
				if (pNegative === "X") {
					errorMessage = this.getTranslatedText("negative");
					this.model.setProperty("/primaryStatus", "Error");
					this.model.setProperty("/primaryStatusText", errorMessage);
				}
				if (pDecimal === "X") {
					errorMessage = this.getTranslatedText("decimal");
					this.model.setProperty("/primaryStatus", "Error");
					this.model.setProperty("/primaryStatusText", errorMessage);
				}
				if (pDecimal === "X" && pNegative === "X") {
					errorMessage = this.getTranslatedText("negativedecimal");
					this.model.setProperty("/primaryStatus", "Error");
					this.model.setProperty("/primaryStatusText", errorMessage);
				}

				if (cNegative === "X") {
					errorMessage = this.getTranslatedText("negative");
					this.model.setProperty("/contingentStatus", "Error");
					this.model.setProperty("/contingentStatusText", errorMessage);
				}
				if (cDecimal === "X") {
					errorMessage = this.getTranslatedText("decimal");
					this.model.setProperty("/contingentStatus", "Error");
					this.model.setProperty("/contingentStatusText", errorMessage);
				}
				if (cDecimal === "X" && cNegative === "X") {
					errorMessage = this.getTranslatedText("negativedecimal");
					this.model.setProperty("/contingentStatus", "Error");
					this.model.setProperty("/contingentStatusText", errorMessage);
				}

			}

		},
		isValid: function () {
			var valid = true;
			var errorMessage = this.getTranslatedText("mustTotal100");

			var totalPrimary = this.model.getProperty("/totalPrimary");
			if (totalPrimary !== 100) {
				valid = false;
				this.model.setProperty("/primaryStatus", "Error");
				this.model.setProperty("/primaryStatusText", errorMessage);
			} else if (totalPrimary === 100) {
				this.model.setProperty("/primaryStatus", "Success");
				this.model.setProperty("/primaryStatusText", "");
			} else {
				this.model.setProperty("/primaryStatus", "None");
				this.model.setProperty("/primaryStatusText", "");
			}

			var totalContingent = this.model.getProperty("/totalContingent");
			if (totalContingent !== 100 && totalContingent !== 0) {
				valid = false;
				this.model.setProperty("/contingentStatus", "Error");
				this.model.setProperty("/contingentStatusText", errorMessage);
			} else if (totalContingent === 100) {
				this.model.setProperty("/contingentStatus", "Success");
				this.model.setProperty("/contingentStatusText", "");
			} else {
				this.model.setProperty("/contingentStatus", "None");
				this.model.setProperty("/contingentStatusText", "");
			}

			this.model.getProperty("/beneficiaries").forEach(function (b, index) {
				var statusPath = "/beneficiaries/" + index + "/status";
				var textPath = "/beneficiaries/" + index + "/statusText";
				if (parseInt(b.primaryPercent || "0", 10) !== 0 && parseInt(b.contingentPercent || "0", 10) !== 0) {
					this.model.setProperty(statusPath, "Error");
					this.model.setProperty(textPath, this.getTranslatedText("beneficiaryPrimaryContingentExclusion"));
					valid = false;
				} else {
					this.model.setProperty(statusPath, "None");
					this.model.setProperty(textPath, "");
				}
			}.bind(this));

			return valid;
		},
		cleanUpBeneficiaryFields: function (ben) {
			var individualOnlyFields = ["fanam", "favor"];
			var organizationOnlyFields = ["orgnm", "stras", "ort01", "state", "pstlz"];

			if (ben.subty.startsWith("Z")) {
				individualOnlyFields.forEach(function (f) {
					ben[f] = "";
				});
			} else {
				organizationOnlyFields.forEach(function (f) {
					ben[f] = "";
				});
			}
			return ben;
		},
		newBeneficiaryDialog: function () {
			if(this.model.getProperty("/beneficiaries").length < 10){
			this.model.setProperty("/dialogTitle", this.getTranslatedText("newBeneficiary"));
			this.model.setProperty("/isEdit", false);
			var context = this.model.setProperty("/beneficiary", {
				Pernr: "",
				subty: "",
				fanam: "",
				favor: "",
				telnr: "",
				perid: "",
				stras: "",
				ort01: "",
				state: "",
				pstlz: "",
				adj_reason: "",
				relationship: ""
			});

			this.model.setProperty("/showIndividualForm", false);
			this.model.setProperty("/showOrganizationForm", false);
			this.initValidationModel();
			this.openBeneficiaryDialog(context);
			}else{
				MessageToast.show("Can only add upto 10 Beneficiaries. Please Contact HRConnect to add more.");
			}
		},
		editBeneficiaryDialog: function (event) {
			this.initValidationModel();
			this.model.setProperty("/isEdit", true);
			this.validationModel.setProperty("/createButton", true);
			this.model.setProperty("/dialogTitle", this.getTranslatedText("editBeneficiary"));
			var ben = event.getSource().getBindingContext().getProperty("");
			this.model.setProperty("/beneficiary", ben.sapBen);

			var org = false;
			if (ben.sapBen.subty.startsWith("Z")) {
				org = true;
			}
			this.model.setProperty("/showIndividualForm", !org);
			this.model.setProperty("/showOrganizationForm", org);

			this.openBeneficiaryDialog();
		},
		openBeneficiaryDialog: function () {
			this.dialog = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.dialogs.addBeneficiary", this);
			// connect dialog to the root view of this component (models, lifecycle)
			this.getView().addDependent(this.dialog);
			this.dialog.open();
		},
		submitBeneficiary: function () {
			var ben = this.model.getProperty("/beneficiary");
			ben.Pernr = this.routeArgs.Pernr;
			if (this.validateBeneficiary(ben)) {
				return;
			}

			this.benefitsModel().resetChanges();
			var onSuccess = function (data, response) {
				this.closeDialog(ben.Pernr);
			}.bind(this);

			if (this.model.getProperty("/isEdit")) {
				var key = this.benefitsModel().createKey("/emplBeneficiariesSet", ben);
				this.benefitsModel().update(key, ben, {
					success: onSuccess
				});
			} else {
				this.benefitsModel().create("/emplBeneficiariesSet", ben, {
					success: onSuccess
				});
			}

		},
		validateBeneficiary: function (ben) {
			var error = false;

			if (!ben.subty) {
				this.validationModel.setProperty("/subty", this.getTranslatedText("isRequired", this.getTranslatedText("beneficiaryType")));
				this.validationModel.setProperty("/subtyStatus", "Error");
				return false;
			} else {
				this.validationModel.setProperty("/subty", "");
				this.validationModel.setProperty("/subtyStatus", "None");
			}

			var isIndividual = !ben.subty.startsWith("Z");

			if (isIndividual && !ben.favor) {
				error = true;
				this.validationModel.setProperty("/favor", this.getTranslatedText("isRequired", this.getTranslatedText("legalFirstName")));
				this.validationModel.setProperty("/favorStatus", "Error");
			} else {
				this.validationModel.setProperty("/favor", "");
				this.validationModel.setProperty("/favorStatus", "None");
			}

			if (isIndividual && !ben.fanam) {
				error = true;
				this.validationModel.setProperty("/fanam", this.getTranslatedText("isRequired", this.getTranslatedText("legalLastName")));
				this.validationModel.setProperty("/fanamStatus", "Error");
			} else {
				this.validationModel.setProperty("/fanam", "");
				this.validationModel.setProperty("/fanamStatus", "None");
			}

			if (!isIndividual && !ben.orgnm) {
				error = true;
				this.validationModel.setProperty("/orgnm", this.getTranslatedText("isRequired", this.getTranslatedText("organizationName")));
				this.validationModel.setProperty("/orgnmStatus", "Error");
			} else {
				this.validationModel.setProperty("/orgnm", "");
				this.validationModel.setProperty("/orgnmStatus", "None");
			}

			// type of "Other"
			var isOther = ben.subty === "12";
			if (isOther) {
				if (!ben.relationship) {
					error = true;
					this.validationModel.setProperty("/relationship", this.getTranslatedText("isRequired", this.getTranslatedText("relationship")));
					this.validationModel.setProperty("/relationshipStatus", "Error");
				} else if (ben.relationship.length > 40) {
					error = true;
					this.validationModel.setProperty("/relationship", this.getTranslatedText("characterLimit", [this.getTranslatedText("relationship"),
						"40"
					]));
					this.validationModel.setProperty("/relationshipStatus", "Error");
				} else {
					this.validationModel.setProperty("/relationship", "");
					this.validationModel.setProperty("/relationshipStatus", "None");
				}
			}

			return error;
		},
		closeDialog: function (pernr) {
			this.benefitsModel().read("/emplBeneficiariesSet", {
				filters: [this.oFilter]
			});
			this.dialog.close();
			this.dialog.destroy();
		},
		onBeneficiaryTypeSelect: function (event) {
			this.validationModel.setProperty("/createButton", true);
			var key = event.getSource().getSelectedKey();
			var org = false;
			if (key.startsWith("Z")) {
				org = true;
			}
			this.model.setProperty("/showIndividualForm", !org);
			this.model.setProperty("/showOrganizationForm", org);

			var context = event.getSource().getBindingContext();
			this.benefitsModel().setProperty("subty", key, context);
		},
		getBeneficiaries: function (life) {
			// this.oFilterBen = new sap.ui.model.Filter({
			// 	path: "Pernr",
			// 	operator: FilterOperator.EQ,
			// 	value1: life.Pernr
			// });

			this.benefitsModel().read("/emplBeneficiariesSet", {
				filters: [this.oFilter],
				success: function (result) {
					var bens = [];
					var primaryTotal = 0;
					var contingentTotal = 0;
					result.results.forEach(function (ben) {
						if (!ben.subty.includes("Z")) {
							ben.orgnm = "";
						}
						var name = ben.orgnm || ben.favor + " " + ben.fanam;
						var key = "";
						var primary = null;
						var contingent = null;
						var type = this.benefitsModel().getProperty("/relationBeneficiarieSet('" + ben.subty + "')");

						for (var i = 1; i <= 20; i++) {
							var num = ("00" + i).slice(-2);
							if (
								life["dty" + num] === ben.subty &&
								life["did" + num] === ben.objps
							) {
								primary = life["bpt" + num];
								contingent = life["cbpt" + num];
								if (primary !== "") {
									primaryTotal += parseFloat(primary);
								}
								if (contingent !== "") {
									contingentTotal += parseFloat(contingent);
								}
							}
						}

						var relationship = type.stext;
						if (ben.subty === "12") {
							relationship = ben.relationship;
						}

						bens.push({
							key: key,
							name: name,
							relationship: relationship,
							primaryPercent: primary,
							contingentPercent: contingent,
							status: "None",
							statusText: "",
							sapBen: ben
						});
					}.bind(this));

					this.model.setProperty("/beneficiaries", bens);
					this.model.setProperty("/totalPrimary", primaryTotal);
					this.model.setProperty("/totalContingent", contingentTotal);
					this.isValid();
				}.bind(this)
			});
		},
		benValidFormatter: function (allStatus, beneficiaryStatus) {
			if (beneficiaryStatus === "Error") {
				return "Error";
			}

			return allStatus;
		},
		benValidTextFormatter: function (allStatusText, beneficiaryStatusText) {
			if (beneficiaryStatusText) {
				return beneficiaryStatusText;
			}

			return allStatusText;
		}
	});
});