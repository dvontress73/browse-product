sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/m/Dialog",
	"sap/m/MessageBox"
], function (Controller, Filter, FilterOperator, JSONModel, Device, Dialog, MessageBox) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.TermsAndConditions", {

		onInit: function () {
			this.getRouter()
				.getRoute("TermsAndConditions")
				.attachPatternMatched(this.onRouteMatched.bind(this));

			this.model = new JSONModel({
				links: [],
				titleText: ""
			});
			this.getView().setModel(this.model);
			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			if (oDeviceModel.getData().system.phone) {
				this.desktopView = false;
			}

		},
		onRouteMatched: function (route) {
			this.getProxyPernr(route.getParameters().arguments.Pernr);
			//UI5 doesn't support rel attribute on links. 
			$(".link-box a").attr("rel", "noreferrer noopener");
			this.routeArgs = route.getParameters().arguments;
			this.checkPermission(this.routeArgs.Pernr, this.routeArgs.Event, this.routeArgs.Begda, this.routeArgs.Endda);
			this.getEname();
			// PIP not in Scope Currently
			// this.checkMichiganEmployee(route.getParameters().arguments.Pernr);
			this.currentLanguage = this.getOwnerComponent().getModel("languageModel").getProperty("/currentLanguage");

		},
		currentLanguage: null,
		desktopView: true,
		onBeforeRendering: function () {
			var oHeader = this.getView().byId("pageHeader");
			var oVbox = this.getView().byId("hrcBox");
			if (!this.desktopView) {
				oHeader.removeAllContent();
				oVbox.removeAllItems();
				this.loadMobileFragment(oHeader);

			} else {
				oHeader.removeAllContent();
				this.loadDesktopFragment(oHeader);
			}
			this.setLanguage();
		},
		onLanguageChange: function (oEvent) {

			if (this.desktopView) {
				this.changeLanguage(oEvent.getSource()._getSelectedItemText());
			} else {
				this.createRadioButton();
				this.dialog.open();
			}

		},
		closeDialog: function () {
			this.dialog.close();
		},
		onMobileLanguageSelection: function (oEvent) {
			this.changeLanguage(oEvent.getSource().getSelectedButton().getText());
			this.dialog.close();
		},
		pernrKey: null,
		getProxyPernr: function (data) {
			if (data !== "") {
				this.pernrKey = data;
			} else {
				this.pernrKey = "X";
			}
		},
		getEname: function () {
			var sEname = "/getEnameSet('" + this.pernrKey + "')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		declineTac: function () {
			var that = this;
			var title = this.getTranslatedText("tncPopUp");
			function onSuccess() {
				this.getRouter().navTo("LandingPage", {
					Pernr: that.pernrKey
				});
			}

			MessageBox.warning(title, {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK") {
						//Do nothing
					} else if (sAction === "CANCEL") {
						that.updateCurrentStep(Object.assign({},
							that.routeArgs, {
								IdSession: "decline"
							}
						), {
							success: onSuccess.bind(that)
						});
					}

				}
			});

		},
		isMichiganEmp: null,
		acceptTac: function () {

			var sessionId, navTo = "";

			function onSuccess() {
				this.getRouter().navTo(navTo, this.routeArgs);
			}

			// if (this.isMichiganEmp === 'X') {
			// 	sessionId = "pipInsurance";
			// 	navTo = "PIPInsurance";
			// } else {
			// 	sessionId = "DependentsStep";
			// 	navTo = "DependentsStep";
			// }
			
			if(this.routeArgs.Event === "HIRE" || this.routeArgs.Event === "OPEN"){
				sessionId = "DependentsStep";
				navTo = "DependentsStep";
			}else{
				sessionId = "QLEMain";
				navTo = "QLEMain";
			}
			
			this.updateCurrentStep(Object.assign({},
				this.routeArgs, {
					IdSession: sessionId
				}), {
				success: onSuccess.bind(this)
			});
		},
		checkMichiganEmployee: function (pernr) {
			this.benefitsModel().read("/empCarInsPIPSet('" + pernr + "')", {
				success: this.handleEmpLocation.bind(this)
			});
		},
		handleEmpLocation: function (data) {
			this.isMichiganEmp = data.MI;
		},
		onDownload: function () {
			var oPrintText = this.getView().byId("idTermsText").getHtmlText();
			this.createDOM(oPrintText);

		},
		createDOM: function PrintElem(elem) {
			var mywindow = window.open("", "PRINT", "height=400,width=600");

			mywindow.document.write("<html><head><title>" + document.title + "</title>");
			mywindow.document.write("</head><body >");
			mywindow.document.write("<h2>" + document.title + ":Terms & Conditions" + "</h2>");
			mywindow.document.write("<h4>" + elem + "</h4>");
			mywindow.document.write("</body></html>");
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10*/
			mywindow.print();
			mywindow.close();

			return true;
		}
	});
});