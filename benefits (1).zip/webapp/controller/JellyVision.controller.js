sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/TextArea"
], function (
	Controller,
	MessageBox,
	Dialog,
	DialogType, 
	Button, 
	ButtonType, 
	Label, 
	MessageToast, 
	Text, 
	TextArea
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.JellyVision", {
		onInit: function () {
			this.getRouter().getRoute("JellyVisionStep").attachPatternMatched(this.attachRouteMatched.bind(this));
		},
		
		attachRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			//this.createHTMLForm();
		},
		
		openConfirmation: function(){
			var that = this;
			if (!this.oJVConfirmation) {
				this.oJVConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({ text: "You are leaving the Dart Enrollment System. Once you have made your enrollment selections, close the Ask Alex window to return."}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							that.goToJellyVision();
							this.oJVConfirmation.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oJVConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oJVConfirmation.open();
		},
		
		goToJellyVision: function () {
			var busy = this.getView().byId("BusyDialog");
			busy.open();
			var that = this;
			var key = "/jellyVision(pernr='" + this.routeArgs.Pernr +
				"',event='" + this.routeArgs.Event +
				"',begda='" + this.routeArgs.Begda +
				"',endda='" + this.routeArgs.Endda + "',learnAcct='')";
			this.benefitsModel().read(key, {
				success: function (result) {
					that.createHTMLForm(result.jvURL, result.saml);
					jQuery.sap.delayedCall(3000, this, function () {
						busy.close();
					});
					var oParentModel = that.getView().getParent().getParent().getParent().getModel();	
					oParentModel.setProperty("/isJVCompleted", false);
					oParentModel.setProperty("/isJVHealth", false);
					oParentModel.setProperty("/showMedicalDependentStep", false);
					oParentModel.setProperty("/showDentalDependentStep", false);
					oParentModel.setProperty("/showVisionDependentStep", false);
					oParentModel.setProperty("/showDependentReminderStep", false);
					oParentModel.setProperty("/showSupplementDependentStep", false);
				},
				error: function (response) {
					var msg = that.getTranslatedText("jvError");
					MessageBox.error(msg);
					busy.close();
				}
			});
		},
		
		createHTMLForm: function (jvAction, samlValue) {
			if (samlValue === "" || jvAction === "") {
					var msg = this.getTranslatedText("jvError");
					MessageBox.error(msg);
			} else {

				var formId = this.getView().byId("formAction").getId();
				var viewId = formId.replace("formAction", "");
				var inputVal = viewId + "samlInput";
				document.getElementById(inputVal).value = samlValue;
				document.getElementById(formId).action = jvAction;
				document.getElementById(formId).submit();
			}
		}
	});
});