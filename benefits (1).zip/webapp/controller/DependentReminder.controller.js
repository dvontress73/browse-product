sap.ui.define([
	"dart/hcm/benefits/controller/Dependents.controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, Filter, FilterOperator) {
	return Controller.extend("dart.hcm.benefits.controller.DependentReminder", {
		onInit: function(){
			this.getRouter().getRoute("DepReminderStep").attachPatternMatched(this.onReminderRouteMatched.bind(this));
			this.dateParser = sap.ui.core.format.DateFormat.getInstance({
				format: "yMd"
			});
		},
		onReminderRouteMatched: function(route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.setDependentsFilter(this.dependentNoDocumentationFilter);
			this.getDependents();
		},
		dependentNoDocumentationFilter: function(dependent){
			return dependent.status_id === "1";
		}
	});
});

