sap.ui.define([
	"dart/hcm/benefits/controller/HealthDependentBase",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/dependentUtils"
], function (
	Controller,
	NumberFormat,
	DependentUtils
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.MedicalDependent", {
		planType: "AMED",
		dependentLimits: DependentUtils.dependentLimits.AMED,
		onInit: function() {
			this.getRouter().getRoute("MedDepStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});