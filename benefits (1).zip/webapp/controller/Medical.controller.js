sap.ui.define([
	"dart/hcm/benefits/controller/HealthPlanBase",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/format/NumberFormat"
], function (
	Controller,
	JSONModel,
	MessageToast,
	NumberFormat
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.Medical", {
		planType: "AMED",
		onInit: function() {
			this.getRouter().getRoute("MedicalStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});