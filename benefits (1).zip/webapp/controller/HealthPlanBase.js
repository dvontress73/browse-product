sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/planUtils",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	Controller,
	JSONModel,
	NumberFormat,
	planUtils,
	Filter,
	FilterOperator
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.HealthPlanBase", {
		planType: "AMED",
		onInit: function () {
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.getPlans();
		},
		initLocalModel: function () {
			this.model = new JSONModel({
				levels: [{
					key: "EE",
					text: this.getTranslatedText("employeeOnly")
				}, {
					key: "EE+1",
					text: this.getTranslatedText("employeePlusOne")
				}, {
					key: "EFAM",
					text: this.getTranslatedText("employeePlusFamily")
				}],
				selectedLevel: "EE",
				selectedPlan: "",
				plans: [],
				isLoading: true
			});
			this.getView().setModel(this.model);
		},
		getPlans: function (event) {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			this.benefitsModel().read("/mdvPlanSet", {
				filters:[this.oFilter,this.oEventFilter],
				success: this.getRelevantPlans.bind(this)
			});
		},
		onSelectedLevelChange: function (event) {
			var level = event.getParameter("selectedLevel");
			this.model.setProperty("/selectedLevel", level);
			var plan = this.model.getProperty("/selectedPlan");
			if (plan) {
				var newPlan = this.model.getProperty("/plans").filter(function (p) {
					return p.key === plan && p.level === level;
				})[0];

				if (newPlan) {
					//copy dependents to new plan
					this.transferDependents(plan, newPlan);
					this.selectPlan(newPlan);
				}
			}
		},
		onPlanChange: function (event) {
			var newPlan = event.getParameter("selectedPlan");
			var oldPlan = this.model.getProperty("/selectedPlan");

			this.transferDependents(oldPlan, newPlan);
			
			this.selectPlan(newPlan);
		},
		transferDependents: function (oldPlan, newPlan) {
					for (var i = 1; i <= 20; i++) {
				var num = ("00" + i).slice(-2);
				newPlan["dty" + num] = oldPlan["dty" + num];
				newPlan["did" + num] = oldPlan["did" + num];
			}
		},
		selectPlan: function (plan) {
			var planKey = this.benefitsModel().createKey("/mdvPlanSet", plan ? plan.sapElement : {});

			var plans = this.model.getProperty("/plans")
				.map(function (p) {
					return p.sapElement;
				});

			//deselect plans first, so that things happen in the right order in sap.
			plans.forEach(function (p) {
				var thisKey = this.benefitsModel().createKey("/mdvPlanSet", p);
				var bc = this.benefitsModel().createBindingContext(thisKey);
				if (thisKey !== planKey) {
					this.benefitsModel().setProperty("enrolled", "", bc);
				}
			}.bind(this));
			
			plans.forEach(function (p) {
				var thisKey = this.benefitsModel().createKey("/mdvPlanSet", p);
				var bc = this.benefitsModel().createBindingContext(thisKey);
				if (thisKey === planKey) {
					this.benefitsModel().setProperty("enrolled", "X", bc);
				}
			}.bind(this));

			this.model.setProperty("/isLoading", true);
			this.benefitsModel().submitChanges({
				success: this.getPlans.bind(this)
			});
		},
		handleDeductionSuccess:function(data){
			var wizardModel = this.getView().getParent().getParent().getParent().getModel();
			wizardModel.setProperty("/premium",data.premium);
		},
		getRelevantPlans: function (result) {
			var deductions = "/totalDeduction(pernr='"+ this.routeArgs.Pernr +"',event='"+this.routeArgs.Event+"')";
			
			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});
			
			
			var plans = result.results.filter(function (p) {
				return p.pltyp === this.planType;
			}.bind(this));

			var levels = [];
			plans.forEach(function (p) {
				if (levels.indexOf(p.depcv) === -1 && p.depcv !== "WAIV") {
					levels.push(p.depcv);
				}
			});
			levels = levels.sort().map(function (l) {
				var ret = {
					key: l
				};
				if (l === "EE") {
					ret.text = this.getTranslatedText("employeeOnly");
				} else if (l === "EE+1") {
					ret.text = this.getTranslatedText("employeePlusOne");
				} else if (l === "EFAM" || l === "EEFA") {
					ret.text = this.getTranslatedText("employeePlusFamily");
				}
				return ret;
			}.bind(this));
			this.model.setProperty("/levels", levels);

			plans = plans.sortByAttribute("bopti")
				.sortByAttribute("bplan");

			var enrolled = plans.filter(function (p) {
				return p.enrolled === "X";
			})[0];

			if (enrolled) {
				var selectedLevel = enrolled.depcv;
				if (enrolled.depcv === "WAIV") {
					selectedLevel = "EE";
				}
				this.model.setProperty("/selectedLevel", selectedLevel);
				this.model.setProperty("/selectedPlan", enrolled.bplan + enrolled.bopti);
			}

			this.model.setProperty("/plans", plans.map(this.mapSapElement.bind(this)));
			this.model.setProperty("/isLoading", false);
		},
		getTitleForPlan: function (p) {
			return this.getTranslatedText(planUtils.getTitleKeyForPlan(p));
		},
		mapSapElement: function (p) {
			var attributes = [];
						var out_of_pocket = "";
						var deductibles = "";
						// This Logic should work only for Dental or Vision Plans
						if (p.bplan === "2000" || p.bplan === "3000") {

							//For Out Of Pocket Expenses
							if (p.out_pocket === "0.00") {
								out_of_pocket = "N/A";
							} else {
								out_of_pocket = this.currencyFormatter.format([p.out_pocket, "$"]);
							}
							//For Deductibles
							if (p.deductible === "0.00") {
								deductibles = "N/A";
							} else {
								deductibles = this.currencyFormatter.format([p.deductible, "$"]);
							}
						} else {
							out_of_pocket = this.currencyFormatter.format([p.out_pocket, "$"]);
							deductibles = this.currencyFormatter.format([p.deductible, "$"]);
						}			
			if (p.depcv !== "WAIV") {
				attributes = [{
					title: this.getTranslatedText("employeePlanPremium"),
					value: this.currencyFormatter.format([p.amount, "$"]) + this.getTranslatedText("perMonth")
				}, {
					title: this.getTranslatedText("outOfPocketLimit"),
					value: out_of_pocket
				}, {
					title: this.getTranslatedText("deductible"),
					value: deductibles
				}, {
					title: this.getTranslatedText("spendingAccountEligibility"),
					value: this.getTranslatedText("flexibleSpendingAccount")
				}];
			}
			p.Pernr = this.routeArgs.Pernr;
			return {
				title: this.getTitleForPlan(p),
				linkText: this.getTranslatedText("planDetails"),
				key: p.bplan + p.bopti,
				level: p.depcv,
				attributes: attributes,
				sapElement: p
			};
		}
	});
});