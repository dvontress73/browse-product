sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"dart/hcm/benefits/utils/planUtils",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/core/format/NumberFormat"
], function (
	Controller,
	JSONModel,
	planUtils,
	dependentUtils,
	Filter,
	FilterOperator,
	History,
	NumberFormat
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.summary", {
		onInit: function () {
			this.getRouter().getRoute("SumStep").attachPatternMatched(this.onWizardRouteMatched.bind(this));
			this.getRouter().getRoute("CurrentBenefits").attachPatternMatched(this.onConfirmationRouteMatched.bind(this));
			this.getRouter().getRoute("Summary").attachPatternMatched(this.onConfirmationRouteMatched.bind(this));

		},

		onConfirmationRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel(false);
			if (this.routeArgs.Event === "ANY") {
				this.model.setProperty("/isAny", true);
			}
			this.getBenefitElections();
			this.getMDVPlans();
			this.getBeneficiaries();

			var history = History.getInstance();
			var previousRoute = history.getPreviousHash();
			if (previousRoute && previousRoute.includes("wizard")) {
				this.model.setProperty("/showConfirmationMessage", true);

			}
			this.model.setProperty("/showDownloadButton", true);
		},
		onWizardRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel(true);
			this.getBenefitElections();
			this.getMDVPlans();
			this.getBeneficiaries();
			this.getView().byId("idIconEOI").setTooltip(this.getTranslatedText("supplementLifeEOIRequirements"));

		},
		initLocalModel: function (review) {
			this.model = new JSONModel({
				isReview: review,
				title: "",
				employeeInfo: {},
				benefitElections: [],
				currency: "$",
				dependents: [],
				medicalPlan: null,
				dentalPlan: null,
				visionPlan: null,
				insurancePlan: null,
				medicalDependents: [],
				dentalDependents: [],
				visionDependents: [],
				supplementalBeneficiaries: [],
				lifeBeneficiaries: [],
				showConfirmationMessage: false,
				showDownloadButton: false,
				showEOI: false,
				date: new Date(),
				isAny: false
			});

			this.getView().setModel(this.model);
		},
		getHeaderInformation: function (pernr) {
			var key = this.benefitsModel()
				.createKey("/benefit_summary", {
					pernr: pernr
				});
			this.benefitsModel().read(key, {
				success: function (info) {
					this.model.setProperty("/title", this.getTranslatedText("summaryPageTitle", info.name));
					this.model.setProperty("/employeeInfo", info);
					if (this.routeArgs) {
						this.getHeaderForDependents(info);
					}
				}.bind(this)
			});
		},
		getMDVPlans: function () {
			this.mdvFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.mdvEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			this.oDateFilter = new sap.ui.model.Filter({
				path: "begda",
				operator: FilterOperator.EQ,
				value1: dateFormat.format(this.getView().byId("idDate").getDateValue())
			});

			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.mdvFilter, this.mdvEventFilter, this.oDateFilter],
				success: function (result) {

					var plans = result.results.filter(function (plan) {
						return plan.enrolled === "X";
					});

					this.model.setProperty("/medicalPlan", plans.filter(function (plan) {
						return plan.pltyp === "AMED";
					})[0]);
					this.model.setProperty("/dentalPlan", plans.filter(function (plan) {
						return plan.pltyp === "DENT";
					})[0]);
					this.model.setProperty("/visionPlan", plans.filter(function (plan) {
						return plan.pltyp === "VISN";
					})[0]);

					if (this.routeArgs) {
						this.getHeaderInformation(this.routeArgs.Pernr);
					} else {
						this.benefitsModel().read("/empl_headSet", {
							success: function (r) {
								this.getHeaderInformation(r.results[0].Pernr);
								this.getDependents(r.results[0]);
							}.bind(this)
						});
					}
				}.bind(this)
			});
		},
		getBeneficiaries: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.benefitsModel().read("/emplBeneficiariesSet", {
				filters: [this.oFilter],
				success: function (result) {
					this.getInsurancePlan(result.results);
				}.bind(this)
			});
		},
		getInsurancePlan: function (beneficiaries) {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			this.oDateFilter = new sap.ui.model.Filter({
				path: "begda",
				operator: FilterOperator.EQ,
				value1: dateFormat.format(this.getView().byId("idDate").getDateValue())
			});

			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter, this.oDateFilter],
				success: function (results) {
					var plans = results.results.filter(function (p) {
						return p.enrolled === "X";
					});

					var lifePlan = plans.filter(function (p) {
						return p.pltyp === "BCLF";
					});
					var lifeBeneficiaries = [];
					var suppBeneficiaries = [];
					var benificiary = {};
					var that = this;
					this.benefitsModel().read("/BeneficiarieSummarySet", {
						filters: [this.oFilter, this.oEventFilter, this.oDateFilter],
						success: function (result) {

							for (var i = 0; i < result.results.length; i++) {
								benificiary.fullName = result.results[i].fullname;
								benificiary.relation = result.results[i].relation;
								benificiary.primary = result.results[i].primary;
								benificiary.contingent = result.results[i].contingent;
								if (result.results[i].pltyp === "BCLF") {
									lifeBeneficiaries.push(benificiary);
									benificiary = {};

								} else {
									suppBeneficiaries.push(benificiary);
									benificiary = {};
								}
							}
							that.model.setProperty("/lifeBeneficiaries", lifeBeneficiaries);
							that.model.setProperty("/supplementalBeneficiaries", suppBeneficiaries);
						}
					});

					// for (var i = 1; i <= 20; i++) {
					//           var num = ("00" + i).slice(-2);
					//           var ben = beneficiaries.filter(function (dep) {
					//                         return lifePlan["dty" + num] === dep.subty &&
					//                                       lifePlan["did" + num] === dep.objps;
					//           })[0];
					//           if (ben) {
					//                         lifeBeneficiaries.push(ben);
					//           }
					// }
					// this.model.setProperty("/lifeBeneficiaries", lifeBeneficiaries);

					// var suppPlan = plans.filter(function (p) {
					//           return p.pltyp === "SUPP";
					// });
					// // var suppBeneficiaries = [];
					// for (var i = 1; i <= 20; i++) {
					//           var num = ("00" + i).slice(-2);
					//           var ben = beneficiaries.filter(function (dep) {
					//                         return suppPlan["dty" + num] === dep.subty &&
					//                                       suppPlan["did" + num] === dep.objps;
					//           })[0];
					//           if (ben) {
					//                         suppBeneficiaries.push(ben);
					//           }
					// }
					// this.model.setProperty("/supplementalBeneficiaries", suppBeneficiaries);
				}.bind(this)
			});
		},
		getHeaderForDependents: function (info) {
			var key = this.benefitsModel()
				.createKey("/empl_headSet", this.routeArgs);
			this.benefitsModel().read(key, {
				success: this.getDependents.bind(this)
			});
		},
		getDependents: function (header) {
			if (this.model.getProperty("/date")) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				header.date = dateFormat.format(this.getView().byId("idDate").getDateValue());
			}
			dependentUtils.getDependentsFromOdata(header, function (dependents) {
				this.model.setProperty("/dependents", dependents);
				this.assignDependents("medical");
				this.assignDependents("dental");
				this.assignDependents("vision");
			}.bind(this));
		},
		formatPhoneNumber: function (num) {
			if (!num) {
				return "";
			}
			var str = "(";
			str += num.substring(0, 3);
			str += ") ";
			str += num.substring(3, 6);
			str += "-";
			str += num.substring(6);
			return str;
		},
		getBenefitElections: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			this.oDateFilter = new sap.ui.model.Filter({
				path: "begda",
				operator: FilterOperator.EQ,
				value1: dateFormat.format(this.getView().byId("idDate").getDateValue())
			});

			var key = "/plan_summary";
			this.benefitsModel().read(key, {
				filters: [this.oFilter, this.oEventFilter, this.oDateFilter],
				success: function (result) {
					var suppIndex = result.results.findIndex((el) => el.eoi_flag === 'X' && el.pltyp == 'Supplement Life');
					if (suppIndex >= 0) {
						result.results[suppIndex].eoi_flag = "sap-icon://alert";
						this.model.setProperty("/showEOI", true);
					}
					var splpIndex = result.results.findIndex((el) => el.eoi_flag === 'X' && el.pltyp == 'Dep Life Spouse');
					if (splpIndex >= 0) {
						result.results[splpIndex].eoi_flag = "sap-icon://alert";
						this.model.setProperty("/showEOI", true);
					}
					var depcIndex = result.results.findIndex((el) => el.eoi_flag === 'X' && el.pltyp == 'Dep Life Child');
					if (depcIndex >= 0) {
						result.results[depcIndex].eoi_flag = "sap-icon://alert";
						this.model.setProperty("/showEOI", true);
					}
					this.model.setProperty("/benefitElections", result.results);
				}.bind(this)
			});
		},
		assignDependents: function (planName) {
			var dependents = this.model.getProperty("/dependents");
			var plan = this.model.getProperty("/" + planName + "Plan");
			if (plan) {
				var planDependents = [];
				var employee = dependents.filter(function (p) {
					return p.status_id === "0";
				})[0];
				if (plan.depcv !== "WAIV") {
					planDependents.push(employee);
				}
				for (var i = 1; i <= 20; i++) {
					var num = ("00" + i).slice(-2);
					var dependent = dependents.filter(function (dep) {
						return plan["dty" + num] === dep.sapDep.subty &&
							plan["did" + num] === dep.sapDep.objps;
					})[0];
					if (dependent) {
						planDependents.push(dependent);
					}
				}

				this.model.setProperty("/" + planName + "Dependents", planDependents);
			}
		},
		pltypToDescription: function (planType) {
			var val = {
				"AMED": this.getTranslatedText("medical"),
				"DENT": this.getTranslatedText("dental"),
				"VISN": this.getTranslatedText("vision"),
				"SUPP": this.getTranslatedText("supplementalLife"),
				"SPLP": this.getTranslatedText("supplementalLife"),
				"DEPC": this.getTranslatedText("supplementalLife"),
				"MCRI": this.getTranslatedText("supplemental"),
				"SCRI": this.getTranslatedText("supplemental"),
				"MHSI": this.getTranslatedText("supplemental"),
				"MACP": this.getTranslatedText("supplemental")
			}[planType];

			if (val) {
				return val;
			}
			return planType;
		},
		planToOption: function (plan) {
			var planType = plan.pltyp;
			var val = {
				"AMED": this.getTranslatedText(planUtils.getTitleKeyForPlan(plan)),
				"DENT": this.getTranslatedText(planUtils.getTitleKeyForPlan(plan)),
				"VISN": this.getTranslatedText(planUtils.getTitleKeyForPlan(plan)),
				"SUPP": this.getTranslatedText("supplementalLife"),
				"SPLP": this.getTranslatedText("supplementalSpouse"),
				"DEPC": this.getTranslatedText("supplementalChild"),
				"MCRI": this.getTranslatedText("employeeCriticalIllness"),
				"SCRI": this.getTranslatedText("spouseCriticalIllness"),
				"MHSI": this.getTranslatedText("hospitalCoverage"),
				"MACP": this.getTranslatedText("accidentCoverage")
			}[planType];

			if (val) {
				return val;
			}
			return planType;
		},
		depcvToDescription: function (plan) {
			var key = planUtils.getTextKeyForPlanLevel(plan.depcv);
			if (["MHSI", "MACP", "SCRI", "MCRI"].includes(plan.pltyp)) {
				return plan.amount;
			}

			if (!isNaN(parseFloat(key))) {
				var fmtOptions = {
					currencyCode: true,
					showMeasure: true,
					maxFractionDigits: 2
				};
				// var currencyFormat = sap.ui.core.format.NumberFormat.getCurrencyInstance(fmtOptions);
				var currencyFormat = NumberFormat.getCurrencyInstance(fmtOptions);
				key = currencyFormat.format(key, this.model.getProperty("/currency"));
			}
			return this.getTranslatedText(key);
		},
		onDownload: function (oEvent) {
			this.model.setProperty("/showDownloadButton", false);
			var oTarget = this.getView(),
				sTargetId = oEvent.getSource().data("targetId");

			if (sTargetId) {
				oTarget = oTarget.byId(sTargetId);
			}
			this.model.setProperty("/showDownloadButton", true);
			if (oTarget) {
				var $domTarget = oTarget.$()[0],
					sTargetContent = $domTarget.innerHTML,
					sOriginalContent = document.body.innerHTML;
				this.createDOM(sTargetContent);
				document.reload();
			}

		},
		createDOM: function PrintElem(elem) {
			var mywindow = window.open("", "PRINT", "height=400,width=600");

			mywindow.document.write("<html><head><title>" + document.title + "</title>");
			mywindow.document.write("</head><body >");
			mywindow.document.write("<h2>" + document.title + ":Terms & Conditions" + "</h2>");
			mywindow.document.write("<h4>" + elem + "</h4>");
			mywindow.document.write("</body></html>");
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10*/
			mywindow.print();
			mywindow.close();
			return true;
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},

		onDateChange: function (oEvent) {
			//To Do 
			this.getBenefitElections();
			this.getMDVPlans();
			this.getBeneficiaries();

		},
		submit: function () {
			this.oPlanFilter = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oPlanEvent = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});
			this.submitEnrollments(this.routeArgs.Pernr, this.routeArgs.Event, this.routeArgs.Begda, this.routeArgs.Endda);
		}
	});
});