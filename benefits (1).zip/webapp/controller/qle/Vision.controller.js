sap.ui.define([
	"dart/hcm/benefits/controller/HealthPlanBase",
	"sap/ui/core/format/NumberFormat"
], function (
	Controller,
	NumberFormat
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.qle.Vision", {
		planType: "VISN",
		
		onInit: function() {
			this.getRouter().getRoute("QLEVisionStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});