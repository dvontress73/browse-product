sap.ui.define([
	"dart/hcm/benefits/controller/qle/HealthPlanBase",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/format/NumberFormat"
], function (
	Controller,
	JSONModel,
	MessageToast,
	NumberFormat
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.qle.Medical", {
		
		planType: "AMED",
		
		onInit: function() {
			this.getRouter().getRoute("QLEMedicalStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});