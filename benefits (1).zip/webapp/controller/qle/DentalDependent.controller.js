sap.ui.define([
	"dart/hcm/benefits/controller/qle/HealthDependentBase",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/dependentUtils"
], function (
	Controller,
	NumberFormat,
	DependentUtils
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.qle.DentalDependent", {
		planType: "DENT",
		dependentLimits: DependentUtils.dependentLimits.DENT,
		onInit: function() {
			this.getRouter().getRoute("QLEDenDepStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.currencyFormatter = NumberFormat.getCurrencyInstance();
		}
	});
});