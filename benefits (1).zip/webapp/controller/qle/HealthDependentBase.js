sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/NumberFormat",
	"dart/hcm/benefits/utils/planUtils",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	Controller,
	JSONModel,
	NumberFormat,
	planUtils,
	dependentUtils,
	MessageToast,
	MessageBox,
	Filter,
	FilterOperator
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.qle.HealthDependentBase", {
		planType: "",
		familyPlanCode: "",
		dependentLimits: {},
		
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.getSelectedPlan();
			this.getDependents();
		},
		
		initLocalModel: function () {
			this.model = new JSONModel({
				selectedPlan: {},
				dependents: [],
				enteredWithFamily: false,
				url: "",
				items: {},
				allPlans: {},
				selectedKey: {}
			});
			this.getView().setModel(this.model);
		},
		
		getSelectedPlan: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});
			this.benefitsModel().read("/mdvPlanSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: function (result) {
					this.model.setProperty("/allPlans", result);
					var plan = result.results.filter(function (p) {
						return p.pltyp === this.planType && p.enrolled === "X";
					}.bind(this))[0];

					if (plan) {
						var planModel = {
							title: this.getTranslatedText(planUtils.getTitleKeyForPlan(plan)),
							sapEntity: plan,
							attributes: []
						};
						var out_of_pocket = "";
						var deductibles = "";
						// This Logic should work only for Dental or Vision Plans
						if (plan.bplan === "2000" || plan.bplan === "3000") {

							//For Out Of Pocket Expenses
							if (plan.out_pocket === "0.00") {
								out_of_pocket = "N/A";
							} else {
								out_of_pocket = this.currencyFormatter.format([plan.out_pocket, "$"]);
							}
							//For Deductibles
							if (plan.deductible === "0.00") {
								deductibles = "N/A";
							} else {
								deductibles = this.currencyFormatter.format([plan.deductible, "$"]);
							}
						} else {
							out_of_pocket = this.currencyFormatter.format([plan.out_pocket, "$"]);
							deductibles = this.currencyFormatter.format([plan.deductible, "$"]);
						}
						if (plan.btype !== "1009") {
							planModel.attributes = [{
								title: this.getTranslatedText("planLevel"),
								value: this.getTranslatedText(planUtils.getTextKeyForPlanLevel(plan.depcv))
							}, {
								title: this.getTranslatedText("employeePlanPremium"),
								value: this.currencyFormatter.format([plan.amount, "$"]) + " / month"

							}, {
								title: this.getTranslatedText("outOfPocketLimit"),
								value: out_of_pocket
							}, {
								title: this.getTranslatedText("deductible"),
								value: deductibles
							}, {
								title: this.getTranslatedText("spendingAccountEligibility"),
								value: this.getTranslatedText("flexibleSpendingAccount")
							}];
						}
						if (this.getDependentLimit(plan.depcv) === 19) {
							this.model.setProperty("/enteredWithFamily", true);
						}
						this.model.setProperty("/selectedPlan", planModel);
						this.model.setProperty("/selectedKey", planModel.sapEntity.depcv);
						var allUrls = this.getModel("helpfullinks").getProperty("/" + planModel.sapEntity.pltyp + "");
						if (allUrls !== undefined) {
							var urls = allUrls.filter(function (p) {
								return p.event === plan.event;
							});
						}
						var planName = planUtils.getKeyForBplan(plan.bplan);
						if (planModel.sapEntity.pltyp === "AMED") {
							if (planModel.title === "DMC Premier PPO") {
								planName = "PRM";
							} else {
								planName = "DMC";
							}
						}
						if (urls !== undefined) {
							var finalLink = [];
							finalLink = urls.filter(function (l) {
								return l.url_id.includes(planName.toUpperCase());
							});
							if (finalLink.length > 0) {
								this.model.setProperty("/url", finalLink[0].url);
							}
						}
						if (planModel.sapEntity.pltyp === "AMED") {
							this.model.setProperty("/items", planUtils.getKeyLevelMedical());

						} else {
							this.model.setProperty("/items", planUtils.getKeyLevelDental());
						}
					}

				}.bind(this)
			});
		},
		getDependents: function () {
			//set this here so it can be used on data refresh
			this.model.setProperty("/dependents", []);
			if (this.routeArgs.Pernr) {
				this.getHeaderInformation();
			} else {
				this.getDependentsFromOdata(null);
			}
		},
		getHeaderInformation: function () {
			var key = this.benefitsModel().createKey("/empl_headSet", this.routeArgs);
			
			this.benefitsModel().read(key, {
				success: function (header) {
					header.date = this.routeArgs.Begda;

					this.getDependentsFromOdata(header);
				}.bind(this)
			});
		},
		getDependentsFromOdata: function (header) {
			dependentUtils.getDependentsFromOdata(header, function (dependents) {
				var currentPlan = this.model.getProperty("/selectedPlan").sapEntity;
				var counter = 0;
				dependents.forEach(function (d) {
					if (currentPlan.btype === "1009") {
						d.enrolled = false;
						d.enabled = false;
					} else if (d.status_id === "0") {
						d.enrolled = true;
						d.enabled = false;
					} else {
						var enrolled = false;
						for (var i = 1; i <= 20; i++) {
							var num = ("00" + i).slice(-2);
							if (currentPlan["dty" + num] === d.sapDep.subty &&
								currentPlan["did" + num] === d.sapDep.objps) {
								enrolled = true;
								counter = counter + 1;
								break;
							}
						}
						d.enrolled = enrolled;
						d.enabled = true;
					}
				});

				var currentLevel = this.model.getProperty("/selectedPlan").sapEntity.depcv;
				var currentLimit = this.getDependentLimit(currentLevel);
				if (currentLimit === counter) {
					dependents.forEach(function (d) {
						d.enabled = d.enrolled;
					});
				}
				this.model.setProperty("/dependents", dependents);
			}.bind(this));
		},
		onDependentSelect: function (event) {
	
	
			var context = event.getSource().getBindingContext().sPath.split("/")[2];
			var eDate = this.routeArgs.Begda;
			var dobDate = this.model.getProperty("/dependents")[context].dateOfBirth;
			var eligDate = new Date(eDate.slice(0,4),eDate.slice(4,6)-1,eDate.slice(6,8));
			var years = new Date(eligDate - dobDate).getFullYear() - 1970;
			var subty = this.model.getProperty("/dependents")[context].sapDep.subty;
			if(years >= 26 && subty !== "1" && !this.model.getProperty("/dependents")[context].sapDep.disab){
				MessageBox.error("Dependent is over 26 years, please contact HR Connect for more information");
				this.model.getProperty("/dependents")[context].enrolled = false;
				return;
			}
			
			
			var source = event.getSource();
			// this.checkLevelChangeNeeded(source);
			this.toggleDependentsCheckBox(source.getSelected());

		},

		toggleDependentsCheckBox: function (selected) {
			var currentLevel = this.model.getProperty("/selectedPlan").sapEntity.depcv;
			var numDependents = this.getEnrolledDependents().length;
			var currentLimit = this.getDependentLimit(currentLevel);
			this.dependents = this.model.getProperty("/dependents");
			if (currentLevel === "EE") {
				for (var i = 1; i < this.dependents.length; i++) {
					this.dependents[i].enabled = false;
					this.dependents[1].enrolled = false;
				}
				return;
			}
			if (selected === true) {
				if (numDependents === currentLimit) {
					for (i = 0; i < this.dependents.length; i++) {
						if (this.dependents[i].enrolled)
							continue;
						else;
						this.dependents[i].enabled = false;
					}
				}
			} else {
				for (i = 0; i < this.dependents.length; i++) {
					this.dependents[i].enabled = true;
				}
			}

			this.updateDependentsOnPlan();
			this.getSelectedPlan();
			this.getDependents();
		},
		getEnrolledDependents: function () {
			return this.model.getProperty("/dependents").filter(function (d) {
				return d.status_id !== "0" && d.enrolled;
			});
		},
		updateDependentsOnPlan: function () {
			var plan = this.model.getProperty("/selectedPlan").sapEntity;

			this.assignDependentsToSapEntity(plan);
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var key = this.benefitsModel().createKey("/mdvPlanSet", plan);
			this.benefitsModel().update(key, plan, {
				success: function () {
					jQuery.sap.delayedCall(1000, this, function () {
						oBusy.close();
					});

				},
				error: function () {
					oBusy.close();
					MessageToast.show("There was an error updating your selected dependents, please refresh and try again.");
				}
			});
		},
		checkLevelChangeNeeded: function (source) {

			var currentLevel = this.model.getProperty("/selectedPlan").sapEntity.depcv;
			var numDependents = this.getEnrolledDependents().length;
			var currentLimit = this.getDependentLimit(currentLevel);

			var newLevel = null;
			var levels = Object.keys(this.dependentLimits);
			var currentIndex = levels.indexOf(currentLevel);

			if (numDependents > currentLimit && currentIndex === levels.length - 1) {
				MessageBox.alert(this.getTranslatedText("dependentLimitReached", currentLimit), {
					onClose: function () {
						this.cancelSelection(source);
					}.bind(this)
				});
			} else if (numDependents > currentLimit) {
				newLevel = levels[currentIndex + 1];
				MessageBox.confirm(this.getTranslatedText(
					"upgradeCareLevel",
					this.getTranslatedText(planUtils.getTextKeyForPlanLevel(newLevel))
				), {
					onClose: function (action) {
						if (action === sap.m.MessageBox.Action.CANCEL) {
							this.cancelSelection(source);
						} else {
							this.updatePlanLevel(newLevel);
						}
					}.bind(this)
				});
			} else {
				newLevel = Object.entries(this.dependentLimits)
					.map(function (a) {
						return {
							key: a[0],
							value: a[1]
						};
					})
					.sortByAttribute("value")
					.filter(function (level) {
						return level.value >= numDependents;
					})[0];

				if (newLevel) {
					newLevel = newLevel.key;
				} else {
					newLevel = null;
				}

				if (this.model.getProperty("/enteredWithFamily")) {
					if (this.getDependentLimit(newLevel) < 19) {
						this.model.setProperty("/enteredWithFamily", false);
						if (newLevel && newLevel !== currentLevel) {
							MessageBox.confirm(this.getTranslatedText(
								"addDependant",
								this.getTranslatedText(planUtils.getTextKeyForPlanLevel(newLevel))
							), {
								onClose: function (action) {
									if (action === sap.m.MessageBox.Action.CANCEL) {
										this.cancelSelection(source);
									} else {
										this.updatePlanLevel(newLevel);
									}
								}.bind(this)
							});
						}
					}
					this.updateDependentsOnPlan();
				} else if (newLevel && newLevel !== currentLevel) {
					MessageBox.confirm(this.getTranslatedText(
						"downgradeCareLevel",
						this.getTranslatedText(planUtils.getTextKeyForPlanLevel(newLevel))
					), {
						onClose: function (action) {
							if (action === sap.m.MessageBox.Action.CANCEL) {
								this.cancelSelection(source);
							} else {
								this.updatePlanLevel(newLevel);
							}
						}.bind(this)
					});
				} else {
					this.updateDependentsOnPlan();
				}
			}
		},
		getDependentLimit: function (level) {
			return this.dependentLimits[level];
		},
		updatePlanLevel: function (newLevel) {
			var currentPlan = this.model.getProperty("/selectedPlan").sapEntity;
			var currentBindingContext = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", currentPlan));
			this.benefitsModel().setProperty("enrolled", "", currentBindingContext);

			var newPlan = this.model.getProperty("/selectedPlan").sapEntity;
			newPlan.depcv = newLevel;
			newPlan.enrolled = "X";
			this.assignDependentsToSapEntity(newPlan);

			var newBindingContext = this.benefitsModel().createBindingContext(this.benefitsModel().createKey("/mdvPlanSet", newPlan));
			Object.keys(newPlan).forEach(function (property) {
				if (property === "enrolled" || property.startsWith("dty" || property.startsWith("did"))) {
					this.benefitsModel().setProperty(property, newPlan[property], newBindingContext);
				}
			}.bind(this));

			var key = this.benefitsModel().createKey("/mdvPlanSet", newPlan);
			var that = this;
			this.benefitsModel().update(key, newPlan, {
				success: function () {
					jQuery.sap.delayedCall(500, this, function () {
						that.getSelectedPlan();
						that.getDeductions();

					});
				},
			});

		},
		getDeductions: function () {
			var deductions = "/totalDeduction(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";
			this.benefitsModel().read(deductions, {
				success: this.handleDeductionSuccess.bind(this)
			});
		},
		handleDeductionSuccess: function (data) {
			var wizardModel = this.getView().getParent().getParent().getParent().getModel();
			wizardModel.setProperty("/premium", data.premium);
		},
		cancelSelection: function (source) {
			var bc = source.getBindingContext();
			this.model.setProperty("enrolled", !bc.getProperty("enrolled"), bc);
		},
		assignDependentsToSapEntity: function (sapEntity) {
			var enrolledDependents = this.getEnrolledDependents();

			for (var i = 0; i < 20; i++) {
				var num = ("00" + (i + 1)).slice(-2);
				var dep = enrolledDependents[i];
				if (dep) {
					sapEntity["dty" + num] = dep.sapDep.subty;
					sapEntity["did" + num] = dep.sapDep.objps;
				} else {
					sapEntity["dty" + num] = "";
					sapEntity["did" + num] = "";
				}
			}
		},

		onEmpOnly: function (oEvent) {
			var ifSelected = oEvent.getSource().getProperty("selected");

			if (ifSelected) {
				var dependents = this.model.getProperty("/dependents");
				for (var i = 0; i < dependents.length - 1; i++) {
					if (dependents[i].relation === "Employee") {
						continue;
					}
					dependents[i].enrolled = false;
				}
				this.model.setProperty("/dependents", dependents);
				MessageBox.confirm(this.getTranslatedText(
					"downgradeCareLevel",
					this.getTranslatedText(planUtils.getTextKeyForPlanLevel("EE"))
				), {
					onClose: function (action) {
						if (action === sap.m.MessageBox.Action.CANCEL) {
							oEvent.getSource().setProperty("selected", false);
						} else {
							this.updatePlanLevel("EE");
						}
					}.bind(this)
				});
			}
		},

		onLevelChange: function (event) {
			if (!this.oApprove) {
				this.oApprove = new sap.m.Dialog({
					type: sap.m.DialogType.Message,
					title: "Change of Plan Level",
					content: new sap.m.Text({
						text: "Dependent Selections will be Reset. Are you sure you want to Continue?"
					}),
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "Ok",
						press: function () {
							this.oApprove.close();
							var selectedPlan = this.model.getProperty("/selectedPlan");
							// this.currentPlan = this.model.getProperty("/selectedPlan").sapEntity;
							var allPlans = this.model.getProperty("/allPlans").results;
							var currentKey = this.model.getProperty("/selectedKey");
							this.currentPlan = allPlans.filter(function (element) {
								return (element.pltyp === selectedPlan.sapEntity.pltyp &&
									element.bplan === selectedPlan.sapEntity.bplan &&
									element.bopti === selectedPlan.sapEntity.bopti &&
									element.depcv === currentKey);
							});
							this.currentPlan = this.currentPlan[0];
							this.currentPlan.enrolled = "X";
							for (var i = 0; i < 20; i++) {
								var num = ("00" + (i + 1)).slice(-2);
								this.currentPlan["dty" + num] = "";
								this.currentPlan["did" + num] = "";
							}
							selectedPlan.sapEntity = this.currentPlan;
							this.model.setProperty("/selectedPlan", selectedPlan);
							var key = this.benefitsModel().createKey("/mdvPlanSet", selectedPlan.sapEntity);
							var that = this;
							this.benefitsModel().update(key, selectedPlan.sapEntity, {
								success: function () {
									jQuery.sap.delayedCall(500, this, function () {
										that.getSelectedPlan();
										that.getDeductions();
										that.getDependents();

										if (that.currentPlan.depcv === "EE") {
											var dep = that.model.getProperty("/dependents");
											for (i = 1; i < dep.length; i++) {
												dep[i].enabled = false;
												dep[i].enrolled = false;
											}
										} else {
											that.getHeaderInformation();
										}

									});
								}
							});
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							this.getSelectedPlan();
							this.oApprove.close();
						}.bind(this)
					})
				});
			}
			this.oApprove.open();
		}
	});
});