sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel"
], function (
	Controller,
	JSONModel
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.qle.CurrentBenefits", {
		onInit: function () {
			this.getRouter().getRoute("QLECurrentBenefits").attachPatternMatched(this.onRouteMatched.bind(this));
		},
		
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
		},
		
		goHome: function () {
			var that = this;
				this.getRouter().navTo("LandingPage",{
					Pernr: that.routeArgs.Pernr
				});
		}
	});
});