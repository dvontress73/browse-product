sap.ui.define([
	"dart/hcm/benefits/controller/BeneficiaryBase",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button",
	"sap/m/DialogType",
	"sap/m/ButtonType",
	"sap/m/MessageBox"
], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	MessageToast,
	Fragment,
	Dialog,
	Text,
	Button,
	DialogType,
	ButtonType,
	MessageBox
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.SuppBeneficiaries", {
		onInit: function () {
			this.getRouter().getRoute("SuppBenStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.getRouter().getRoute("SuppBeneficiaries").attachPatternMatched(this.onRouteMatched.bind(this));
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.benefitsModel().read("/relationBeneficiarieSet");
			this.routeName = route.getParameters().name;
			this.initLocalModel();
			this.getInsurances();
		},
		initLocalModel: function () {
			this.model = new JSONModel({
				showIndividualForm: false,
				showOrganizationForm: false,
				isEdit: false,
				dialogTitle: "",
				beneficiary: {},
				totalPrimary: 0,
				totalContingent: 0,
				contingentStatus: "None",
				primaryStatus: "None",
				amount: "0",
				currency: "$",
				beneficiaries: [],
				sapEntity: {}
			});
			this.getView().setModel(this.model);
		},
		getInsurances: function () {
			this.oFilter = new sap.ui.model.Filter({
				path: "Pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.oEventFilter = new sap.ui.model.Filter({
				path: "event",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Event
			});
			this.benefitsModel().read("/lifeInsHeadSet", {
				filters: [this.oFilter, this.oEventFilter],
				success: this.getInsuranceAmount.bind(this)
			});
		},
		getInsuranceAmount: function (result) {
			var selected = result.results.filter(function (i) {
				return i.enrolled === "X" && i.bplan === "SUPP";
			})[0];

			if (selected) {
				this.model.setProperty("/sapEntity", selected);
				this.model.setProperty("/amount", selected.amount);
				this.getBeneficiaries(selected);
			}
			//Supplemental Life Changes
			var that = this;
			var suppInsLink = this.getModel("helpfullinks").getProperty("/suppInsLinks");
			if (suppInsLink.length > 0 && suppInsLink !== undefined) {
				var suppIns = suppInsLink.filter(function (p) {
					return p.event === that.routeArgs.Event;
				});
				if (suppIns.length > 0) {
					this.getModel("helpfullinks").setProperty("/suppIns", suppIns[0].url);
				}
			}

		},
		updateBeneficiaryAllocations: function () {
			var that = this;
			var allocations = {};
			this.model.getProperty("/beneficiaries").forEach(function (ben, index) {
				var key = ("00" + (index + 1)).slice(-2);
				allocations["dty" + key] = ben.sapBen.subty;
				allocations["did" + key] = ben.sapBen.objps;
				allocations["bpt" + key] = ben.primaryPercent || "0"; // these fields are strings in SAP
				allocations["cbpt" + key] = ben.contingentPercent || "0";
			});

			var life = this.model.getProperty("/sapEntity");
			life.suppBenPage = "X";
			var path = this.benefitsModel().createKey("/lifeInsHeadSet", life);
			this.benefitsModel().update(path, Object.assign(life, allocations), {
				success: function (msg) {
					that.oBusyDialog.close();
					that.getRouter().navTo(that.routeName, that.routeArgs);
				},
				error: function (msg) {
					that.oBusyDialog.close();
					MessageToast.show("there was an error saving allocations");
					that.getRouter().navTo(that.routeName, this.routeArgs);
				}
			});
		},
		closeDialog: function () {
			this.getBeneficiaries(this.model.getProperty("/sapEntity"));
			Controller.prototype.closeDialog.bind(this)();
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},
		toSummary: function () {
			var that = this;
			if (!this.oConfirmation) {
				this.oConfirmation = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Submit?."
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Continue",
						press: function () {
							//Get the model of the child view and check 100% prim ben
							that.oConfirmation.close();
							var oModel = that.getView().getAggregation("content")[0].getAggregation("content")[0].getModel();
							if (oModel.getProperty("/primaryStatus") === "Error" || oModel.getProperty("/contingentStatus") === "Error") {
								MessageBox.error("Percentage not equals 100%");
								return;
							} else {
								var selectedPlan = oModel.getProperty("/sapEntity");
								var key = that.benefitsModel().createKey("/resetValuesSet", {
									Pernr: selectedPlan.Pernr,
									event: selectedPlan.event,
									pltyp: selectedPlan.pltyp,
									bplan: selectedPlan.bplan,
									bopti: selectedPlan.bopti
								});
								var payload = {};
								payload.Pernr = selectedPlan.Pernr;
								payload.event = selectedPlan.event;
								payload.pltyp = selectedPlan.pltyp;
								payload.bplan = selectedPlan.bplan;
								payload.bopti = selectedPlan.bopti;

								that.benefitsModel().update(key, payload, {
									method: "PUT",
									success: function (odata, Response) {
										that.getRouter()
											.navTo("CurrentBenefits", {
												Pernr: that.routeArgs.Pernr,
												Event: that.routeArgs.Event,
												Begda: that.routeArgs.Begda,
												Endda: that.routeArgs.Endda
											});

									},
									error: function (cc, vv) {

									}
								});
							}
						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oConfirmation.close();
						}.bind(this)
					})
				});
			}

			this.oConfirmation.open();

		},
		toSuppIns:function(){
			var that = this;
			this.getRouter().navTo("SuppInsurance", {
					Pernr: that.routeArgs.Pernr,
					Event: that.routeArgs.Event,
					Begda: that.routeArgs.Begda,	
					Endda: that.routeArgs.Endda
			});
			
		}
	});
});