sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/m/Dialog"
], function (BaseController, JSONModel, Filter, FilterOperator, MessageBox, Device, Dialog) {
	"use strict";

	return BaseController.extend("dart.hcm.benefits.controller.WelcomeVideo", {

		onInit: function () {
			this.getRouter()
				.getRoute("WelcomeVideo")
				.attachPatternMatched(this.routeMatched.bind(this));
			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			if (oDeviceModel.getData().system.phone) {
				this.desktopView = false;
			}
		},
		videoDoc: null,
		routeMatched: function (route) {
			this.getProxyPernr(route.getParameters().arguments.Pernr);
			this.routeArgs = route.getParameters().arguments;
			this.checkPermission(this.routeArgs.Pernr, this.routeArgs.Event, this.routeArgs.Begda, this.routeArgs.Endda);
			this.model = new JSONModel({
				defaultText: "",
				titleText: "",
				isWatched: "",
				isMobile: false
			});
			this.getView().setModel(this.model);
			this.getDefaultText();
			this.getEname();
			this.checkedWatched();
			this.getView().setModel(this.model);
			this.currentLanguage = this.getOwnerComponent().getModel("languageModel").getProperty("/currentLanguage");

		},
		currentLanguage: null,
		desktopView: true,
		onBeforeRendering: function () {
			var oHeader = this.getView().byId("pageHeader");
			if (!this.desktopView) {
				oHeader.removeAllContent();
				this.loadMobileFragment(oHeader);

			} else {
				oHeader.removeAllContent();
				this.loadDesktopFragment(oHeader);
			}
			this.setLanguage();
		},
		onLanguageChange: function (oEvent) {

			if (this.desktopView) {
				this.changeLanguage(oEvent.getSource()._getSelectedItemText());
				this.getDefaultText();
			} else {
				this.createRadioButton();
				this.dialog.open();
			}

		},
		closeDialog: function () {
			this.dialog.close();
		},
		onMobileLanguageSelection: function (oEvent) {
			this.changeLanguage(oEvent.getSource().getSelectedButton().getText());
			this.getDefaultText();
			this.dialog.close();
		},
		pernrKey: null,
		getProxyPernr: function (data) {
			if (data !== "") {
				this.pernrKey = data;
			} else {
				this.pernrKey = "X";
			}
		},
		getDefaultText: function () {
			this.benefitsModel().read("/welcome_terms_textSet", {
				success: this.handleTextSuccess.bind(this)
			});
		},
		getEname: function () {

			var sEname = "/getEnameSet('" + this.pernrKey + "')";
			this.benefitsModel().read(sEname, {
				success: this.handleEnameSuccess.bind(this)
			});
		},
		handleLinks: function (data) {
			var url = data.results.filter(function (r) {
				return r.url_id === "JIM_VIDEO";
			})[0].url;
			var html = new sap.ui.core.HTML();
			html.setContent(this.getVideoHtml(url));
			var videoContainer = this.getView().byId("videoContainer");
			videoContainer.removeAllItems();
			videoContainer.addItem(html);

		},
		handleEnameSuccess: function (data) {
			var title = this.getTranslatedText("landingPageTitle", data.ename);
			this.model.setProperty("/titleText", title);

		},
		play: function () {

			this.videoDoc = jQuery.sap.domById("welcomeVideo");
			this.videoDoc.play();
			this.getView().byId("idPause").setVisible(true);
			this.getView().byId("idFullScreen").setVisible(true);
			var that = this;
			this.videoDoc.addEventListener("ended", function () {
				if (that.videoDoc) {
					that.enableContinue();
				}
			});
		},
		videoEnded: null,
		enableContinue: function () {
			this.getView().byId("continue").setVisible(true);
			this.videoEnded = true;
		},
		pause: function () {
			this.videoDoc = jQuery.sap.domById("welcomeVideo");
			this.videoDoc.pause();
		},
		fullScreen: function () {
			this.videoDoc = jQuery.sap.domById("welcomeVideo");
			this.videoDoc.requestFullscreen();
			this.videoDoc.controls = false;
			this.videoDoc.load();
			this.videoDoc.play();
		},
		handleTextSuccess: function (data) {
			var lang = this.getModel("languageModel").getProperty("/currentLanguage");
			var currentLanguage;
			if (typeof lang === "undefined" || lang === "English" || lang === "Inglés") {
				currentLanguage = "E";
			} else {
				currentLanguage = "S";
			}

			var text = data.results.filter(function (r) {
				return r.type === "VideoDefault";
			})[0];
			if (text) {
				this.model.setProperty("/defaultText", text.text);
			}
			var languageFilter = new Filter({
				path: "spras",
				operator: FilterOperator.EQ,
				value1: currentLanguage
			});
			var PernrFilter = new Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: this.routeArgs.Pernr
			});
			this.benefitsModel()
				.read("/benefits_linkSet", {
					filters: [languageFilter, PernrFilter],
					success: this.handleLinks.bind(this)
				});
		},
		getVideoHtml: function (srcUrl) {
			var str = "";
			if (!this.desktopView) {
				str = "<video id='welcomeVideo' controls='true' width='100%' height='100%' playsinline muted controlsList='nodownload'>";
				str += "<source src='" + srcUrl + "' type='video/mp4'/>";
				
				
			} else {
				str = "<video src='" + srcUrl +"' width='100%' height='400' controls playsinline disablePictureInPicture id='welcomeVideo' controlsList='nodownload'>";
			}
			
			str += this.model.getProperty("/defaultText");
			str += "</video>";
			return str;
		},
		goToTermsAndConditions: function () {
			var that = this;
			this.videoDoc = jQuery.sap.domById("welcomeVideo");
			var videoDuration = this.videoDoc.duration;
			var currentTime = this.videoDoc.currentTime;
			if(videoDuration === currentTime){
				this.videoEnded = true;
			}
			this.videoDoc.addEventListener("ended", function () {
				if (that.videoDoc) {
					that.enableContinue();
				}
			});

			function onSuccess() {
				this.getRouter()
					.navTo("TermsAndConditions", this.routeArgs);
			}
			if (this.videoEnded) {
				this.updateCurrentStep(Object.assign({},
					this.routeArgs, {
						IdSession: "TermsAndConditions"
					}), {
					success: onSuccess.bind(this)
				});
			} else {
				this.videoDoc.pause();
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"Please watch the welcome video to continue.", {
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							that.videoDoc.play();
						}
					}
				);

			}
		},
		checkedWatched: function () {

			var watched = "/welcomeVideoSet(pernr='" + this.routeArgs.Pernr + "',event='" + this.routeArgs.Event + "')";
			this.benefitsModel()
				.read(watched, {
					success: this.handleWatched.bind(this)
				});
		},
		validateUser: function () {
			var proxy = "/proxyEmpSet('X')";
			this.benefitsModel().read(proxy, {
				success: this.handleproxySuccess.bind(this)
			});
		},
		handleproxySuccess: function (data) {
			if (data.validate === "true") {
				this.videoEnded = true;
				this.model.setProperty("/isWatched", true);
				this.enableContinue();
			} else {
				this.model.setProperty("/isWatched", false);
			}
		},
		handleWatched: function (data) {
			if (data.watched === "false") {
				this.validateUser();
			} else {
				this.videoEnded = true;
				this.model.setProperty("/isWatched", true);
				this.enableContinue();
			}

		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		}
	});

});