sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function (
	Controller,
	ResourceModel,
	JSONModel,
	Filter,
	FilterOperator,
	MessageBox,
	Fragment
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.BaseController", {
		benefitsModel: function () {

			return this.getOwnerComponent().getModel("benefits");
		},
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},
		getModel: function (name) {
			return this.getView().getModel(name);
		},
		updateCurrentStep: function (data, params) {
			var key = this.benefitsModel()
				.createKey("/empl_headSet", data);
			this.benefitsModel().read(key, {
				success: function (currentData) {
					this.benefitsModel()
						.update(key, Object.assign({}, currentData, data), params);
				}.bind(this)
			});
		},
		checkPermission: function (pernr, event, begda, endda) {
			var that = this;
			var key = "/checkPermissionSet(pernr='" + pernr +
				"',begda='" + begda +
				"',endda='" + endda +
				"',event='" + event + "')";
			if (pernr) {

				this.benefitsModel().read(key, {
					success: function (response, error) {
						//
					},
					error: function (response) {
						var msg = JSON.parse(response.responseText).error.message.value;
						MessageBox.error(msg, {
							onClose: function (oAction) {
								window.history.go(-1);
							}
						});
					}
				});
			}
		},
		empName: null,
		getUserName: function () {
			function onSuccess(data) {
				this.empName = data.ename;
			}
			var sEname = "/getEnameSet('00000')";
			this.benefitsModel().read(sEname, {
				success: onSuccess.bind(this)
			});
			// return sap.ushell.Container.getService("UserInfo").getUser().getFullName();
			return this.empName;
		},
		getTranslatedText: function (key, variables) {

			var i18n = this.getOwnerComponent().getModel("i18n");
			return i18n.getResourceBundle().getText(key, variables);
		},
		getEmployeePernr: function () {

			return "not available";
		},
		changeLanguage: function (oEvent) {
			this.oBusy = this.getView().byId("BusyDialog");
			if (this.oBusy) {
				this.oBusy.open();
			}
			this.getOwnerComponent().getModel("languageModel").setProperty("/currentLanguage", oEvent);
			var i18nModel = new ResourceModel({
				bundleName: "dart.hcm.benefits.i18n.i18n"
			});
			var i18nModel_es = new ResourceModel({
				bundleName: "dart.hcm.benefits.i18n.i18n_es_ES"
			});
			var filterValue;
			if (oEvent === "Spanish") {
				filterValue = "S";
				this.getView().setModel(i18nModel_es, "i18n");
			} else {
				filterValue = "E";
				this.getView().setModel(i18nModel, "i18n");
			}
			if (this.oBusy) {
				jQuery.sap.delayedCall(1000, this, function () {
					this.oBusy.close();
				});
			}

		},
		loadMobileFragment: function (oHeader) {
			if (this.getView().byId("langSelection")) {
				this.getView().byId("langSelection").destroy();
			}
			if (this.getView().byId("langSelection")) {
				this.getView().byId("langSelection").destroy();
			}
			if (this.getView().byId("selectLanguage")) {
				this.getView().byId("selectLanguage").destroy();
			}
			var oFragment = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.generalFragments.mobileLanguageSelection",
				this);
			for (var i = 0; i < oFragment.length; i++) {
				oHeader.addContent(oFragment[i]);
			}
		},
		loadDesktopFragment: function (oHeader) {
			if (this.getView().byId("selectLanguage")) {
				this.getView().byId("selectLanguage").destroy();
			}
			
			if (this.byId("currentBenefitsBtn")) {
				this.byId("currentBenefitsBtn").destroy();
			}
			
			Fragment.load({
                id: this.getView().getId(),
                name: "dart.hcm.benefits.view.generalFragments.languageSelection",
                controller: this
            }).then(function (oFragment) {
    			for (var i = 0; i < oFragment.length; i++) {
					oHeader.addContent(oFragment[i]);
				}

				if( this.byId("currentBenefitsBtn") ) {
					this.byId("currentBenefitsBtn").setVisible( this.routeArguments.Event === "OPEN" );
				}				
            }.bind(this));
		},
		createRadioButton: function () {
			this.dialog = "";
			this.dialog = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.generalFragments.languageDialog", this);
			this.getView().addDependent(this.dialog);
			this.dialog.open();
		},
		setLanguage: function () {

			this.getView().setModel(this.getOwnerComponent().getModel("languageModel"), "languageModel");
			var selectedKey;
			this.currentLanguage = this.getOwnerComponent().getModel("languageModel").getProperty("/currentLanguage");
			if (this.currentLanguage === null || this.currentLanguage === "English") {
				this.currentLanguage = "English";
				selectedKey = "en";
				this.getOwnerComponent().getModel("languageModel").setProperty("/en", true);
				this.getOwnerComponent().getModel("languageModel").setProperty("/es", false);
			} else if (this.currentLanguage === "Spanish") {
				selectedKey = "es";
				this.getOwnerComponent().getModel("languageModel").setProperty("/en", false);
				this.getOwnerComponent().getModel("languageModel").setProperty("/es", true);
			}
			if (this.desktopView) {
				if (this.getView().byId("selectLanguage")) {
					this.getView().byId("selectLanguage").setSelectedItem(this.currentLanguage);
					this.getView().byId("selectLanguage").setSelectedKey(selectedKey);
				}

			} else {
				if (this.getView().byId("disabRadio")) {
					this.getView().byId("disabRadio").setSelected(this.currentLanguage);
				}

			}
			this.changeLanguage(this.currentLanguage);
		},
		sanitizeSapString: function (str) {
			var text = "";
			if (str) {
				text = str.replace(/\r\n\r\n/gi, "\t");
				text = text.replace(/\r\n/gi, "");
				text = text.replace(/\t/gi, "\r\n");
			}
			return text;
		},
		goToLandingPage: function () {
			this.getRouter().navTo("LandingPage");
		},
		responseHasError: function (response) {
			if (response.headers["sap-message"]) {
				var message = JSON.parse(response.headers["sap-message"]);
				if (message.severity.toLowerCase() === "error") {
					return true;
				}
			}
			return false;
		},
		submitEnrollments: function (pernr,event,begda,endda) {
			this.benefitsModel().read("/plan_summary", {
				filters: [this.oPlanFilter, this.oPlanEvent],
				success: function (result) {
					result.results.splice(1);
					var promises = [];
					result.results.forEach(function (p) {
						var promise = new Promise(function (resolution, rejection) {
							var key = this.benefitsModel().createKey("/plan_summary", Object.assign({}, p, {
								pernr: pernr,
								event: event
							}));
							this.benefitsModel().update(key, {}, {
								success: function (response) {
									resolution(response);
								}
							});
						}.bind(this));
						promises.push(promise);
					}.bind(this));
					Promise.all(promises).then(function () {
						this.getRouter().navTo("CurrentBenefits", {
							Pernr: pernr,
							Begda: begda,
							Endda: endda,
							Event: event
						});
					}.bind(this));
				}.bind(this)
			});

		}
	});
});