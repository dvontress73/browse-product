sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/UploadCollectionParameter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button",
	"sap/m/MessageBox",
	"dart/hcm/benefits/utils/dependentUtils"
], function (
	Controller,
	JSONModel,
	Filter,
	FilterOperator,
	UploadCollectionParameter,
	MessageToast,
	Fragment,
	Dialog,
	Text,
	Button,
	MessageBox,
	dependentUtils
) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.Dependents", {
		onInit: function () {
			this.getRouter().getRoute("DependentsStep").attachPatternMatched(this.onRouteMatched.bind(this));
			this.getRouter().getRoute("Dependents").attachPatternMatched(this.onRouteMatched.bind(this));
			this.dateParser = sap.ui.core.format.DateFormat.getInstance({
				format: "yMd"
			});
		},
		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
			this.getDependents();

		},
		initLocalModel: function () {
			this.model = new JSONModel({
				dependents: [],
				newDependent: {},
				dialogTitle: "",
				attachmentText: "",
				uploadUrl: "/sap/opu/odata/sap/ZHBN_4862_EMP_BEN_SRV/attachmentSet",
				dependentFiles: [],
				isEdit: false,
				isSSNEnabled: true
			});

			this.getView().setModel(this.model);
		},
		initValidationModel: function () {
			this.validationModel = new JSONModel({
				favor: "",
				favorStatus: "None",
				fanam: "",
				fanamStatus: "None",
				fasex: "",
				fasexStatus: "None",
				fgbdt: "",
				fgbdtStatus: "None",
				disab_date: "",
				disab_dateStatus: "None"
			});
			this.getView().setModel(this.validationModel, "validation");
		},
		getWizard: function () {
			return this.getView().byId("BenefitsWizard");
		},
		goToNextStep: function () {
			this.getWizard().nextStep();
		},
		gotToPreviousStep: function () {
			this.getWizard().previousStep();
		},
		enroll: function (event) {
			var medicalModel = event.getSource().getModel("medical");
			medicalModel.getData().forEach(function (medical, ind) {
				medicalModel.setProperty("/" + ind + "/enrolled", false);
			});
			var bindingContext = event.getSource().getBindingContext("medical");
			medicalModel.setProperty("enrolled", true, bindingContext);
		},
		hasSpouse: function (oEvent) {

			return this.model.getProperty("/dependents").filter(function (d) {
				return d.relation === "Spouse";
			}).length > 0;
		},
		addDependent: function (event) {
			this.model.setProperty("/isSSNEnabled", true);
			var subty = this.byId("benefitTypeSelect").getSelectedKey();
			if(subty === "91"){
				MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("courtOrdered"));
				return;
			}
			if (subty === "1" && this.hasSpouse()) {
				MessageToast.show(this.getTranslatedText("alreadyHasSpouse"), {
					duration: 5000
				});
			} else if (subty === "") {
				MessageToast.show(this.getTranslatedText("addDependentMissing"), {
					duration: 5000
				});
			} else if (subty) {
				var title = this.getTranslatedText("addDependentTitle", this.byId("benefitTypeSelect").getSelectedItem().getText());
				this.model.setProperty("/dialogTitle", title);
				this.model.setProperty("/newDependent", {
					pernr: "",
					type: "D", // it's a dependent
					subty: subty, // child/spouse/legal dependent/etc
					favor: "", // first name
					fanam: "", // last name
					fasex: 0, // gender [male, female] send index of array
					fgbdt: "", // date of birth
					disab: "", // disability
					disab_date: "", // date of disability
					stras: "", // house number and street
					ort01: "", // city
					state: "",
					pstlz: "", // postal code
					telnr: "", // telephone number
					status_id: "1",
					event: this.routeArgs.Event || ""
				});
				this.model.setProperty("/isEdit", false);
				this.openDependentDialog();
			}
		},
		editDependent: function (event) {
			var dep = event.getSource().getBindingContext().getProperty();
			//need to send event to backend so they know what end date to put on dependent confirmation case.
			dep.sapDep.event = this.routeArgs.Event || "";
			if(dep.sapDep.subty === "91"){
				MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("courtOrdered"));
				return;
			}
			var title = this.getTranslatedText("editDependentTitle", dep.fullName);
			if (dep.status === "VERIFIED" || dep.status === "Verified" || dep.status === "Pending Approval") {
				this.model.setProperty("/isSSNEnabled", false);
			} else {
				this.model.setProperty("/isSSNEnabled", true);
			}
			this.model.setProperty("/dialogTitle", title);
			this.model.setProperty("/newDependent", dep.sapDep);
			this.model.setProperty("/isEdit", true);
			this.getDependentFiles();
			this.openDependentDialog();
			this.byId("disabRadio").setSelectedIndex(dep.sapDep.disab === "X" ? 1 : 0);
		},
		openDependentDialog: function () {
			this.setAttachmentText();
			this.initValidationModel();
			this.model.setProperty("/dependentFiles", []);
			this.dialog = sap.ui.xmlfragment(this.getView().getId(), "dart.hcm.benefits.view.dialogs.addDependent", this);
			// connect dialog to the root view of this component (models, lifecycle)
			this.getView().addDependent(this.dialog);
			this.dialog.open();
		},
		getDependentFiles: function () {
			var dep = this.model.getProperty("/newDependent");
			this.benefitsModel().read("/attachmentSet", {
				filters: [
					new Filter({
						path: "pernr",
						operator: FilterOperator.EQ,
						value1: dep.pernr
					}),
					new Filter({
						path: "type",
						operator: FilterOperator.EQ,
						value1: dep.type
					}),
					new Filter({
						path: "subty",
						operator: FilterOperator.EQ,
						value1: dep.subty
					}),
					new Filter({
						path: "objps",
						operator: FilterOperator.EQ,
						value1: dep.objps
					})
				],
				success: function (result) {
					var files = result.results;
					files.forEach(function (f) {
						if (!f.url) {
							var url = new URL(f.__metadata.media_src);
							f.url = url.pathname;
						}
					});
					this.model.setProperty("/dependentFiles", files);
				}.bind(this)
			});
		},
		checkRequired: function (path, field, i18nkey) {
			if (!this.model.getProperty(path + "/" + field)) {
				this.validationModel.setProperty("/" + field, this.getTranslatedText("isRequired", this.getTranslatedText(i18nkey)));
				this.validationModel.setProperty("/" + field + "Status", "Error");
				return false;
			} else {
				this.validationModel.setProperty("/" + field, "");
				this.validationModel.setProperty("/" + field + "Status", "None");
				return true;
			}
		},
		submitDependent: function () {
			var isValid = true;
			isValid = this.checkRequired("/newDependent", "favor", "legalFirstName") && isValid;
			isValid = this.checkRequired("/newDependent", "fanam", "legalLastName") && isValid;
			isValid = this.checkRequired("/newDependent", "fasex", "birthGender") && isValid;
			isValid = this.checkRequired("/newDependent", "fgbdt", "dateOfBirth") && isValid;

			//Check SSN for completeness 
			if (typeof this.model.getProperty("/newDependent/perid") !== "undefined") {
				if (this.model.getProperty("/newDependent/perid").indexOf("_") !== -1) {
					this.getView().byId("idSSN").setValueState("Error");
					this.getView().byId("idSSN").setValueStateText(this.getTranslatedText("invalidSSN"));
					isValid = false;
					return;
				}
			}
			var dob = this.getView().byId("idDob").getValue();
			if (dob.includes("/")) {

			}
			var checkDate = new Date(dob.substr(0, 4), dob.substr(4, 2) - 1, dob.substr(6, 2));
			if (checkDate.getMonth() + 1 != dob.substr(4, 2) || checkDate.getUTCFullYear() != dob.substr(0, 4) || checkDate.getDate() != dob.substr(
					6, 2)) {
				this.validationModel.setProperty("/fgbdtStatus", "Error");
				this.getView().byId("idDob").setValueStateText("Enter a valid date of birth in MM/dd/yyyy format");
				return;
			} else {
				this.validationModel.setProperty("/fgbdtStatus", "None");
			}

			if (this.getView().byId("disabRadio").getSelectedButton().getText() === "Yes") {
				if (this.getView().byId("idDisabDate").getDateValue() === null) {
					this.getView().byId("idDisabDate").setValueState("Error");
					this.getView().byId("idDisabDate").setValueStateText(this.getTranslatedText("incapacitedRequired"));
					isValid = false;
				}
			}

			if (isValid) {

				if (this.model.getProperty("/isEdit")) {
					this.updateDependent();
				} else {
					this.createDependent();
				}
			} else {
				MessageToast.show(this.getTranslatedText("dependentError"), {
					duration: 5000
				});
			}
		},
		createDependent: function () {
			var tempModel = this.model.getProperty("/newDependent");
			tempModel.pernr = this.routeArgs.Pernr;
			var busy = this.getView().byId("BusyDialog");
			busy.open();

			this.benefitsModel().create("/empDepBenSet", tempModel, {
				success: function (dependent, response) {
					if (!this.responseHasError(response)) {
						this.submitDocuments(dependent, this.getTranslatedText("dependentCreated"), true);
					} else {
						busy.close();
					}
				}.bind(this)
			});
		},
		updateDependent: function () {
			var dep = this.model.getProperty("/newDependent");

			var path = this.benefitsModel().createKey("/empDepBenSet", dep);
			var busy = this.getView().byId("BusyDialog");
			busy.open();
			this.benefitsModel().update(path, dep, {
				error: function () {
					busy.close();
					MessageToast.show(this.getTranslatedText("dependentSaveError"), {
						duration: 5000

					});
				}.bind(this),
				filters: [this.oFilter],
				success: function (dependent, response) {
					if (!this.responseHasError(response)) {
						this.submitDocuments(dep, this.getTranslatedText("dependentUpdated"), true);
					}
					jQuery.sap.delayedCall(4000, this, function () {
						busy.close();
					});
				}.bind(this)
			});
		},

		submitDocuments: function (dependent, message, closeDialog) {
			var uploader = this.byId("addDependentFileUploader");
			this.dependent = dependent;
			var filesToUpload = uploader.getItems().filter(function (f) {
				return !f.getBindingContext();
			});
			var fileNames = this.byId("addDependentFileUploader").getItems();
			if (filesToUpload.length > 0) {
				uploader.upload();
				uploader.attachUploadComplete(this.uploadSucceeded.bind(this, message));

			} else {
				this.uploadSucceeded(message, closeDialog);
			}
		},
		addHeaderInformation: function (oEvent) {
			this.benefitsModel().refreshSecurityToken();
			var headers = this.benefitsModel().oHeaders;
			var token = headers["x-csrf-token"];

			var csrfToken = new UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});
			oEvent.getParameters().addHeaderParameter(csrfToken);

			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "pernr",
				value: this.dependent.pernr
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "type",
				value: this.dependent.type
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "subty",
				value: this.dependent.subty
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "objps",
				value: this.dependent.objps
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "begin_date",
				value: this.dependent.begin_date
			}));

			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")
			}));
		},

		uploadSucceeded: function (message, closeDialog) {
			if (!this.stopUpload) {
				MessageToast.show(message, {
					duration: 5000
				});
				if (closeDialog) {
					this.getDependents();
					this.cancelDialog();
				}
			}
		},
		uploadFailed: function () {
			MessageToast.show(this.getTranslatedText("dependentDocumentationError"), {
				duration: 5000
			});
			this.cancelDialog();
		},
		cancelDialog: function () {
			this.dialog.close();
			this.dialog.destroy();
			var oBusy = this.getView().byId("BusyDialog");
			if (oBusy) {
				oBusy.close();
			}
		},

		setDependentsFilter: function (filter) {
			this.filter = filter;
		},
		getDependents: function (filter) {

			//set this here so it can be used on data refresh
			this.model.setProperty("/dependents", []);
			if (this.routeArgs.Pernr) {
				this.getHeaderInformation();
			} else {
				this.getDependentsFromOdata(null);
			}
		},
		getHeaderInformation: function () {

			var key = "/empl_headSet(Pernr='" + this.routeArgs.Pernr +
				"',Begda='" + this.routeArgs.Begda +
				"',Endda='" + this.routeArgs.Endda + "')";
			this.benefitsModel().read(key, {
				success: function (header) {
					this.getDependentsFromOdata(header);
				}.bind(this)
			});
		},
		getDependentsFromOdata: function (header) {
			dependentUtils.getDependentsFromOdata(header, function (dependents) {
				if (this.filter) {
					dependents = dependents.filter(this.filter);
				}
				this.model.setProperty("/dependents", dependents);
			}.bind(this));
		},

		updateDisab: function (event) {
			var bool = event.getSource().getSelectedIndex() ? true : false;
			this.model.setProperty("/newDependent/disab", bool ? "X" : "");
			this.setAttachmentText();
		},
		onFilenameLengthExceed: function () {
			MessageToast.show(this.getTranslatedText("fileLengthExceeded"), {
				duration: 5000
			});
		},
		onFileSizeExceed: function () {
			MessageToast.show(this.getTranslatedText("fileSizeExceeded"), {
				duration: 5000
			});
		},
		onTypeMissmatch: function () {
			MessageToast.show(this.getTranslatedText("fileTypeIncorrect"), {
				duration: 5000
			});
		},
		deleteAttachment: function (event) {
			var bc = event.getSource().getBindingContext();
			var model = this.benefitsModel();
			var confirmDialog = new Dialog({
				title: this.getTranslatedText("confirmDeleteTitle"),
				type: "Message",
				content: new Text({
					text: this.getTranslatedText("confirmDeleteAttachment", bc.getProperty("fileName"))
				}),
				beginButton: new Button({
					text: this.getTranslatedText("remove"),
					press: function () {
						var file = bc.getProperty();
						file.deletion_flag = "X";
						var path = model.createKey("/attachmentSet", file);
						model.update(path, file, {
							success: function () {
								this.getDependentFiles();
								MessageToast.show(this.getTranslatedText("attachmentDeleteSuccess", file.fileName), {
									duration: 5000
								});
								confirmDialog.close();
							}.bind(this),
							error: function () {
								MessageToast.show(this.getTranslatedText("attachmentDeleteError", file.fileName), {
									duration: 5000
								});
								confirmDialog.close();
							}.bind(this)
						});
					}.bind(this)
				}),
				endButton: new Button({
					text: this.getTranslatedText("cancel"),
					press: function () {
						confirmDialog.close();
					}
				}),
				afterClose: function () {
					confirmDialog.destroy();
				}
			});

			confirmDialog.open();
		},
		getKeyForTextFromDependentType: function (famsa) {
			var map = {
				"Spouse": "spouse",
				"Child": "new_born",
				"Step Child": "step_child",
				"Foster Child": "foster",
				"Legal Dependent": "adopted"
			};
			return map[famsa];
		},
		setAttachmentText: function () {
			var bool = this.model.getProperty("/newDependent/disab") === "X";
			var textKey = "disabled";
			if (!bool) {
				var subtyKey = this.model.getProperty("/newDependent").subty;
				textKey = this.getKeyForTextFromDependentType(this.benefitsModel().getProperty("/empSubtypeSet('" + subtyKey + "')").famsa);
			}
			var attachmentTextKey = "/welcome_terms_textSet('" + textKey + "')/text";
			var attachmentText = this.benefitsModel().getProperty(attachmentTextKey);
			this.model.setProperty("/attachmentText", attachmentText);
		},
		goHome: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		}
	});
});