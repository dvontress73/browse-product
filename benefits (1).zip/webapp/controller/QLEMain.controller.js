sap.ui.define([
	"dart/hcm/benefits/controller/Base",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"dart/hcm/benefits/utils/dependentUtils",
	"sap/m/UploadCollectionParameter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	
	"sap/m/DialogType",
	"sap/m/ButtonType",

	"sap/ui/core/ValueState"
	
], function (Controller, JSONModel, MessageToast, dependentUtils, UploadCollectionParameter, Filter, FilterOperator, MessageBox, Dialog, Button, Text, DialogType, ButtonType, ValueState) {
	"use strict";

	return Controller.extend("dart.hcm.benefits.controller.QLEMain", {
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("QLEMain").attachPatternMatched(this.onRouteMatched.bind(this));
		},

		onRouteMatched: function (route) {
			this.routeArgs = route.getParameters().arguments;
			this.initLocalModel();
		},

		initLocalModel: function () {
			this.model = new JSONModel({
				isMarriage: false,
				isDivorce: false,
				isDeath: false,
				isBirth: false,
				isCoverage: false,
				dependents: [],
				qleFiles: [],
				attachmentText: "",
				uploadUrl: "/sap/opu/odata/sap/ZHBN_4862_EMP_BEN_SRV/qleAttachmentSet",
				dependentFiles: [],
				qleData: {}
			});
			
			var text = this.getView().getModel("i18n").getResourceBundle().getText("qle" + this.routeArgs.Event);
			this.model.setProperty("/attachmentText",text);
			this.getQLEAttachement();
			this.getView().setModel(this.model);
		},
		
		getQLEAttachement: function () {
			this.benefitsModel().read("/qleAttachmentSet", {
				filters: [
					new Filter({
						path: "pernr",
						operator: FilterOperator.EQ,
						value1: this.routeArgs.Pernr
					}),
					new Filter({
						path: "event",
						operator: FilterOperator.EQ,
						value1: this.routeArgs.Event
					})

				],
				success: function (result) {
					var files = result.results;
					files.forEach(function (f) {
						if (!f.url) {
							var url = new URL(f.__metadata.media_src);
							f.url = url.pathname;
						}
					});
					this.model.setProperty("/qleFiles", files);
					this.byId("nextButton").setEnabled( files.length > 0 );
				}.bind(this)
			});
		},
		
		next: function () {
			
			if( this.routeArgs.Event === "DIV" || this.routeArgs.Event === "DETH" ) {
				if (!this.oSuccessMessageDialog) {
					this.oSuccessMessageDialog = new Dialog({
						type: DialogType.Message,
						title: "Success",
						state: ValueState.Success,
						content: new Text({ text: this.getTranslatedText( this.routeArgs.Event + "_DialogText") }),
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "OK",
							press: function () {
								this.oSuccessMessageDialog.close();
					
								var str = "/qleEvent(PERNR='" + this.routeArgs.Pernr + "',TYPE='" + this.routeArgs.Event + "',BEGDA='" + this.routeArgs.Begda + "')";
								
								var payload = {
									"PERNR"	: this.routeArgs.Pernr,
									"TYPE"	: this.routeArgs.Event,
									"BEGDA"	: this.routeArgs.Begda,
									"ENDDA": "",
									"ERDAT": "",
									"ERZET": "",
									"ERNAM": "",
									"STATUS": "",
									"INVALID": ""
								};
								
								this.benefitsModel().update(str, payload, {
									success: function() {
										this.getRouter().navTo("LandingPage", {
											Pernr: this.routeArgs.Pernr
										});
									}.bind(this)
								});
								
							}.bind(this)
						})
					});
				}
	
				this.oSuccessMessageDialog.open();								
				return;
			}
			
			var sessionId, navTo = "";

			function onSuccess() {
				this.getRouter().navTo(navTo, this.routeArgs);
			}

			sessionId = "QLEBenefitsWizard";
			navTo = "QLEBenefitsWizard";

			this.updateCurrentStep(Object.assign({},
				this.routeArgs, {
					IdSession: sessionId
				}), {
				success: onSuccess.bind(this)
			});
		},

		addHeaderInformation: function (oEvent) {
			this.benefitsModel().refreshSecurityToken();
			var headers = this.benefitsModel().oHeaders;
			var token = headers["x-csrf-token"];

			var csrfToken = new sap.m.UploadCollectionParameter({  //UploadCollectionParameter({ //
				name: "x-csrf-token",
				value: token
			});
			oEvent.getParameters().addHeaderParameter(csrfToken);

			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "pernr",
				value: this.routeArgs.Pernr
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "event",
				value: this.routeArgs.Event
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "begda",
				value: this.routeArgs.Begda
			}));
			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "endda",
				value: this.routeArgs.Endda
			}));

			oEvent.getParameters().addHeaderParameter(new UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")
			}));
			
			sap.ui.core.BusyIndicator.show();
		},		
		
		submitDocuments: function (dependent, message, closeDialog) {
			var uploader = this.byId("addQLEFileUploader");
			this.dependent = dependent;
			var filesToUpload = uploader.getItems().filter(function (f) {
				return !f.getBindingContext();
			});
			if (filesToUpload.length > 0) {
				uploader.upload();
				uploader.attachUploadComplete(this.uploadSucceeded.bind(this, message));
			}
		},
		
		uploadSucceeded: function () {
			sap.ui.core.BusyIndicator.hide();
			this.getQLEAttachement();
		},

		deleteAttachment: function (event) {
			var bc = event.getSource().getBindingContext();
			var model = this.benefitsModel();
			var confirmDialog = new Dialog({
				title: this.getTranslatedText("confirmDeleteTitle"),
				type: "Message",
				content: new Text({
					text: this.getTranslatedText("confirmDeleteAttachment", bc.getProperty("fileName"))
				}),
				beginButton: new Button({
					text: this.getTranslatedText("remove"),
					press: function () {
					var file = bc.getProperty();
						file.deletion_flag = "X";
						var path = model.createKey("/qleAttachmentSet", file);
						model.update( path, file, {
							success: function () {
								this.getQLEAttachement();
								MessageToast.show(this.getTranslatedText("attachmentDeleteSuccess", file.fileName), {
									duration: 5000
								});
								confirmDialog.close();
							}.bind(this),
							error: function (evt) {
								
								MessageToast.show(this.getTranslatedText("attachmentDeleteError", file.fileName), {
									duration: 5000
								});
								confirmDialog.close();
							}.bind(this)
						});
					}.bind(this)
				}),
				endButton: new Button({
					text: this.getTranslatedText("cancel"),
					press: function () {
						confirmDialog.close();
					}
				}),
				afterClose: function () {
					confirmDialog.destroy();
				}
			});

			confirmDialog.open();
		},		
		
		onFilenameLengthExceed: function () {
			MessageToast.show(this.getTranslatedText("fileLengthExceeded"), {
				duration: 5000
			});
		},
		
		onFileSizeExceed: function () {
			MessageToast.show(this.getTranslatedText("fileSizeExceeded"), {
				duration: 5000
			});
		},
		
		onTypeMissmatch: function () {
			MessageToast.show(this.getTranslatedText("fileTypeIncorrect"), {
				duration: 5000
			});
		},
		
		gotToPreviousStep: function (evt) {
			var that = this;
			this.getRouter().navTo("LandingPage", {
				Pernr: that.routeArgs.Pernr
			});
		},

		fileDeleted : function(oEvent) {
			this.byId("nextButton").setEnabled( this.byId("addQLEFileUploader").getItems().length > 0 );
		},

		refreshModel : function(oEvent) {
			this.byId("nextButton").setEnabled( ( oEvent.getParameter("files").length + this.byId("addQLEFileUploader").getItems().length ) > 0 );
		}
	});
});