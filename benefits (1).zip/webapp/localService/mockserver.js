sap.ui.define([
		"sap/ui/core/util/MockServer"
	], function (MockServer) {
		"use strict";

		var oMockServer,
			_sAppModulePath = "dart/hcm/benefits/",
			_sJsonFilesModulePath = _sAppModulePath + "localService/mockdata";

		return {
			/**
			 * Initializes the mock server.
			 * You can configure the delay with the URL parameter "serverDelay".
			 * The local mock data in this folder is returned instead of the real data for testing.
			 * @public
			 */

			init : function () {
				var oUriParameters = jQuery.sap.getUriParameters(),
					sJsonFilesUrl = jQuery.sap.getModulePath(_sJsonFilesModulePath),
					sManifestUrl = jQuery.sap.getModulePath(_sAppModulePath + "manifest", ".json"),
					oManifest = jQuery.sap.syncGetJSON(sManifestUrl).data,
					oMainDataSource = oManifest["sap.app"].dataSources.ZHBN_4862_EMP_BEN_SRV,
					sMetadataUrl = jQuery.sap.getModulePath(_sAppModulePath + oMainDataSource.settings.localUri.replace(".xml", ""), ".xml"),
					// ensure there is a trailing slash
					sMockServerUrl = /.*\/$/.test(oMainDataSource.uri) ? oMainDataSource.uri : oMainDataSource.uri + "/";

				oMockServer = new MockServer({
					rootUri : sMockServerUrl
				});

				// configure mock server with a delay of 1s
				MockServer.config({
					autoRespond : true,
					autoRespondAfter : (oUriParameters.get("serverDelay") || 0)
				});

				oMockServer.simulate(sMetadataUrl, {
					sMockdataBaseUrl : sJsonFilesUrl,
					bGenerateMissingMockData : true
				});
				
		       var aRequests = oMockServer.getRequests();
		       aRequests.push({
		            method: "MERGE",
		            path: new RegExp("(.*)empl_headSet(.*)"),
		            response: function(oXhr, sUrlParams) {
		            jQuery.sap.log.debug("Mock Server: Incoming request for empl_headSet");
		            var oResponse = {
		                 data: {},
		                 headers: {
		                      "Content-Type": "application/json;charset=utf-8",
		                      "DataServiceVersion": "1.0"
		                 },
		                 status: "204",
		                 statusText: "No Content"
		            };
		            oXhr.respond(oResponse.status, oResponse.headers, JSON.stringify({ d: oResponse.data }));
		            }
		       });
		       oMockServer.setRequests(aRequests);
				
				oMockServer.start();
			},

			/**
			 * @public returns the mockserver of the app, should be used in integration tests
			 * @returns {sap.ui.core.util.MockServer} the mockserver instance
			 */
			getMockServer : function () {
				return oMockServer;
			}
		};

	}
);