sap.ui.define([
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	DateFormat, Filter, FilterOperator
) {
	"use strict";

	return {
		dependentLimits: {
			DENT: {
				"EE": 0,
				"EE+1": 1,
				"EEFA": 19
			},
			AMED: {
				"EE": 0,
				"EE+1": 1,
				"EFAM": 19
			},
			VISN: {
				"EE": 0,
				"EE+1": 1,
				"EEFA": 19
			}
		},
		dateParser: DateFormat.getInstance({
			format: "yMd"
		}),
		convertSapDependentToFrontEnd: function (dep) {
			return {
				fullName: dep.favor + " " + dep.fanam,
				status: this.mapStatusIdToText(dep.status_id),
				relation: this.benefitsModel.getProperty("/empSubtypeSet('" + dep.subty + "')").famsa,
				dateOfBirth: this.dateParser.parse(dep.fgbdt),
				status_id: dep.status_id,
				sapDep: dep
			};
		},
		mapStatusIdToText: function (id) {
			//TODO: wrp translation into this
			return [
				this.i18n.getResourceBundle().getText("verificationStatusShortYou"),
				this.i18n.getResourceBundle().getText("verificationStatusShortActionNeeded"),
				this.i18n.getResourceBundle().getText("verificationStatusShortPending"),
				this.i18n.getResourceBundle().getText("verificationStatusShortVerified"),
				this.i18n.getResourceBundle().getText("verificationStatusShortRejected"),
				this.i18n.getResourceBundle().getText("verificationStatusShortVerified"),
				this.i18n.getResourceBundle().getText("verificationStatusShortRejected")
			][id];
		},
		getDependentsFromOdata: function (header, successFunction) {
			var newFilter = new sap.ui.model.Filter({
				path: "pernr",
				operator: FilterOperator.EQ,
				value1: header.Pernr
			});
			
			var oDatefiler = new sap.ui.model.Filter({
				path: "begin_date",
				operator: FilterOperator.EQ,
				value1: header.date
			});
			this.benefitsModel.read("/empDepBenSet", {

				filters: [newFilter,oDatefiler],
				success: function (data) {
					var dependents = [];
					if (header) {
						//add current employee to top of list
						dependents.push({
							fullName: header.ename,
							status: this.mapStatusIdToText(0),
							relation: this.i18n.getResourceBundle().getText("employee"),
							status_id: "0",
							dateOfBirth: this.dateParser.parse(header.dob),
							sapDep: {}
						});
					}
					data.results.forEach(function (dep) {
						dependents.push(this.convertSapDependentToFrontEnd(dep));
					}.bind(this));

					successFunction(dependents);
				}.bind(this)
			});
		}
	};
});