sap.ui.define([

], function (

) {
	"use strict";

	return {
		getKeyForBplan: function (bplan) {
			var bplanKey = {
				1007: "dmc",
				1008: "php",
				1009: "kaiser",
				1090: "waiveMedical",
				2000: "delta",
				2090: "waiveDental",
				3000: "vsp",
				3090: "waiveVision",
				"HCFX": "HCFX",
				"DCFX": "DCFX"
			};
			return bplanKey[bplan];
		},
		getTitleKeyForPlan: function (p) {
			var optionKey = {
				"0001": "Std",
				"0004": "Premium",
				"HCFX": "HCFX",
				"DCFX": "DCFX"
			};

			var key = this.getKeyForBplan(p.bplan) || "";
			key += optionKey[p.bopti] || "";

			return key;
		},

		getKeyLevelMedical: function () {
			var val = [{
				"key": "EE",
				"text":"Employee"
			}, {
				"key": "EE+1",
				"text":"Employee + 1"
			}, {
				"key": "EFAM",
				"text":"Family"
			}];
			return val;
		},

		getKeyLevelDental: function () {
		var val = [{
				"key": "EE",
				"text":"Employee"
			}, {
				"key": "EE+1",
				"text":"Employee + 1"
			}, {
				"key": "EEFA",
				"text":"Family"
			}];
			return val;
		},
		getTextKeyForPlanLevel: function (level) {
			var val = {
				"EE": "employeeOnly",
				"EE+1": "employeePlusOne",
				"EFAM": "employeePlusFamily",
				"EEFA": "employeePlusFamily",
				"EECH": "employeePlusChild",
				"EESP": "employeePlusSpouse"
			}[level];
			if (val) {
				return val;
			}
			return level;
		}
	};
});