function initModel() {
	var sUrl = "/sap/opu/odata/sap/ZHRP_4874_DEP_VER_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}