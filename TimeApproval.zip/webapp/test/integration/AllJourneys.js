jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"dart/hcm/timeapproval/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"dart/hcm/timeapproval/test/integration/pages/Worklist",
		"dart/hcm/timeapproval/test/integration/pages/Object",
		"dart/hcm/timeapproval/test/integration/pages/NotFound",
		"dart/hcm/timeapproval/test/integration/pages/Browser",
		"dart/hcm/timeapproval/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "dart.hcm.timeapproval.view."
	});

	sap.ui.require([
		"dart/hcm/timeapproval/test/integration/WorklistJourney",
		"dart/hcm/timeapproval/test/integration/ObjectJourney",
		"dart/hcm/timeapproval/test/integration/NavigationJourney",
		"dart/hcm/timeapproval/test/integration/NotFoundJourney",
		"dart/hcm/timeapproval/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});