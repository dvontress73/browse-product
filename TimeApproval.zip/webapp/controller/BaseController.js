sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("dart.hcm.timeapproval.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * New logic per ADO 273969 Fiori: Allow Substitutes for MSS Time Approval
		 * @Public
		 */
		createEvent: function (evt) {
			var ctx = evt.getSource().getBindingContext("worklistView");
			var oViewModel = this.getModel("worklistView");

			//Look for employeeNumber in ctx and viewModel key
			var employeeNumber = oViewModel.getProperty("employeeNumber", ctx) || oViewModel.getProperty("/employeeNumber");
			//var oRouter = this.getRouter();
			var options = {
				query: {}
			};

			if (employeeNumber) {
				options.query.employeeNumber = employeeNumber;
			}

		},
		getSubordinateFilter: function () {
			return new Filter({
				path: "SubGroupExclusion",
				operator: FilterOperator.EQ,
				value1: "Exempt"
			});
		},
		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function () {
			var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		}

	});

});