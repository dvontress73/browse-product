sap.ui.define([
		"dart/hcm/timeapproval/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("dart.hcm.timeapproval.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);