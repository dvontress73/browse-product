sap.ui.define([
	"dart/hcm/timeapproval/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"dart/hcm/timeapproval/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"dart/hcm/core/SubordinateType",
	"sap/ui/core/BusyIndicator"
], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator, Sorter, SubordinateType, BusyIndicator) {
	"use strict";

	return BaseController.extend("dart.hcm.timeapproval.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;
			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				//				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				
				tableData: [],
				filters: {
					employeeNumber: null,
					subordinateType: SubordinateType.DIRECT,
					subordinateFilter: this.getSubordinateFilter()
				},
				SubordinateTypeSelected: true,
				IsConfirmed: false,
				scope: "",
				subordinateType: SubordinateType.DIRECT,
				subordinateTypes: [{
					key: SubordinateType.DIRECT,
					text: "Direct"
				}, {
					key: SubordinateType.INDIRECT,
					text: "Indirect"
				}, {
					key: SubordinateType.DELEGATE,
					text: "Delegate"
				}, {
					key: SubordinateType.ALL,
					text: "All"
				}]
				
			});
			this.setModel(oViewModel, "worklistView");

			//ADO273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
			//model for the filter selection
			var oFilterModel = new JSONModel({
				tableData: [],
				filters: {
					employeeNumber: null,
					subordinateType: SubordinateType.DIRECT,
					subordinateFilter: this.getSubordinateFilter()
				},
				SubordinateTypeSelected: true,
				IsConfirmed: false,
				scope: "",
				subordinateType: SubordinateType.DIRECT,
				subordinateTypes: [{
					key: SubordinateType.DIRECT,
					text: "Direct"
				}, {
					key: SubordinateType.INDIRECT,
					text: "Indirect"
				}, {
					key: SubordinateType.DELEGATE,
					text: "Delegate"
				}, {
					key: SubordinateType.ALL,
					text: "All"
				}]
			});

			this.getView().setModel(oFilterModel, "listViewFilter");

			//END ADO273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},
		//Begin ADO273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
		onBeforeRendering: function (){
			this.handleSubordinateChange();	
		},
		//End ADO273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
	
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */

		onUpdateFinished: function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
			
			
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function (oEvent) {
			this._confirmApproval(oEvent.getSource());
		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			this._oTable.getBinding("items").refresh();
		},
		// Begin Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
		handleSubordinateChange: function (evt) {
			//var oViewModel = this.getView().getModel("worklistView");
			var filters = this._getFilters();
			var oTable = this.getView().byId("table");
			//get binding to items aggregation...
			var oBinding = oTable.getBinding("items");
			//Apply the filter...
			oBinding.filter(filters);
		},
		// End Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**		 
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private		 */
		_confirmApproval: function (oItem) {
			var bConfirmed = true;
			this.getView().getModel().setProperty("IsConfirmed", bConfirmed, oItem.getBindingContext());

			this.getView().getModel().submitChanges({
				error: function (err) {
					//D500277 console.log(err);  WebIDE did not like this
				}
			});

		},
		// Begin Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
		_getFilters: function () {
				var oViewModel = this.getView().getModel("listViewFilter");
				var filters = [];
				var type = oViewModel.getProperty("/filters/subordinateType");

				if (type !== SubordinateType.ALL) {
					var value = "MSS_TMV_EE_ALL";
					if (type === SubordinateType.DIRECT) {
						value = "MSS_TMV_EE_DIR";
					}
					if (type === SubordinateType.INDIRECT) {
						value = "MSS_TMV_EE_IND";
					}

					if (type === SubordinateType.DELEGATE) {
						value = "MSS_TMV_EE_DEL";
					}

					filters.push(new Filter({
						path: "Selection",
						operator: FilterOperator.EQ,
						value1: value
					}));
				}
				return filters;
			}
			// End Changes per 273969 Fiori: Allow Substitutes for MSS Time Approval and Time Event App
	});
});