sap.ui.define([
	] , function () {
		"use strict";

		return {

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
						niceDate: function (sValue) {
				if (!sValue) {
					return "";
				}
				
				//string parse... not recommended, but UI5 insists on sending the value
				//as a string into the formatter. could probably work around
				//this in the controller, but considering that UI5 just converted
				//a DateTime object into a string, it seems fine to just parse it again.
				var nTicks = Date.parse(sValue);
				
				//because new Date() will always assume local time, to get it to account for the input
				//being UTC, we need to adjust the date by the user's current timezone offset.
				//TimezoneOffset is in minutes (e.g. 300 = -0500 = 5 hours), multiply by 60 = seconds,
				//multiply by 1000 = milliseconds, hence 60000
				var dValue = new Date(nTicks + (new Date()).getTimezoneOffset() * 60000);
				
				//check for bad conversion or max date... 
				if (isNaN(dValue)) {
					return "";
				}
				//11 = december, thanks javascript!
				if (dValue >= new Date(Date.UTC(9999, 11, 31))) {
					return this.getView().getModel("i18n").getResourceBundle().getText("maxDate");
				}
				
				var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});
				
				return oDateFormatter.format(dValue, true);
			}
		};
	}
);